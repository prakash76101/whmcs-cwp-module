<?php
/**
 * CWP Hosting Module for WHMCS
 *
 * Provisioning module for Control Web Panel (CWP), driving the CWP external API on
 * port 2304. Dispatcher only: API access lives in lib/CwpClient.php and behaviour in
 * lib/Actions/.
 *
 * Compatibility target: WHMCS 6.x through 9.x and PHP 5.6 through the PHP versions supported by the installed WHMCS release.
 *
 * @package cwp7
 * @version 3.0.42
 * @author  Booysen Logistics <bradley@booysenlogistics.co.za>
 * @license MIT
 * @link    https://github.com/bradleygb/whmcs-cwp-module
 */

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

if (!defined('CWP7_MODULE_VERSION')) {
    define('CWP7_MODULE_VERSION', '3.0.42');
}

require_once __DIR__ . '/lib/CwpException.php';
require_once __DIR__ . '/lib/CwpClient.php';
require_once __DIR__ . '/lib/ClientRequest.php';
require_once __DIR__ . '/lib/Validate.php';
require_once __DIR__ . '/lib/Actions/Account.php';
require_once __DIR__ . '/lib/Actions/Dashboard.php';
require_once __DIR__ . '/lib/Actions/Mailbox.php';
require_once __DIR__ . '/lib/Actions/Ftp.php';
require_once __DIR__ . '/lib/Actions/Database.php';
require_once __DIR__ . '/lib/Actions/Dns.php';
require_once __DIR__ . '/lib/Actions/ZoneEditor.php';
require_once __DIR__ . '/lib/Actions/Package.php';
require_once __DIR__ . '/lib/Actions/Session.php';
require_once __DIR__ . '/lib/Actions/Usage.php';
require_once __DIR__ . '/lib/Diagnostics/Capabilities.php';
require_once __DIR__ . '/lib/Storage/UsageHistory.php';

use Cwp7\Actions\Account;
use Cwp7\Actions\Dashboard;
use Cwp7\Actions\Dns;
use Cwp7\Actions\ZoneEditor;
use Cwp7\Actions\Mailbox;
use Cwp7\Actions\Ftp;
use Cwp7\Actions\Session;
use Cwp7\Actions\Usage;
use Cwp7\ClientRequest;
use Cwp7\CwpClient;
use Cwp7\CwpException;
use Cwp7\Diagnostics\Capabilities;

// ---------------------------------------------------------------------------
// Module definition
// ---------------------------------------------------------------------------

/**
 * @return array<string,string|bool>
 */
function cwp7_MetaData()
{
    return [
        'DisplayName' => 'KPS CWP Manager',
        'APIVersion' => '1.1',
        'RequiresServer' => true,

        // CWP's external API is HTTPS-only on 2304; there is no cleartext equivalent.
        'DefaultNonSSLPort' => '2304',
        'DefaultSSLPort' => '2304',

        'ServiceSingleSignOnLabel' => 'Log in to Control Panel',

        // Server Sync (WHMCS 7.10+).
        'ListAccountsUniqueIdentifierDisplayName' => 'Domain',
        'ListAccountsUniqueIdentifierField' => 'domain',
        'ListAccountsProductField' => 'configoption1',
    ];
}

/**
 * Product-scoped settings.
 *
 * ORDER IS FIXED. WHMCS stores these by position in tblproducts.configoption1..24, so
 * reordering or inserting repoints the stored values of every existing product. New
 * options are appended.
 *
 * Server-scoped settings (TLS policy, timeouts, ports) live in config.php.
 *
 * @return array<string,array<string,string>>
 */
function cwp7_ConfigOptions()
{
    return [
        'package' => [
            'FriendlyName' => 'CWP Package',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '1',
            'Description' => 'Package ID or name exactly as it exists in CWP. '
                . 'Leave blank to use this product\'s name.',
        ],
        'inode' => [
            'FriendlyName' => 'Inode Limit',
            'Type' => 'text',
            'Size' => '10',
            'Default' => '0',
            'Description' => '0 for unlimited.',
        ],
        'nofile' => [
            'FriendlyName' => 'Open File Limit',
            'Type' => 'text',
            'Size' => '10',
            'Default' => '100',
            'Description' => 'Maximum open file descriptors.',
        ],
        'nproc' => [
            'FriendlyName' => 'Process Limit',
            'Type' => 'text',
            'Size' => '10',
            'Default' => '40',
            'Description' => 'Maximum concurrent processes.',
        ],
        'usernamelength' => [
            'FriendlyName' => 'Max Username Length',
            'Type' => 'text',
            'Size' => '5',
            'Default' => '8',
            'Description' => 'Applied to new accounts only. Set 0 to send the username unchanged.',
        ],

        // Slots 6-15 describe the CWP package itself, and are only read when package
        // pushing is enabled in config.php. Left blank, each limit keeps CWP's own
        // default; set to 0 it means none allowed.
        'diskquota' => [
            'FriendlyName' => 'Disk Quota (MB)',
            'Type' => 'text',
            'Size' => '10',
            'Description' => 'Required to push this product to CWP as a package.',
        ],
        'bandwidth' => [
            'FriendlyName' => 'Bandwidth (MB)',
            'Type' => 'text',
            'Size' => '10',
            'Description' => 'Monthly transfer allowance.',
        ],
        'ftpaccounts' => [
            'FriendlyName' => 'FTP Accounts',
            'Type' => 'text',
            'Size' => '10',
        ],
        'emailaccounts' => [
            'FriendlyName' => 'Email Accounts',
            'Type' => 'text',
            'Size' => '10',
        ],
        'emaillists' => [
            'FriendlyName' => 'Email Lists',
            'Type' => 'text',
            'Size' => '10',
        ],
        'databases' => [
            'FriendlyName' => 'Databases',
            'Type' => 'text',
            'Size' => '10',
        ],
        'subdomains' => [
            'FriendlyName' => 'Sub Domains',
            'Type' => 'text',
            'Size' => '10',
        ],
        'parkeddomains' => [
            'FriendlyName' => 'Parked Domains',
            'Type' => 'text',
            'Size' => '10',
        ],
        'addondomains' => [
            'FriendlyName' => 'Addon Domains',
            'Type' => 'text',
            'Size' => '10',
        ],
        'hourlyemails' => [
            'FriendlyName' => 'Hourly Email Limit',
            'Type' => 'text',
            'Size' => '10',
        ],
        'client_email_management' => [
            'FriendlyName' => 'Client Email Management',
            'Type' => 'yesno',
            'Description' => "Allow this product's customers to create, change and delete their own mailboxes. Existing products default to the server setting.",
        ],
        'client_ftp_management' => [
            'FriendlyName' => 'Client FTP Management',
            'Type' => 'yesno',
            'Description' => "Allow this product's customers to create, change and delete FTP accounts.",
        ],
        'client_dns_management' => [
            'FriendlyName' => 'Client DNS Management',
            'Type' => 'yesno',
            'Description' => "Allow this product's customers to add TXT records through the verified CWP Zone Editor transport. Existing products default to the server setting.",
        ],
    ];
}

// ---------------------------------------------------------------------------
// Admin: KPS CWP Manager dashboard
// ---------------------------------------------------------------------------

/**
 * Add a dedicated administrator action to the WHMCS service custom actions.
 *
 * WHMCS passes the normal service parameters to the custom function, including the
 * assigned server id/hostname and service username. See WHMCS provisioning-module
 * custom functions documentation for the AdminCustomButtonArray contract.
 *
 * @return array<string,string>
 */
function cwp7_AdminCustomButtonArray()
{
    // WHMCS provisioning custom functions are command actions and must return
    // success/error. They are not an HTML page renderer. The actual KPS CWP Manager
    // dashboard and DNS manager are rendered through AdminServicesTabFields below.
    return [
        'Refresh KPS CWP Manager' => 'refreshManager',
    ];
}

/**
 * Safe no-op command used by the admin custom-action menu.
 *
 * @param array<string,mixed> $params
 * @return string
 */
function cwp7_refreshManager($params)
{
    return 'success';
}

// ---------------------------------------------------------------------------
// Admin: connectivity
// ---------------------------------------------------------------------------

/**
 * @param array<string,mixed> $params
 *
 * @return array<string,mixed>
 */
function cwp7_TestConnection($params)
{
    try {
        $result = CwpClient::fromParams($params)->ping();

        if ($result['ok']) {
            // The connection test is deliberately read-only. Once connectivity is
            // established, probe only endpoints already used by this module so an
            // administrator gets useful diagnostics without granting new write access.
            $client = CwpClient::fromParams($params);
            // TestConnection is a server-level WHMCS action and must not assume a
            // service username is present. DNS candidate discovery is therefore
            // performed without account context; service-level DNS operations will
            // resolve the actual hosting username when they are implemented.
            $capabilities = Capabilities::probe($client);
            $summary = Capabilities::summary($capabilities);

            return [
                'success' => true,
                'description' => Capabilities::testConnectionDescription($summary),
            ];
        }

        $error = $result['error'];

        return [
            'success' => false,
            'error' => $error->getMessage() . "\n\n" . cwp7_troubleshootingHint($error),
        ];
    } catch (CwpException $e) {
        return [
            'success' => false,
            'error' => $e->getMessage() . "\n\n" . cwp7_troubleshootingHint($e),
        ];
    } catch (\Exception $e) {
        cwp7_logFailure('TestConnection', $params, $e);

        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Link to the CWP admin panel from the server configuration page.
 *
 * @param array<string,mixed> $params
 *
 * @return string
 */
function cwp7_AdminLink($params)
{
    try {
        $url = CwpClient::fromParams($params)->getAdminUrl();
    } catch (CwpException $e) {
        return '';
    }

    return sprintf(
        '<a href="%s" target="_blank" rel="noopener noreferrer">Open CWP Admin Panel</a>',
        htmlspecialchars($url, ENT_QUOTES, 'UTF-8')
    );
}

/**
 * Link shown on the admin's view of a service.
 *
 * Not an autologin URL — a session token would then be present in the page source of
 * every render. Use the Single Sign-On button, which mints one on click.
 *
 * @param array<string,mixed> $params
 *
 * @return void
 */
function cwp7_LoginLink($params)
{
    try {
        $url = CwpClient::fromParams($params)->getPanelUrl();
    } catch (CwpException $e) {
        return;
    }

    echo sprintf(
        '<a href="%s" target="_blank" rel="noopener noreferrer">CWP User Panel</a>',
        htmlspecialchars($url, ENT_QUOTES, 'UTF-8')
    );
}

// ---------------------------------------------------------------------------
// Provisioning lifecycle
// ---------------------------------------------------------------------------

/**
 * @param array<string,mixed> $params
 *
 * @return string
 */
function cwp7_CreateAccount($params)
{
    return cwp7_perform('CreateAccount', $params, function (Account $account) {
        $account->create();
    });
}

/**
 * @param array<string,mixed> $params
 *
 * @return string
 */
function cwp7_SuspendAccount($params)
{
    return cwp7_perform('SuspendAccount', $params, function (Account $account) {
        $account->suspend();
    });
}

/**
 * @param array<string,mixed> $params
 *
 * @return string
 */
function cwp7_UnsuspendAccount($params)
{
    return cwp7_perform('UnsuspendAccount', $params, function (Account $account) {
        $account->unsuspend();
    });
}

/**
 * @param array<string,mixed> $params
 *
 * @return string
 */
function cwp7_TerminateAccount($params)
{
    return cwp7_perform('TerminateAccount', $params, function (Account $account) {
        $account->terminate();
    });
}

/**
 * @param array<string,mixed> $params
 *
 * @return string
 */
function cwp7_ChangePassword($params)
{
    $password = isset($params['password']) ? (string) $params['password'] : '';

    return cwp7_perform('ChangePassword', $params, function (Account $account) use ($password) {
        $account->changePassword($password);
    });
}

/**
 * @param array<string,mixed> $params
 *
 * @return string
 */
function cwp7_ChangePackage($params)
{
    return cwp7_perform('ChangePackage', $params, function (Account $account) {
        $account->changePackage();
    });
}

/**
 * Runs when a renewal invoice is paid. CWP has no notion of a term, so this is a no-op.
 *
 * @param array<string,mixed> $params
 *
 * @return string
 */
function cwp7_Renew($params)
{
    return 'success';
}

// ---------------------------------------------------------------------------
// Usage
// ---------------------------------------------------------------------------

/**
 * Daily disk and bandwidth import. Runs once per server, not per service.
 *
 * @param array<string,mixed> $params
 *
 * @return void
 */
function cwp7_UsageUpdate($params)
{
    $serverId = isset($params['serverid']) ? (int) $params['serverid'] : 0;

    try {
        $stats = Usage::apply(CwpClient::fromParams($params), $serverId);

        if (function_exists('logModuleCall')) {
            logModuleCall('cwp7', 'UsageUpdate', ['serverid' => $serverId], $stats);
        }
    } catch (\Exception $e) {
        // Must not escape: this runs inside the daily cron.
        cwp7_logFailure('UsageUpdate', $params, $e);
        logActivity('CWP UsageUpdate failed for server ' . $serverId . ': ' . $e->getMessage());
    }
}

// ---------------------------------------------------------------------------
// Single sign-on
// ---------------------------------------------------------------------------

/**
 * Mint a panel session and return the URL for WHMCS to redirect to.
 *
 * @param array<string,mixed> $params
 *
 * @return array<string,mixed>
 */
function cwp7_ServiceSingleSignOn($params)
{
    try {
        $client = CwpClient::fromParams($params);
        $account = new Account($client, $params);

        $session = new Session(
            $client,
            $account->resolveUsername(),
            (bool) $client->getOption('autologin_trust_returned_host', false)
        );

        return ['success' => true, 'redirectTo' => $session->url()];
    } catch (CwpException $e) {
        cwp7_logFailure('ServiceSingleSignOn', $params, $e);

        return ['success' => false, 'errorMsg' => $e->getClientMessage()];
    } catch (\Exception $e) {
        cwp7_logFailure('ServiceSingleSignOn', $params, $e);

        return [
            'success' => false,
            'errorMsg' => 'We could not open the control panel just now. Please try again shortly.',
        ];
    }
}

// ---------------------------------------------------------------------------
// Client-area custom transport
// ---------------------------------------------------------------------------

/**
 * Expose the JSON transport as a WHMCS client-area custom function.
 *
 * WHMCS invokes allowed custom functions before rendering the normal product-details
 * page. This is the supported transport boundary for AJAX requests from a provisioning
 * module; relying on ClientArea() to intercept an arbitrary POST can leave the browser
 * with the full HTML page instead of JSON.
 *
 * @return array<int,string>
 */
function cwp7_ClientAreaAllowedFunctions()
{
    return ['ajax'];
}

/**
 * Handle the module's client-area JSON request through WHMCS's custom-function router.
 *
 * @param array<string,mixed> $params
 *
 * @return string
 */
function cwp7_ajax($params)
{
    if (!ClientRequest::wanted($_POST)) {
        ClientRequest::refuse('That request was not understood.');
    }

    cwp7_clientRequest($params);

    return '';
}

// ---------------------------------------------------------------------------
// Client area
// ---------------------------------------------------------------------------

/**
 * Extra output on the client's service page. Makes no API call.
 *
 * @param array<string,mixed> $params
 *
 * @return array<string,mixed>
 */
function cwp7_ClientArea($params)
{
    // Dashboard data is fetched separately so this render still opens no socket and an
    // unreachable panel cannot delay the page.
    $serviceId = isset($params['serviceid']) ? (int) $params['serviceid'] : 0;

    try {
        $panelUrl = CwpClient::fromParams($params)->getPanelUrl();
    } catch (CwpException $e) {
        $panelUrl = '';
    }

    $ssoUrl = $serviceId > 0
        ? 'clientarea.php?action=productdetails&id=' . $serviceId . '&dosinglesignon=1'
        : '';

    return [
        'tabOverviewModuleOutputTemplate' => 'templates/overview',
        'templateVariables' => [
            'panelUrl' => $panelUrl,
            'username' => isset($params['username']) ? (string) $params['username'] : '',
            'serverHostname' => isset($params['serverhostname']) ? (string) $params['serverhostname'] : '',
            'ssoUrl' => $ssoUrl,
            'webmailUrl' => $serviceId > 0 ? CwpClient::fromParams($params)->getWebmailUrl() : '',
            'dataUrl' => $serviceId > 0
                ? 'clientarea.php?action=productdetails&id=' . $serviceId . '&modop=custom&a=ajax'
                : '',
            // Mutating client-area AJAX requests are protected by the same WHMCS token
            // generated for this authenticated session. Do not rely on a theme-defined
            // global JavaScript variable: custom themes may not expose one.
            'csrfToken' => function_exists('generate_token') ? (string) generate_token('plain') : '',
        ],
    ];
}

/**
 * Serve one client area data request and stop.
 *
 * Reached only from cwp7_ClientArea(), so WHMCS has already authenticated the session and
 * resolved this service to the logged-in client. Which account is touched comes from
 * $params for that reason; the request supplies the operation and its own fields, never
 * an account.
 *
 * @param array<string,mixed> $params
 */
function cwp7_clientRequest($params)
{
    $operation = ClientRequest::operation($_POST);

    if ($operation === '') {
        ClientRequest::refuse('That request was not understood.');
    }

    if (ClientRequest::mutates($operation)) {
        if (!ClientRequest::tokenValid(ClientRequest::field($_POST, 'token'))) {
            ClientRequest::refuse('Your session has expired. Reload the page and try again.', 403);
        }

        $serviceId = isset($params['serviceid']) ? (int) $params['serviceid'] : 0;

        if (!ClientRequest::allow($serviceId, time())) {
            ClientRequest::refuse('Too many changes at once. Wait a minute and try again.', 429);
        }
    }

    try {
        ClientRequest::respond(['ok' => true, 'data' => cwp7_clientOperation($operation, $params)]);
    } catch (CwpException $e) {
        // An input refusal is the customer's to fix and says so; it is not a fault worth
        // a Module Log entry. FTP gets a slightly more useful safe diagnostic so the
        // customer is not left staring at a spinner while the technical CWP response
        // remains protected in the Module Log.
        if ($e->getKind() !== CwpException::KIND_INPUT) {
            cwp7_logFailure('ClientArea ' . $operation, $params, $e);
        }

        $clientMessage = $e->getClientMessage();
        if (strpos($operation, 'ftp.') === 0 && $e->getKind() !== CwpException::KIND_INPUT) {
            if ($e->getKind() === CwpException::KIND_API) {
                $clientMessage = 'CWP rejected the FTP request. Check the CWP API Manager permissions for FTP Manager and the WHMCS Module Log for the exact response.';
            } elseif ($e->getKind() === CwpException::KIND_TRANSPORT) {
                $clientMessage = 'The CWP FTP API did not respond. Check connectivity to the CWP API port and the WHMCS Module Log.';
            } elseif ($e->getKind() === CwpException::KIND_PROTOCOL) {
                $clientMessage = 'CWP returned an unexpected response for the FTP request. Check the WHMCS Module Log for the response.';
            }
        }

        ClientRequest::refuse(
            $clientMessage,
            $e->getKind() === CwpException::KIND_INPUT ? 422 : 502
        );
    } catch (\Exception $e) {
        cwp7_logFailure('ClientArea ' . $operation, $params, $e);

        ClientRequest::refuse(CwpException::GENERIC_CLIENT_MESSAGE, 500);
    }
}

/**
 * Route one operation to the class that performs it.
 *
 * @param array<string,mixed> $params
 *
 * @return array<string,mixed>
 *
 * @throws CwpException
 */
function cwp7_featureEnabled($params, $productOption, $serverOption, $default) {
    // Product-level controls are stored by WHMCS as configoptionN.  A populated
    // product option is authoritative; an empty value preserves the server-level
    // setting for existing products that pre-date these controls.
    $map = [
        'client_email_management' => 'configoption16',
        'client_ftp_management' => 'configoption17',
        'client_database_management' => 'configoption18',
        'client_dns_management' => 'configoption19',
    ];
    $field = isset($map[$productOption]) ? $map[$productOption] : '';
    if ($field !== '' && array_key_exists($field, $params) && trim((string) $params[$field]) !== '') {
        $value = strtolower(trim((string) $params[$field]));
        return in_array($value, ['on', 'yes', '1', 'true'], true);
    }

    try {
        return (bool) CwpClient::fromParams($params)->getOption($serverOption, $default);
    } catch (CwpException $e) {
        return $default;
    }
}

function cwp7_clientOperation($operation, $params)
{
    $account = Account::fromParams($params);

    if ($operation === 'dashboard.list') {
        return Dashboard::from($account->detail());
    }

    if (strpos($operation, 'mailbox.') === 0) {
        return cwp7_mailboxOperation($operation, $account, $params);
    }

    if (strpos($operation, 'ftp.') === 0) {
        return cwp7_ftpOperation($operation, $account, $params);
    }

    if (strpos($operation, 'database.') === 0) {
        return cwp7_databaseOperation($operation, $account, $params);
    }

    if (strpos($operation, 'dns.') === 0) {
        $client = CwpClient::fromParams($params);
        $domain = ClientRequest::field($_POST, 'domain');
        $detail = $account->detail();
        $domains = Dashboard::domains($detail);
        $owned = false;
        foreach ($domains as $row) {
            if (is_array($row) && strcasecmp(rtrim((string) (isset($row['domain']) ? $row['domain'] : ''), '.'), rtrim($domain, '.')) === 0) {
                $owned = true;
                break;
            }
        }
        if (!$owned) {
            throw CwpException::input('That domain is not owned by this CWP hosting account.');
        }

        $settings = Dns::serverSettings($client, $params);
        $delegation = Dns::delegation(
            $domain,
            $settings['nameservers'],
            $settings['ips'],
            $settings['require_ip_match']
        );

        if ($operation === 'dns.list') {
            return $delegation;
        }
        if (!$delegation['ready']) {
            throw CwpException::input('DNS record management is available only after delegation verification passes.');
        }

        if ($operation === 'dns.records') {
            $names = [];
            foreach (Dashboard::subdomains($detail) as $row) {
                if (is_array($row) && isset($row['name'])) {
                    $names[] = (string) $row['name'];
                }
            }

            // When the verified CWP Zone Editor session is available, use its actual
            // User Defined Records table as the authoritative inventory. The previous
            // public-DNS implementation could only discover selected/common hostnames
            // and therefore missed valid zone records such as localhost, www.<subdomain>
            // and custom records that are not currently resolvable.
            $editor = new ZoneEditor($client, $params);
            $zoneRecords = [];
            $zoneEditorConfigured = $editor->configured();
            if ($zoneEditorConfigured) {
                try {
                    $zone = $editor->parse($domain);
                    $zoneRecords = isset($zone['records']) && is_array($zone['records'])
                        ? $zone['records']
                        : [];
                } catch (\Exception $e) {
                    $zoneRecords = [];
                    logModuleCall('cwp7', 'dns.records.zone_editor', [
                        'serviceid' => (isset($params['serviceid']) ? $params['serviceid'] : 0),
                        'domain' => $domain,
                    ], $e->getMessage());
                }
            }

            if ($zoneRecords !== []) {
                $zoneRecords = Dns::deduplicateZoneEditorRecords($zoneRecords);
                return array_merge($delegation, [
                    'domain' => $domain,
                    'records' => $zoneRecords,
                    'queried_names' => [$domain],
                    'source' => 'cwp_zone_editor',
                    'read_only' => true,
                    'cwp_zone_editor_verified' => true,
                    'zone_editor_configured' => true,
                    'management_enabled' => cwp7_featureEnabled($params, 'client_dns_management', 'dns_management', true),
                ]);
            }

            // Safe fallback while the Zone Editor transport is unavailable.
            return array_merge($delegation, Dns::publishedRecords($domain, $names), [
                'zone_editor_configured' => $zoneEditorConfigured,
                'management_enabled' => cwp7_featureEnabled($params, 'client_dns_management', 'dns_management', true),
            ]);
        }

        if (!cwp7_featureEnabled($params, 'client_dns_management', 'dns_management', true)) {
            throw CwpException::input('DNS record changes are disabled for this service.');
        }

        $editor = new ZoneEditor($client, $params);
        if ($operation === 'dns.zone') {
            return $editor->parse($domain);
        }
        if ($operation === 'dns.add') {
            $type = strtoupper(ClientRequest::field($_POST, 'type', 'TXT'));
            if ($type !== 'TXT') {
                throw CwpException::input('This release enables DNS creation for TXT records only; other CWP record types will be enabled after their live Zone Editor contracts are verified.');
            }
            $ttl = (int) ClientRequest::field($_POST, 'ttl', '300');
            $result = $editor->addTxt($domain, ClientRequest::field($_POST, 'name', '@'), $ttl, ClientRequest::field($_POST, 'value'));
            $client->clearReadCache();
            return $result;
        }
        if ($operation === 'dns.edit') {
            $lineNumber = (int) ClientRequest::field($_POST, 'line_number');
            return $editor->edit($domain, $lineNumber, ClientRequest::field($_POST, 'line'));
        }
        if ($operation === 'dns.delete') {
            $lineNumber = (int) ClientRequest::field($_POST, 'line_number');
            return $editor->delete($domain, $lineNumber, ClientRequest::field($_POST, 'line'));
        }
    }

    throw CwpException::input('That request was not understood.');
}

/**
 * Mailbox operations.
 *
 * Listing is available whenever the key can read it. Everything that changes a mailbox
 * is behind `mailbox_management`, off by default: the field names CWP expects on add,
 * udp and del have not been confirmed against its Interactive Documentation, and a
 * half-right write request is worse than none.
 *
 * @param array<string,mixed> $params
 *
 * @return array<string,mixed>
 *
 * @throws CwpException
 */
function cwp7_mailboxOperation($operation, Account $account, $params)
{
    $client = CwpClient::fromParams($params);
    $mailbox = new Mailbox($client, $account->resolveUsername());

    if ($operation === 'mailbox.list') {
        $manageable = cwp7_featureEnabled($params, 'client_email_management', 'mailbox_management', true);

        return [
            'mailboxes' => $mailbox->all(),
            'manageable' => $manageable,
        ];
    }

    if (!cwp7_featureEnabled($params, 'client_email_management', 'mailbox_management', true)) {
        throw CwpException::input('Mailboxes cannot be changed from here on this server.');
    }

    $address = ClientRequest::field($_POST, 'address');

    if ($operation === 'mailbox.create') {
        return ['address' => $mailbox->create(
            $account->detail(),
            ClientRequest::field($_POST, 'mailbox'),
            ClientRequest::field($_POST, 'domain'),
            ClientRequest::field($_POST, 'password')
        )];
    }

    if ($operation === 'mailbox.update') {
        $mailbox->update(
            $mailbox->all(),
            $address,
            ClientRequest::field($_POST, 'password'),
            ClientRequest::field($_POST, 'quota')
        );

        return ['address' => $address];
    }

    if ($operation === 'mailbox.delete') {
        $mailbox->delete($mailbox->all(), $address);

        return ['address' => $address];
    }

    throw CwpException::input('That request was not understood.');
}

/**
 * FTP operations shared by the client portal and admin diagnostics.
 *
 * The account is always resolved from the WHMCS service; request fields never select an
 * arbitrary CWP account.
 *
 * @throws CwpException
 */
function cwp7_ftpOperation($operation, Account $account, $params)
{
    $client = CwpClient::fromParams($params);
    $ftp = new Ftp($client, $account->resolveUsername());

    if ($operation === 'ftp.list') {
        return [
            'accounts' => $ftp->all(),
            'manageable' => cwp7_featureEnabled($params, 'client_ftp_management', 'ftp_management', true),
        ];
    }

    if (!cwp7_featureEnabled($params, 'client_ftp_management', 'ftp_management', true)) {
        throw CwpException::input('FTP accounts cannot be changed from here on this server.');
    }

    $existing = $ftp->all();
    if ($operation === 'ftp.create') {
        $address = $ftp->create(
            $account->detail(),
            ClientRequest::field($_POST, 'username'),
            ClientRequest::field($_POST, 'domain'),
            ClientRequest::field($_POST, 'password'),
            ClientRequest::field($_POST, 'path')
        );
        return ['username' => $address];
    }

    if ($operation === 'ftp.update') {
        $ftp->update($existing, ClientRequest::field($_POST, 'username'), ClientRequest::field($_POST, 'password'), ClientRequest::field($_POST, 'path'));
        return ['username' => ClientRequest::field($_POST, 'username')];
    }

    if ($operation === 'ftp.delete') {
        $ftp->delete($existing, ClientRequest::field($_POST, 'username'));
        return ['username' => ClientRequest::field($_POST, 'username')];
    }

    throw CwpException::input('That request was not understood.');
}

/**
 * MySQL database operations shared by the client portal and admin diagnostics.
 *
 * CWP exposes MySQL databases through databasemysql. Database-user management
 * is intentionally deferred because this CWP installation currently returns an
 * HTTP 500 from usermysql/list. The hosting account is always resolved from the
 * WHMCS service.
 *
 * @throws CwpException
 */
function cwp7_databaseOperation($operation, Account $account, $params)
{
    $client = CwpClient::fromParams($params);
    $database = new \Cwp7\Actions\Database($client, $account->resolveUsername());

    if ($operation === 'database.list') {
        // Database listing is intentionally read-only for this release.
        // Do not call usermysql/list because the target CWP installation
        // returns HTTP 500 (Undefined variable: arrayuser).
        return [
            'databases' => $database->databases(),
            'manageable' => false,
        ];
    }

    if (!cwp7_featureEnabled($params, 'client_database_management', 'database_management', true)) {
        throw CwpException::input('Databases cannot be changed from here on this server.');
    }

    if ($operation === 'database.create') {
        return ['database' => $database->createDatabase(ClientRequest::field($_POST, 'database'))];
    }

    if ($operation === 'database.delete') {
        $name = ClientRequest::field($_POST, 'database');
        $database->deleteDatabase($name);
        return ['database' => $name];
    }

    if ($operation === 'database.user.create') {
        return ['username' => $database->createUser(
            ClientRequest::field($_POST, 'username'),
            ClientRequest::field($_POST, 'password'),
            ClientRequest::field($_POST, 'database'),
            ClientRequest::field($_POST, 'host', 'localhost')
        )];
    }

    if ($operation === 'database.user.delete') {
        $name = ClientRequest::field($_POST, 'username');
        $database->deleteUser($name, ClientRequest::field($_POST, 'host', 'localhost'));
        return ['username' => $name];
    }

    throw CwpException::input('That request was not understood.');
}

/**
 * Account detail on the admin service page. Calls CWP on render; a failure degrades to
 * a single line rather than an exception.
 *
 * @param array<string,mixed> $params
 *
 * @return array<string,string>
 */
function cwp7_AdminServicesTabFields($params)
{
    // A terminated service has no account to describe, so the call would fail every
    // time this page is opened.
    $status = strtolower(trim((string) (isset($params['status']) ? $params['status'] : '')));

    if (in_array($status, ['terminated', 'cancelled', 'canceled', 'fraud'], true)) {
        return ['CWP Account' => '<em>Service is ' . htmlspecialchars($status, ENT_QUOTES, 'UTF-8')
            . '. No CWP account is expected.</em>'];
    }

    try {
        $client = CwpClient::fromParams($params);
        $detail = Account::fromParams($params)->detail();
    } catch (CwpException $e) {
        // A missing account is an ordinary state, not a fault worth a red banner.
        if (stripos($e->getMessage(), 'does not exist') !== false) {
            return ['CWP Account' => '<em>No account with this username exists on the server.</em>'];
        }

        return ['CWP Account' => '<span class="label label-danger">'
            . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</span>'];
    } catch (\Exception $e) {
        cwp7_logFailure('AdminServicesTabFields', $params, $e);

        return ['CWP Account' => '<em>Unavailable.</em>'];
    }

    // accountdetail nests the figures under account_info; older shapes are flat.
    $info = (isset($detail['account_info']) && is_array($detail['account_info']))
        ? $detail['account_info']
        : $detail;

    $lines = [];

    $domain = '';
    if (isset($detail['domains'][0]['domain'])) {
        $domain = (string) $detail['domains'][0]['domain'];
    } elseif (isset($detail['domain'])) {
        $domain = (string) $detail['domain'];
    }

    if ($domain !== '') {
        $lines[] = '<strong>Domain:</strong> ' . htmlspecialchars($domain, ENT_QUOTES, 'UTF-8');
    }

    $package = (string) Usage::pick($info, ['package_name', 'package', 'plan']);
    if ($package !== '') {
        $id = (string) Usage::pick($info, ['package_id']);
        $lines[] = '<strong>Package:</strong> ' . htmlspecialchars($package, ENT_QUOTES, 'UTF-8')
            . ($id !== '' ? ' (#' . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . ')' : '');
    }

    foreach (['state' => 'State', 'directory' => 'Home', 'email' => 'Contact', 'ip_address' => 'IP'] as $key => $label) {
        $value = (string) Usage::pick($info, [$key]);
        if ($value !== '') {
            $lines[] = '<strong>' . $label . ':</strong> ' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
        }
    }

    $fields = [];
    $fields['CWP Account'] = $lines === [] ? '<em>No detail returned.</em>' : implode('<br>', $lines);

    $diskUsed = Usage::pick($info, Usage::FIELD_CANDIDATES['diskusage']);
    $diskLimit = Usage::pick($info, Usage::FIELD_CANDIDATES['disklimit']);
    if ($diskUsed !== null || $diskLimit !== null) {
        $fields['Disk'] = cwp7_formatUsage($diskUsed, $diskLimit);
    }

    $bwUsed = Usage::pick($info, ['bandwidth_used', 'bwusage', 'bw_used']);
    $bwLimit = Usage::pick($info, ['bwlimit', 'bandwidth_limit', 'bandwidth']);
    if ($bwUsed !== null || $bwLimit !== null) {
        $fields['Bandwidth'] = cwp7_formatUsage($bwUsed, $bwLimit);
    }

    // CWP spells this key "subdomins" on accountdetail; accept both.
    $counts = [
        'Domains' => ['domains'],
        'Subdomains' => ['subdomains', 'subdomins'],
        'Databases' => ['databases'],
        'Email Accounts' => ['email_accounts', 'emails', 'mailboxes'],
        'FTP Accounts' => ['ftp_accounts', 'ftp'],
        'Addon Domains' => ['addon_domains', 'addons_domains'],
    ];

    foreach ($counts as $label => $keys) {
        foreach ($keys as $key) {
            if (isset($detail[$key]) && is_array($detail[$key])) {
                $fields[$label] = (string) count($detail[$key]);
                break;
            }
        }
    }

    // Keep the admin view and the client portal aligned: these are the sections currently
    // backed by verified, read-only accountdetail/email APIs. New CWP APIs are added only
    // after their request/response contract has been verified.
    $fields['Client Portal'] = '<strong>Available:</strong> Overview, Email, Domains, Subdomains, Databases, DNS delegation verification<br>'
        . '<strong>Email management:</strong> '
        . (cwp7_featureEnabled($params, 'client_email_management', 'mailbox_management', true) ? 'Enabled' : 'Read-only');

    // The admin service tab intentionally mirrors the first client-facing management
    // feature. This makes testing a new portal feature possible from the WHMCS admin
    // side without asking the developer to compare two unrelated data paths.
    try {
        $mailboxes = (new \Cwp7\Actions\Mailbox($client, Account::fromParams($params)->resolveUsername()))->all();
        $preview = [];
        foreach (array_slice($mailboxes, 0, 10) as $mailbox) {
            $address = isset($mailbox['address']) ? (string) $mailbox['address'] : '';
            if ($address === '') {
                continue;
            }
            $used = isset($mailbox['used']) && $mailbox['used'] !== null ? (string) $mailbox['used'] . ' MB' : '';
            $quota = isset($mailbox['quota']) && $mailbox['quota'] !== null ? (string) $mailbox['quota'] . ' MB' : 'unlimited';
            // This value is returned as an HTML fragment by WHMCS. Use an HTML entity
            // for the em dash rather than a literal UTF-8 dash so the admin service tab
            // remains correct even when a legacy WHMCS output path decodes the fragment
            // with a non-UTF-8 character set.
            $preview[] = htmlspecialchars($address, ENT_QUOTES, 'UTF-8')
                . ' &mdash; ' . htmlspecialchars($used, ENT_QUOTES, 'UTF-8')
                . ' / ' . htmlspecialchars($quota, ENT_QUOTES, 'UTF-8');
        }
        $more = count($mailboxes) > 10 ? '<br><em>Showing first 10 of ' . count($mailboxes) . '.</em>' : '';
        $fields['Email Preview'] = $preview === [] ? '<em>No email accounts.</em>' : implode('<br>', $preview) . $more;

        $totalUsed = 0.0;
        $totalQuota = 0.0;
        $quotaKnown = false;
        foreach ($mailboxes as $mailboxRow) {
            if (isset($mailboxRow['used']) && $mailboxRow['used'] !== null) {
                $totalUsed += (float) $mailboxRow['used'];
            }
            if (isset($mailboxRow['quota']) && $mailboxRow['quota'] !== null) {
                $totalQuota += (float) $mailboxRow['quota'];
                $quotaKnown = true;
            }
        }
        $fields['Email Summary'] = '<strong>Mailboxes:</strong> ' . count($mailboxes)
            . '<br><strong>Total used:</strong> ' . number_format($totalUsed, 1) . ' MB'
            . '<br><strong>Known quota:</strong> ' . ($quotaKnown ? number_format($totalQuota, 1) . ' MB' : 'unlimited / mixed');
        $fields['Email Webmail'] = '<a href="'
            . htmlspecialchars($client->getWebmailUrl(), ENT_QUOTES, 'UTF-8')
            . '" target="_blank" rel="noopener noreferrer">Open Webmail Login</a>';
    } catch (CwpException $e) {
        $fields['Email Preview'] = '<em>Unavailable.</em>';
        $fields['Email Summary'] = '<em>Unavailable.</em>';
    } catch (\Exception $e) {
        cwp7_logFailure('AdminEmailPreview', $params, $e);
        $fields['Email Preview'] = '<em>Unavailable.</em>';
        $fields['Email Summary'] = '<em>Unavailable.</em>';
    }

    try {
        $account = Account::fromParams($params);
        $ftpRows = (new Ftp(CwpClient::fromParams($params), $account->resolveUsername()))->all();
        $ftpPreview = [];
        foreach (array_slice($ftpRows, 0, 10) as $row) {
            $ftpPreview[] = htmlspecialchars((string) $row['username'], ENT_QUOTES, 'UTF-8')
                . ' &mdash; ' . htmlspecialchars((string) $row['path'], ENT_QUOTES, 'UTF-8');
        }
        $fields['FTP Preview'] = $ftpPreview === [] ? '<em>No FTP accounts.</em>' : implode('<br>', $ftpPreview);
        $fields['FTP Summary'] = '<strong>FTP accounts:</strong> ' . count($ftpRows)
            . '<br><strong>Management:</strong> ' . (cwp7_featureEnabled($params, 'client_ftp_management', 'ftp_management', true) ? 'Enabled' : 'Read-only');
    } catch (\Exception $e) {
        cwp7_logFailure('AdminFtpPreview', $params, $e);
        $fields['FTP Preview'] = '<em>Unavailable.</em>';
        $fields['FTP Summary'] = '<em>Unavailable.</em>';
    }

    try {
        $db = new \Cwp7\Actions\Database($client, Account::fromParams($params)->resolveUsername());
        $dbRows = $db->databases();
        $dbPreview = [];
        foreach (array_slice($dbRows, 0, 10) as $row) {
            $dbPreview[] = htmlspecialchars((string) $row['database'], ENT_QUOTES, 'UTF-8');
        }
        $fields['Database Preview'] = $dbPreview === [] ? '<em>No databases.</em>' : implode('<br>', $dbPreview);
        $fields['Database Summary'] = '<strong>Databases:</strong> ' . count($dbRows)
            . '<br><strong>Management:</strong> ' . (cwp7_featureEnabled($params, 'client_database_management', 'database_management', true) ? 'Enabled' : 'Read-only');
    } catch (\Exception $e) {
        cwp7_logFailure('AdminDatabasePreview', $params, $e);
        $fields['Database Preview'] = '<em>Unavailable.</em>';
        $fields['Database Summary'] = '<em>Unavailable.</em>';
    }

    // DNS starts with delegation, not with the CWP zone. Only when the domain is
    // delegated to this WHMCS server's configured nameservers should the next release
    // expose the CWP zone/record editor.
    try {
        $dnsDomains = \Cwp7\Actions\Dashboard::domains($detail);
        $dnsPreview = [];
        $dnsSettings = Dns::serverSettings($client, $params);
        if ($dnsDomains !== []) {
            // Check only the primary domain on the admin service page. A large CWP
            // account can have many addon/sub domains; doing public DNS lookups for all
            // of them on every WHMCS page render would add unnecessary latency. The client
            // portal checks the exact selected domain on demand.
            $domainName = (string) $dnsDomains[0]['domain'];
            $check = Dns::delegation(
                $domainName,
                $dnsSettings['nameservers'],
                $dnsSettings['ips'],
                $dnsSettings['require_ip_match']
            );
            $label = $check['ready']
                ? '<span class="label label-success">Delegation verified</span>'
                : '<span class="label label-default">' . htmlspecialchars((string) $check['status'], ENT_QUOTES, 'UTF-8') . '</span>';
            $dnsPreview[] = htmlspecialchars($domainName, ENT_QUOTES, 'UTF-8') . ' &mdash; ' . $label;
            if (count($dnsDomains) > 1) {
                $dnsPreview[] = '<em>' . (count($dnsDomains) - 1) . ' additional domain candidate(s) can be checked from the client portal.</em>';
            }
        }
        $fields['DNS Zone Preview'] = $dnsPreview === [] ? '<em>No domain zones reported.</em>' : implode('<br>', $dnsPreview);
        $fields['DNS Summary'] = '<strong>Zone candidates:</strong> ' . count($dnsDomains)
            . '<br><strong>Configured nameservers:</strong> ' . ($dnsSettings['nameservers'] === [] ? 'Not configured' : htmlspecialchars(implode(', ', $dnsSettings['nameservers']), ENT_QUOTES, 'UTF-8'))
            . '<br><strong>Record management:</strong> ' . (cwp7_featureEnabled($params, 'client_dns_management', 'dns_management', true) ? 'Enabled' : 'Read-only')
            . '<br><strong>Zone Editor transport:</strong> ' . ((new ZoneEditor($client, $params))->configured() ? 'Configured for controlled testing' : 'Not configured');
    } catch (\Exception $e) {
        cwp7_logFailure('AdminDnsPreview', $params, $e);
        $fields['DNS Zone Preview'] = '<em>Unavailable.</em>';
        $fields['DNS Summary'] = '<em>Unavailable.</em>';
    }

    // -----------------------------------------------------------------------
    // KPS CWP Manager dashboard and authoritative DNS Zone Manager.
    //
    // These are intentionally rendered through the supported Admin Services Tab
    // mechanism. AdminCustomButtonArray functions are command actions and WHMCS
    // expects success/error from them; returning arbitrary HTML there causes the
    // generic "Module Command Error" seen in the admin area.
    // -----------------------------------------------------------------------
    $esc = static function ($value) {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    };

    $serviceId = (int) (isset($params['serviceid']) ? $params['serviceid'] : 0);
    $serviceDomain = trim((string) (isset($params['domain']) ? $params['domain'] : $domain));
    $serviceUser = trim((string) (isset($params['username']) ? $params['username'] : ''));
    $serverHost = trim((string) (isset($params['serverhostname']) ? $params['serverhostname'] : ''));
    $serverIp = trim((string) (isset($params['serverip']) ? $params['serverip'] : ''));
    $serverPort = trim((string) (isset($params['serverport']) ? $params['serverport'] : '2304'));
    $serviceStatus = trim((string) (isset($params['status']) ? $params['status'] : ''));

    $dashboard = '<div id="kps-cwp-dashboard" style="padding:12px 0;">'
        . '<div style="font-size:18px;font-weight:600;margin-bottom:10px;">KPS CWP Manager Dashboard</div>'
        . '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px;">'
        . '<a class="btn btn-default btn-sm" href="#kps-cwp-dashboard">Dashboard</a>'
        . '<a class="btn btn-default btn-sm" href="#kps-cwp-dns">DNS Zone Manager</a>'
        . '</div>'
        . '<div style="display:flex;flex-wrap:wrap;gap:10px;">'
        . '<div style="min-width:180px;padding:10px;border:1px solid #ddd;background:#fff;"><strong>Service</strong><br>#' . $esc($serviceId) . '</div>'
        . '<div style="min-width:220px;padding:10px;border:1px solid #ddd;background:#fff;"><strong>Domain</strong><br>' . $esc($serviceDomain ?: '—') . '</div>'
        . '<div style="min-width:180px;padding:10px;border:1px solid #ddd;background:#fff;"><strong>CWP Username</strong><br>' . $esc($serviceUser ?: '—') . '</div>'
        . '<div style="min-width:180px;padding:10px;border:1px solid #ddd;background:#fff;"><strong>Status</strong><br>' . $esc($serviceStatus ?: '—') . '</div>'
        . '<div style="min-width:220px;padding:10px;border:1px solid #ddd;background:#fff;"><strong>WHMCS CWP Server</strong><br>' . $esc($serverHost ?: '—') . '</div>'
        . '<div style="min-width:180px;padding:10px;border:1px solid #ddd;background:#fff;"><strong>Server IP</strong><br>' . $esc($serverIp ?: '—') . '</div>'
        . '<div style="min-width:160px;padding:10px;border:1px solid #ddd;background:#fff;"><strong>API Port</strong><br>' . $esc($serverPort ?: '2304') . '</div>'
        . '</div>'
        . '<div style="margin-top:12px;padding:10px;border:1px dashed #ccc;background:#fafafa;">'
        . '<strong>Management:</strong> Email ' . (cwp7_featureEnabled($params, 'client_email_management', 'mailbox_management', true) ? 'Enabled' : 'Read-only')
        . ' &nbsp;|&nbsp; FTP ' . (cwp7_featureEnabled($params, 'client_ftp_management', 'ftp_management', true) ? 'Enabled' : 'Read-only')
        . ' &nbsp;|&nbsp; Database ' . (cwp7_featureEnabled($params, 'client_database_management', 'database_management', true) ? 'Enabled' : 'Read-only')
        . ' &nbsp;|&nbsp; DNS ' . (cwp7_featureEnabled($params, 'client_dns_management', 'dns_management', true) ? 'Enabled' : 'Read-only')
        . '</div>'
        . '</div>';
    $fields['KPS CWP Manager Dashboard'] = $dashboard;

    $dnsHtml = '<div id="kps-cwp-dns" style="padding:12px 0;">'
        . '<div style="font-size:18px;font-weight:600;margin-bottom:8px;">DNS Zone Manager</div>'
        . '<div style="margin-bottom:10px;color:#666;">Authoritative CWP User Defined Records for <strong>' . $esc($serviceDomain) . '</strong>. The zone is read through a short-lived server-side CWP admin session.</div>';

    try {
        if ($serviceDomain !== '') {
            $zoneEditor = new ZoneEditor($client, $params);
            $inventory = $zoneEditor->parse($serviceDomain);
            $records = isset($inventory['records']) && is_array($inventory['records']) ? $inventory['records'] : [];
            $dnsHtml .= '<div style="overflow:auto;margin-bottom:12px;">'
                . '<table class="table table-bordered table-striped" style="margin-bottom:0;">'
                . '<thead><tr><th>Name</th><th>Type</th><th>TTL</th><th>Value</th><th>Line</th></tr></thead><tbody>';
            if ($records === []) {
                $dnsHtml .= '<tr><td colspan="5"><em>No CWP User Defined Records returned.</em></td></tr>';
            } else {
                foreach ($records as $record) {
                    $dnsHtml .= '<tr>'
                        . '<td>' . $esc(isset($record['name']) ? $record['name'] : '') . '</td>'
                        . '<td>' . $esc(isset($record['type']) ? $record['type'] : '') . '</td>'
                        . '<td>' . $esc(isset($record['ttl']) ? $record['ttl'] : '') . '</td>'
                        . '<td style="word-break:break-word;max-width:520px;">' . $esc(isset($record['value']) ? $record['value'] : '') . '</td>'
                        . '<td>' . $esc(isset($record['line_number']) ? $record['line_number'] : '') . '</td>'
                        . '</tr>';
                }
            }
            $dnsHtml .= '</tbody></table></div>';

            $dnsHtml .= '<div style="padding:12px;border:1px solid #ddd;background:#f7f7f7;">'
                . '<strong>Add TXT Record</strong>'
                . '<div style="margin-top:6px;color:#666;">Enter the values below and use the normal WHMCS <strong>Save Changes</strong> button to apply the verified CWP TXT-add operation.</div>'
                . '<div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:10px;align-items:flex-end;">'
                . '<div><label><strong>Name</strong><br><input class="form-control" type="text" name="modulefields[cwp_dns_txt_name]" value="@" style="min-width:150px;"></label></div>'
                . '<div><label><strong>TTL</strong><br><input class="form-control" type="number" name="modulefields[cwp_dns_txt_ttl]" value="14400" min="0" max="2147483647" style="width:140px;"></label></div>'
                . '<div style="flex:1;min-width:280px;"><label><strong>TXT Value</strong><br><input class="form-control" type="text" name="modulefields[cwp_dns_txt_value]" value="" placeholder="Enter TXT value"></label></div>'
                . '<div><label><input type="checkbox" name="modulefields[cwp_dns_txt_apply]" value="1"> Apply TXT change</label></div>'
                . '</div>'
                . '</div>';
        }
    } catch (CwpException $e) {
        $dnsHtml .= '<div class="alert alert-danger"><strong>DNS Zone Manager:</strong> ' . $esc($e->getClientMessage()) . '</div>';
    } catch (\Exception $e) {
        cwp7_logFailure('AdminDnsZoneTab', $params, $e);
        $dnsHtml .= '<div class="alert alert-danger"><strong>DNS Zone Manager:</strong> ' . $esc($e->getMessage()) . '</div>';
    }

    $dnsHtml .= '<div style="margin-top:10px;padding:10px;border:1px dashed #ccc;color:#666;">'
        . '<strong>Safety:</strong> DNS record editing uses the verified CWP Zone Editor contract. Edit/delete controls remain disabled until the exact live line-mapping behavior is verified.</div>'
        . '</div>';
    $fields['DNS Zone Manager'] = $dnsHtml;

    return $fields;
}

/**
 * Handle the optional DNS TXT change submitted through the supported Admin Services Tab save flow.
 *
 * @param array<string,mixed> $params
 * @return void
 */
function cwp7_AdminServicesTabFieldsSave($params)
{
    $moduleFields = isset($_POST['modulefields']) && is_array($_POST['modulefields'])
        ? $_POST['modulefields'] : [];
    if (empty($moduleFields['cwp_dns_txt_apply'])) {
        return;
    }

    $domain = trim((string) ((isset($params['domain']) ? $params['domain'] : '')));
    $name = trim((string) (isset($moduleFields['cwp_dns_txt_name']) ? $moduleFields['cwp_dns_txt_name'] : '@'));
    $ttl = (int) (isset($moduleFields['cwp_dns_txt_ttl']) ? $moduleFields['cwp_dns_txt_ttl'] : 14400);
    $value = trim((string) (isset($moduleFields['cwp_dns_txt_value']) ? $moduleFields['cwp_dns_txt_value'] : ''));
    if ($domain === '' || $value === '') {
        throw new \RuntimeException('DNS TXT change was requested, but the domain or TXT value is empty.');
    }
    if ($ttl < 0 || $ttl > 2147483647) {
        throw new \RuntimeException('DNS TXT TTL is outside the supported range.');
    }

    try {
        $client = CwpClient::fromParams($params);
        (new ZoneEditor($client, $params))->addTxt($domain, $name, $ttl, $value);
    } catch (CwpException $e) {
        cwp7_logFailure('AdminDnsTxtSave', $params, $e);
        throw new \RuntimeException($e->getClientMessage());
    }
}

/**
 * Render "used of limit" in megabytes, treating CWP's -1 as unlimited.
 *
 * @param mixed $used
 * @param mixed $limit
 *
 * @return string
 */
function cwp7_formatUsage($used, $limit)
{
    $usedMb = $used === null ? null : Usage::numeric($used);
    $rawLimit = $limit === null ? null : (float) Usage::numeric($limit);
    $unlimited = ($limit !== null && (float) $limit < 0);

    $parts = [];
    $parts[] = $usedMb === null ? '?' : number_format($usedMb, 0) . ' MB';
    $parts[] = 'of';
    $parts[] = $unlimited || $rawLimit === null || $rawLimit == 0.0
        ? 'unlimited'
        : number_format($rawLimit, 0) . ' MB';

    return htmlspecialchars(implode(' ', $parts), ENT_QUOTES, 'UTF-8');
}

// ---------------------------------------------------------------------------
// Server Sync
// ---------------------------------------------------------------------------

/**
 * Every account CWP knows about, for WHMCS to compare against its own services.
 *
 * @param array<string,mixed> $params
 *
 * @return array<string,mixed>
 */
function cwp7_ListAccounts($params)
{
    try {
        $rows = Account::fromParams($params)->listAll();
    } catch (\Exception $e) {
        cwp7_logFailure('ListAccounts', $params, $e);

        return ['success' => false, 'error' => $e->getMessage()];
    }

    $accounts = [];

    foreach ($rows as $row) {
        $domain = trim((string) Usage::pick($row, ['domain', 'main_domain', 'primary_domain']));
        $username = trim((string) Usage::pick($row, ['username', 'user', 'account']));

        if ($domain === '' && $username === '') {
            continue;
        }

        $accounts[] = [
            'email' => (string) Usage::pick($row, ['email', 'contact_email']),
            'username' => $username,
            'domain' => $domain,
            'uniqueIdentifier' => $domain !== '' ? $domain : $username,
            'product' => (string) Usage::pick($row, ['package', 'package_name', 'plan']),
            'primaryip' => (string) Usage::pick($row, ['ip_address', 'ip', 'server_ips']),
            'created' => cwp7_normaliseDate(Usage::pick($row, ['setup_date', 'created', 'date'])),
            'status' => cwp7_normaliseStatus($row),
        ];
    }

    return ['success' => true, 'accounts' => $accounts];
}

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

/**
 * Run one lifecycle operation and return WHMCS's contract: 'success', or an error
 * message. These surfaces are admin- and cron-facing, so they carry the technical
 * message; client-facing surfaces use CwpException::getClientMessage().
 *
 * @param array<string,mixed> $params
 * @param $work
 *
 * @return string
 */
function cwp7_perform($action, $params, $work)
{
    try {
        $work(Account::fromParams($params));

        return 'success';
    } catch (CwpException $e) {
        cwp7_logFailure($action, $params, $e);

        return cwp7_commandError($e);
    } catch (\Exception $e) {
        cwp7_logFailure($action, $params, $e);

        return 'Unexpected error: ' . $e->getMessage();
    }
}

/**
 * Turn a failure into the string a Module Command shows the admin.
 *
 * @param CwpException $e
 *
 * @return string
 */
function cwp7_commandError($e)
{
    $message = $e->getMessage();
    $context = $e->getContext();
    $errno = isset($context['curl_errno']) ? (int) $context['curl_errno'] : 0;

    if ($e->getKind() === CwpException::KIND_API) {
        if (stripos($message, 'unauthorized') !== false) {
            return $message . "\n\nThe API key is missing the function/action pair shown in "
                . "brackets. Enable it in CWP -> Settings -> API Manager -> edit the key.";
        }

        if (stripos($message, 'valid user') !== false || stripos($message, 'does not exist') !== false) {
            return $message . "\n\nNo account with that username exists on the server.";
        }

        return $message;
    }

    if ($e->getKind() === CwpException::KIND_TRANSPORT && $errno === 28) {
        return $message . "\n\nCWP was reached but did not reply in time. Account creation "
            . "can take minutes on a busy server; raise 'provision_timeout' in config.php. "
            . "Check the server before retrying — CWP may have finished the work anyway.";
    }

    return $message;
}

/**
 * @param array<string,mixed> $params
 * @param $e
 */
function cwp7_logFailure($action, $params, $e)
{
    if (!function_exists('logModuleCall')) {
        return;
    }

    $context = ($e instanceof CwpException) ? $e->getContext() : ['trace' => $e->getTraceAsString()];
    $context['module_version'] = CWP7_MODULE_VERSION;

    logModuleCall(
        'cwp7',
        $action . ' FAILED',
        cwp7_safeParams($params),
        $e->getMessage(),
        $context,
        cwp7_secrets($params)
    );
}

/**
 * The subset of the module parameters that is safe and useful to log.
 *
 * An allow-list, not a block-list. WHMCS passes a `model` parameter holding a whole
 * Eloquent object — the service, its product and the full client record, including the
 * stored password and the customer's postal address — and WHMCS is free to add more
 * parameters in future. Naming what may be logged is the only approach that stays
 * correct as that set grows.
 *
 * @param array<string,mixed> $params
 *
 * @return array<string,mixed>
 */
function cwp7_safeParams($params)
{
    $allowed = [
        'serviceid', 'serverid', 'serverhostname', 'serverip', 'serverport',
        'domain', 'username', 'moduletype', 'action', 'status', 'packageid',
        'configoption1', 'configoption2', 'configoption3', 'configoption4', 'configoption5',
    ];

    $safe = [];

    foreach ($allowed as $key) {
        if (isset($params[$key]) && is_scalar($params[$key])) {
            $safe[$key] = $params[$key];
        }
    }

    if (isset($params['clientsdetails']['email'])) {
        $safe['clientEmail'] = $params['clientsdetails']['email'];
    }

    return $safe;
}

/**
 * Values WHMCS should redact anywhere else they appear in a log entry.
 *
 * @param array<string,mixed> $params
 *
 * @return array<int,string>
 */
function cwp7_secrets($params)
{
    $secrets = [];

    foreach (['serveraccesshash', 'serverpassword', 'password'] as $key) {
        if (isset($params[$key]) && is_string($params[$key]) && $params[$key] !== '') {
            $secrets[] = $params[$key];
        }
    }

    // A mailbox password submitted from the client area never reaches $params, so it
    // would not be masked by the loop above. Failing to add a new password field here
    // is how one ends up in the Module Log.
    foreach (['password', 'confirm'] as $key) {
        if (isset($_POST[$key]) && is_string($_POST[$key]) && $_POST[$key] !== '') {
            $secrets[] = $_POST[$key];
        }
    }

    return $secrets;
}

/**
 * Map a failure to its most likely cause.
 *
 * @param CwpException $e
 *
 * @return string
 */
function cwp7_troubleshootingHint($e)
{
    $context = $e->getContext();
    $errno = isset($context['curl_errno']) ? (int) $context['curl_errno'] : 0;

    switch ($e->getKind()) {
        case CwpException::KIND_TRANSPORT:
            if ($errno === 6) {
                return "The hostname did not resolve. Check the spelling on the server entry, "
                    . "and that this WHMCS server can resolve it — DNS here may differ from DNS "
                    . "on your workstation.";
            }

            if ($errno === 7) {
                return "The connection was refused or unreachable — nothing answered on 2304, "
                    . "so TLS and the API key are not involved yet.\n"
                    . "Most likely causes:\n"
                    . "  1. This hostname resolves to a different address from the WHMCS server "
                    . "than it does elsewhere (split-horizon DNS, or a NAT gateway with no port "
                    . "forward). The resolved address is named in the error above.\n"
                    . "  2. Outbound 2304 is blocked on the WHMCS server itself. On CSF, add 2304 "
                    . "to TCP_OUT — its DROP_OUT default is REJECT, which produces exactly this "
                    . "instant refusal.\n"
                    . "  3. Inbound 2304 is not open on the CWP server, or cwpsrv is not listening.";
            }

            if ($errno === 28) {
                return "The connection timed out — packets are being dropped rather than refused, "
                    . "which usually means a firewall between here and CWP is discarding them. "
                    . "Check inbound 2304 on the CWP server and any firewall in front of it.";
            }

            return "Most likely causes:\n"
                . "  1. Port 2304 is not open from this WHMCS server's IP.\n"
                . "  2. The CWP firewall is blocking this IP.\n"
                . "  3. TLS verification is failing — check the certificate on the API port.";

        case CwpException::KIND_API:
            return "Most likely causes:\n"
                . "  1. This WHMCS server's IP is not in the API key's IP whitelist "
                . "(CWP -> Settings -> API Manager). On a routed LAN, CWP sees the private "
                . "address, not your public IP.\n"
                . "  2. The Access Hash does not match the CWP API key.\n"
                . "  3. The key lacks LIST permission on Type Server and Account.";

        case CwpException::KIND_CONFIG:
            return "Check the server entry's hostname and Access Hash, and confirm the API key's "
                . "response format is set to JSON.";

        default:
            return "Confirm the API key exists, is active, and has this WHMCS server's IP "
                . "whitelisted in CWP -> Settings -> API Manager.";
    }
}

/**
 * @param mixed $value
 *
 * @return string Y-m-d H:i:s, or '' when nothing parseable was supplied.
 */
function cwp7_normaliseDate($value)
{
    if ($value === null || $value === '') {
        return '';
    }

    if (is_numeric($value)) {
        return date('Y-m-d H:i:s', (int) $value);
    }

    $timestamp = strtotime((string) $value);

    return $timestamp === false ? '' : date('Y-m-d H:i:s', $timestamp);
}

/**
 * Map CWP's status vocabulary onto WHMCS's.
 *
 * @param array<string,mixed> $row
 *
 * @return string
 */
function cwp7_normaliseStatus($row)
{
    $active = class_exists('\WHMCS\Service\Status') ? \WHMCS\Service\Status::ACTIVE : 'Active';
    $suspended = class_exists('\WHMCS\Service\Status') ? \WHMCS\Service\Status::SUSPENDED : 'Suspended';

    // An explicit flag wins. array_key_exists, not isset: "0" means active.
    foreach (['suspended', 'is_suspended', 'susp'] as $key) {
        if (array_key_exists($key, $row)) {
            $flag = strtolower(trim((string) $row[$key]));

            return in_array($flag, ['1', 'yes', 'true', 'on', 'suspended'], true) ? $suspended : $active;
        }
    }

    $status = strtolower(trim((string) Usage::pick($row, ['status', 'state', 'account_status'])));

    if ($status === '') {
        return $active;
    }

    // Specific stems only: a loose substring test reads "unlocked" as suspended.
    foreach (['susp', 'disab', 'inactive'] as $stem) {
        if (strpos($status, $stem) !== false) {
            return $suspended;
        }
    }

    return $active;
}
