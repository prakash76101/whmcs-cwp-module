<?php
/**
 * CWP Hosting Module for WHMCS — optional server-scoped settings.
 *
 * Copy to config.php to use. Without it the module runs on the defaults below, so most
 * installations need no config.php at all. Keeping your copy under a different name to
 * this sample means module upgrades never overwrite it.
 *
 * Credentials do not belong here. The API key is the server entry's Access Hash, which
 * WHMCS stores encrypted.
 *
 * @package cwp7
 * @version 3.0.42
 * @license MIT
 * @link    https://github.com/bradleygb/whmcs-cwp-module
 */

return [

    'defaults' => [

        /** CWP external API port. Overridden by the port on the server entry, if set. */
        'api_port' => 2304,

        /** CWP end-user panel port (2082 plain, 2083 SSL). */
        'panel_port' => 2083,

        /** CWP admin panel port (2030 plain, 2031 SSL; 2086/2087 are the alternates). */
        'admin_port' => 2031,

        /** CWP Webmail port (2095 plain, 2096 SSL). Used only for a customer shortcut. */
        'webmail_port' => 2096,

        /**
         * Verify the CWP TLS certificate.
         *
         * This connection carries an API key with administrative scope over every
         * account on the server. With verification off, anything able to intercept it
         * can present its own certificate and take that key.
         *
         * If CWP serves a certificate from a public CA on the API port, this works as
         * shipped. If it serves a self-signed certificate, export it and set
         * 'ca_bundle' rather than turning this off.
         */
        'verify_tls' => true,

        /**
         * Absolute path to a CA bundle or a pinned self-signed certificate (PEM).
         * null uses the system CA store.
         */
        'ca_bundle' => null,

        /** Seconds to establish the connection. */
        'connect_timeout' => 5,

        /** Seconds for a read (action=list). Some of these run during a page render. */
        'timeout' => 20,

        /**
         * Seconds for anything that changes the server: create, suspend, terminate,
         * package and password changes.
         *
         * Creating an account builds a user, home directory, vhost, DNS zone and mail
         * configuration, which takes far longer than a read. CWP also keeps working after
         * a client gives up, so too short a budget leaves an account on the server and a
         * failed service in WHMCS.
         */
        'provision_timeout' => 180,

        /**
         * Seconds allowed for the CWP FTP Manager add request. FTP creation is a
         * customer-management operation, not a full account provisioning operation, so
         * it should not leave the browser waiting for the 180-second provisioning budget.
         * After a timeout the module checks ftp/list to see whether CWP completed the add.
         */
        'ftp_create_timeout' => 15,
    // Maximum seconds for each post-create ftp/list verification request.
    'ftp_verify_timeout' => 5,

        /**
         * Apply a package change to CWP when an admin changes a service's
         * Product/Service and saves, instead of requiring the Change Package button.
         *
         * Off by default: reconfiguring a live hosting account because someone corrected
         * a mis-assigned product record is a surprise. Requires hooks.php, which WHMCS
         * registers when the module is activated — on an existing install, open any cwp7
         * product's Module Settings tab and press Save Changes once.
         */
        'apply_package_on_service_save' => false,

        /**
         * Create or update the CWP package when a product is saved, on every CWP server
         * in that product's server group.
         *
         * Saves building the same package by hand on each server. The product's CWP
         * Package field is the package name — CWP's update endpoint identifies packages
         * by name, and each server assigns its own local id, so a name is the only
         * identifier that stays stable across a group.
         *
         * Off by default, and enabling it is a decision about ownership: WHMCS becomes
         * the source of truth, and a package edited in CWP is overwritten the next time
         * its product is saved.
         *
         * Requires ADD and UPD on Packages in addition to LIST.
         */
        'push_packages_on_product_save' => false,

        /**
         * Use the hostname CWP returns in an autologin URL, rather than rewriting it to
         * the host on the server entry.
         *
         * Off by default: the session token is in the path and query, so rewriting the
         * host keeps the link working while preventing a redirect to any host that was
         * not configured. Turn this on only if the panel certificate is issued to CWP's
         * own FQDN and the redirect must land on it.
         */
        'autologin_trust_returned_host' => false,

        /**
         * Let customers create, delete and re-password their own mailboxes from the
         * client area, rather than only listing them.
         *
         * A new mailbox takes CWP's own default size: its add endpoint accepts a quota
         * and ignores it. The size is set afterwards through Edit, which does apply it.
         *
         * Listing mailboxes does not depend on this and is always available.
         *
         * Requires ADD, UPD and DEL on Emails in addition to LIST.
         */
        'mailbox_management' => true,

        /** Allow client/admin FTP account create, password/path update and delete. */
        'ftp_management' => true,

        /** Allow client/admin database and database-user management. */
        'database_management' => true,

        /** Allow DNS record changes through the controlled CWP Zone Editor transport. */
        'dns_management' => true,

        /**
         * Authoritative nameservers for this CWP server. When left empty, the module automatically
         * reads nameserver1..5 from the WHMCS server record assigned to the hosting service.
         * Set this only when you intentionally want to override the WHMCS server record.
         * Different CWP servers can therefore use different NS pairs without duplicating
         * them in config.php.
         */
        'dns_nameservers' => [],

        /**
         * Optional IP allow-list for the configured nameservers. Leave empty to verify
         * delegation by nameserver names only. When dns_require_nameserver_ip_match is
         * true, every current nameserver must resolve to at least one of these addresses.
         */
        'dns_nameserver_ips' => [],

        /** Require nameserver A/AAAA addresses to match dns_nameserver_ips. */
        'dns_require_nameserver_ip_match' => false,

        /** The CWP Zone Editor host/URL is derived from the WHMCS-assigned server hostname/IP. */
        /**
         * Use the WHMCS server username/password to create a short-lived CWP admin-panel
         * session for each Zone Editor request. The credentials remain in WHMCS and the
         * temporary session cookie is kept in memory only; it is never exposed to the
         * client and is not persisted by the module.
         */
        'dns_zone_editor_auto_login' => true,

        /** Verify TLS on the Zone Editor HTTPS request. Keep true whenever possible. */
        'dns_zone_editor_verify_tls' => true,

        /** Per-request timeout for Zone Editor AJAX calls. */
        'dns_zone_editor_timeout' => 20,

        /**
         * Apply the product's inode, open-file and process limits after a package
         * change, through account/udp.
         *
         * CWP checks that call as `accout_upd`, a broader grant than the package change
         * itself, and some servers refuse it whether or not Account/UPD is granted in
         * API Manager. A refusal is already non-fatal — the package still moves — but it
         * writes a failure to the WHMCS Module Log on every package change.
         *
         * Set to false on such a server to stop making the call. The three limits then
         * come from the CWP package alone and must be set in the panel if they matter.
         */
        'apply_resource_limits' => true,

        /**
         * Read real disk usage during the daily usage import.
         *
         * CWP's account list reports a placeholder rather than actual consumption, so
         * accurate figures need one extra call per account. That call is made only for
         * accounts matching a WHMCS service on the server, so the cost is proportional
         * to services rather than to every account on the box.
         *
         * Set to false on a server with many hundreds of accounts if you would rather
         * have a single cheap call and accept the placeholder figure.
         */
        'usage_detail_lookup' => true,

        /**
         * Send debug=1 with every call, making CWP write request detail to
         * /var/log/cwp/cwp_api.log on the CWP server.
         *
         * WARNING: that log records the API key IN PLAINTEXT, along with account data.
         * The key is administrative over every account on the server, and the file sits
         * outside WHMCS's retention and access controls entirely.
         *
         * Switch this on only to diagnose a specific call, then switch it off, delete
         * the log, and treat the key as disclosed — rotate it. Never leave it on.
         */
        /**
         * Cache successful read calls for this many seconds within one WHMCS request.
         * Set to 0 to disable the read cache. This cache is request-scoped and never
         * persists account data between customers or requests.
         */
        'read_cache_enabled' => true,
        'read_cache_ttl' => 15,

        'debug' => false,
    ],

    /**
     * Per-server overrides, keyed by the hostname or IP on the WHMCS server entry,
     * merged over 'defaults'.
     *
     *   'cwp1.example.com' => [
     *       'ca_bundle' => '/etc/ssl/certs/cwp1-pinned.pem',
     *       'dns_nameservers' => ['ns1.cwp1.example.com', 'ns2.cwp1.example.com'],
     *       'dns_nameserver_ips' => ['203.0.113.10', '203.0.113.11'],
     *       'dns_require_nameserver_ip_match' => true,
     *   ],
     */
    'servers' => [],
];
