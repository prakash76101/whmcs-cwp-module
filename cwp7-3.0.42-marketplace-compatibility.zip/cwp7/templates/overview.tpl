{* CWP Hosting Module for WHMCS - client area portal. *}

<div class="cwp-portal">
    <div class="cwp-portal-head">
        <div>
            <div class="cwp-kicker">CWP HOSTING</div>
            <h3 class="cwp-title">{$username|escape:'html'}{if $serverHostname} <small>on {$serverHostname|escape:'html'}</small>{/if}</h3>
            <p class="cwp-subtitle">Live account information from Control Web Panel.</p>
        </div>
        <div class="cwp-actions">
            {if $ssoUrl}<a href="{$ssoUrl|escape:'html'}" class="btn btn-primary">Log in to Control Panel</a>{/if}
            {if $panelUrl}<a href="{$panelUrl|escape:'html'}" class="btn btn-default" target="_blank" rel="noopener noreferrer">Open Panel Login Page</a>{/if}
            {if $webmailUrl}<a href="{$webmailUrl|escape:'html'}" class="btn btn-default" target="_blank" rel="noopener noreferrer">Open Webmail</a>{/if}
        </div>
    </div>

    {if $dataUrl}
    <div id="cwp-dashboard" data-url="{$dataUrl|escape:'html'}" data-csrf-token="{$csrfToken|escape:'html'}">
        <div class="cwp-loading">Loading CWP account information&hellip;</div>
    </div>
    {/if}
</div>

{literal}
<style>
.cwp-portal { margin-top: 4px; }
.cwp-portal-head { display:flex; align-items:flex-start; justify-content:space-between; gap:18px; padding:4px 0 20px; border-bottom:1px solid rgba(128,128,128,.22); }
.cwp-kicker { font-size:11px; letter-spacing:.12em; opacity:.62; font-weight:600; }
.cwp-title { margin:3px 0 4px; font-size:25px; font-weight:500; }
.cwp-title small { font-size:13px; opacity:.55; font-weight:400; }
.cwp-subtitle { margin:0; color:#777; font-size:13px; }
.cwp-actions { display:flex; gap:7px; flex-wrap:wrap; justify-content:flex-end; }
.cwp-actions .btn { white-space:nowrap; }
.cwp-tabs { display:flex; gap:4px; flex-wrap:wrap; margin:18px 0 20px; border-bottom:1px solid rgba(128,128,128,.2); }
.cwp-tab { border:0; background:transparent; padding:9px 13px; color:#666; border-bottom:3px solid transparent; cursor:pointer; }
.cwp-tab:hover { background:rgba(128,128,128,.06); }
.cwp-tab.active { color:#145d8a; border-bottom-color:#145d8a; font-weight:600; }
.cwp-pane { display:none; }
.cwp-pane.active { display:block; }
.cwp-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr)); gap:12px; margin-bottom:22px; }
.cwp-stat { border:1px solid rgba(128,128,128,.22); border-radius:7px; padding:13px 14px; background:rgba(128,128,128,.025); }
.cwp-stat-label { font-size:10px; letter-spacing:.07em; text-transform:uppercase; opacity:.62; }
.cwp-stat-value { font-size:19px; font-weight:600; line-height:1.3; margin:4px 0 8px; }
.cwp-stat-limit { font-size:12px; font-weight:400; opacity:.58; }
.cwp-track { background:rgba(128,128,128,.18); border-radius:4px; height:5px; overflow:hidden; }
.cwp-fill { background:#287fb3; height:100%; }
.cwp-fill.cwp-over { background:#d9534f; }
.cwp-summary { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:14px; margin-bottom:20px; }
.cwp-card { border:1px solid rgba(128,128,128,.22); border-radius:7px; padding:15px; }
.cwp-card h4 { margin:0 0 10px; font-size:15px; }
.cwp-card dl { margin:0; }
.cwp-card dt { float:left; clear:left; width:42%; font-size:12px; opacity:.62; margin-bottom:6px; }
.cwp-card dd { margin-left:45%; font-size:12px; margin-bottom:6px; word-break:break-word; }
.cwp-panels { display:grid; grid-template-columns:repeat(auto-fit,minmax(330px,1fr)); gap:18px; }
.cwp-panel h4 { margin:0 0 9px; font-size:15px; }
.cwp-panel table { margin-bottom:0; width:100%; }
.cwp-panel td,.cwp-panel th { padding:6px 8px; font-size:13px; word-break:break-word; }
.cwp-scroll { overflow-x:auto; }
.cwp-section-head { display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom:12px; }
.cwp-section-head h3 { margin:0; font-size:18px; }
.cwp-muted { color:#777; font-size:13px; }
.cwp-email-summary { display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:10px; margin-bottom:16px; }
.cwp-email-summary > div { border:1px solid rgba(128,128,128,.22); border-radius:6px; padding:11px 12px; background:rgba(128,128,128,.025); }
.cwp-email-summary span { display:block; font-size:10px; letter-spacing:.07em; opacity:.62; }
.cwp-email-summary strong { display:block; font-size:17px; margin-top:4px; }
.cwp-mailbox-form { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:14px; align-items:end; margin:0 0 18px; padding:15px; border:1px solid rgba(128,128,128,.22); border-radius:7px; background:rgba(128,128,128,.025); }
.cwp-mailbox-form > div:last-child { grid-column:1 / -1; }
.cwp-mailbox-form .cwp-form-actions { display:flex; gap:8px; align-items:center; justify-content:flex-start; }
.cwp-mailbox-form .cwp-password-field { grid-column:1 / -1; }
.cwp-password-wrap { display:flex; align-items:center; gap:6px; width:100%; }
.cwp-password-wrap input { flex:1 1 auto; min-width:0; width:auto; padding-right:10px; }
.cwp-password-wrap .cwp-password-eye { position:static; flex:0 0 38px; width:38px; height:34px; border:1px solid #ccc; border-radius:4px; background:#fff; color:#555; padding:0; display:inline-flex; align-items:center; justify-content:center; font-size:17px; line-height:1; cursor:pointer; }
.cwp-password-wrap .cwp-password-eye:hover { background:#f5f5f5; border-color:#aaa; }
.cwp-password-actions { display:flex; gap:6px; margin-top:7px; align-items:center; }
.cwp-password-actions .btn { white-space:nowrap; }
.cwp-password-eye .cwp-eye-icon { line-height:1; display:block; }
.cwp-mailbox-form label,.cwp-edit label { display:block; font-size:11px; margin-bottom:4px; opacity:.72; }
.cwp-mailbox-form input,.cwp-edit input { width:100%; }
.cwp-at { display:flex; align-items:center; gap:5px; }
.cwp-at span { opacity:.55; }
.cwp-mailbox-filter { max-width:320px; margin-bottom:10px; }
.cwp-row-acts { white-space:nowrap; text-align:right; }
.cwp-row-acts button { margin-left:5px; }
.cwp-edit { padding:12px; background:rgba(128,128,128,.06); }
.cwp-edit-grid { display:grid; grid-template-columns:1fr 1fr auto; gap:10px; align-items:end; }
.cwp-msg { margin:10px 0; padding:9px 12px; border-radius:5px; font-size:13px; }
.cwp-msg-ok { background:rgba(47,158,79,.12); color:#2f9e4f; }
.cwp-msg-bad { background:rgba(212,59,63,.12); color:#d43b3f; }
.cwp-pager { display:flex; align-items:center; gap:10px; margin-top:10px; }
.cwp-pager-at { font-size:12px; opacity:.68; }
.cwp-loading { padding:24px 0; color:#777; }
.cwp-dns-controls { display:flex; align-items:end; gap:10px; flex-wrap:wrap; margin-bottom:14px; }
.cwp-dns-controls > div { min-width:260px; flex:1 1 320px; }
.cwp-dns-status { border:1px solid rgba(128,128,128,.22); border-radius:7px; padding:15px; }
.cwp-dns-status h4 { margin:0 0 10px; font-size:16px; }
.cwp-dns-status dl { margin:0; }
.cwp-dns-status dt { float:left; clear:left; width:32%; font-size:12px; opacity:.62; margin-bottom:7px; }
.cwp-dns-status dd { margin-left:35%; font-size:12px; margin-bottom:7px; word-break:break-word; }
.cwp-dns-list { margin:0; padding-left:18px; }
.cwp-dns-records { margin-top:12px; }
.cwp-dns-records .cwp-scroll { max-height:520px; overflow:auto; }
.cwp-dns-records th,.cwp-dns-records td { font-size:12px; vertical-align:top; }
.cwp-dns-source { font-size:11px; opacity:.7; margin-top:8px; }
.cwp-dns-manage { margin:0 0 14px; padding:13px; border:1px solid rgba(128,128,128,.22); border-radius:7px; background:rgba(128,128,128,.025); }
.cwp-dns-add-grid { display:grid; grid-template-columns:1fr 120px 2fr auto; gap:10px; align-items:end; margin-top:10px; }
.cwp-dns-manage label { display:block; font-size:11px; margin-bottom:4px; opacity:.72; }
@media(max-width:700px){.cwp-dns-add-grid{grid-template-columns:1fr}}
.cwp-feature-note { padding:13px 15px; border:1px dashed rgba(128,128,128,.35); border-radius:7px; color:#777; font-size:13px; }
.cwp-db-summary { display:grid; grid-template-columns:repeat(2,minmax(150px,1fr)); gap:10px; margin-bottom:16px; }
.cwp-db-summary > div { border:1px solid rgba(128,128,128,.22); border-radius:6px; padding:11px 12px; background:rgba(128,128,128,.025); }
.cwp-db-summary span { display:block; font-size:10px; letter-spacing:.07em; opacity:.62; }
.cwp-db-summary strong { display:block; font-size:17px; margin-top:4px; }
.cwp-db-forms { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:14px; margin-bottom:18px; }
.cwp-db-form { padding:15px; border:1px solid rgba(128,128,128,.22); border-radius:7px; background:rgba(128,128,128,.025); }
.cwp-db-form h4 { margin:0 0 12px; font-size:15px; }
.cwp-db-form label { display:block; font-size:11px; margin-bottom:4px; opacity:.72; }
.cwp-db-form .form-group { margin-bottom:10px; }
.cwp-db-form .cwp-form-actions { margin-top:10px; }
.cwp-db-form .cwp-password-field { margin-bottom:10px; }
@media(max-width:700px){.cwp-db-forms{grid-template-columns:1fr}.cwp-db-summary{grid-template-columns:1fr}}
@media(max-width:700px){
  .cwp-portal-head{flex-direction:column}.cwp-actions{justify-content:flex-start}.cwp-mailbox-form{grid-template-columns:1fr}.cwp-mailbox-form > div:last-child,.cwp-mailbox-form .cwp-password-field{grid-column:auto}.cwp-edit-grid{grid-template-columns:1fr}.cwp-card dt{width:45%}.cwp-card dd{margin-left:48%}
}
</style>

<script>
function cwp7InitPortal() {
    var root = document.getElementById('cwp-dashboard');
    if (!root || !window.jQuery) {
        if (root) root.innerHTML = '<div class="cwp-msg cwp-msg-bad">The hosting portal JavaScript could not be loaded. Please reload the page.</div>';
        return;
    }

    var dataUrl = root.getAttribute('data-url');
    var csrfToken = root.getAttribute('data-csrf-token') || '';
    var dashboard = null;
    var mailboxView = { rows: [], manageable: false, filter: '', page: 0 };
    var domains = [];
    var ftpView = { rows: [], manageable: false, page: 0 };
    var databaseView = { databases: [], users: [], manageable: false };
    var MAILBOXES_PER_PAGE = 10;
    var PANEL_ROWS = 8;

    function esc(v) { return jQuery('<div>').text(v === null || v === undefined ? '' : v).html(); }
    function randomPassword(length) {
        length = length || 20;
        var lower = 'abcdefghijkmnopqrstuvwxyz';
        var upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        var digits = '23456789';
        var symbols = '!@#$%^&*_-+=';
        var all = lower + upper + digits + symbols;
        var bytes = new Uint8Array(length);
        if (window.crypto && window.crypto.getRandomValues) {
            window.crypto.getRandomValues(bytes);
        } else {
            for (var i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
        }
        var chars = [
            lower[bytes[0] % lower.length],
            upper[bytes[1] % upper.length],
            digits[bytes[2] % digits.length],
            symbols[bytes[3] % symbols.length]
        ];
        for (var j = 4; j < bytes.length; j++) chars.push(all[bytes[j] % all.length]);
        for (var k = chars.length - 1; k > 0; k--) {
            var n = bytes[k % bytes.length] % (k + 1);
            var tmp = chars[k]; chars[k] = chars[n]; chars[n] = tmp;
        }
        return chars.join('');
    }
    function fillPassword(input, copyButton) {
        var el = jQuery(input);
        el.val(randomPassword(20));
        el.attr('type', 'password');
        var wrap = el.closest('.cwp-password-wrap');
        wrap.find('.cwp-password-eye').attr('aria-pressed','false').attr('aria-label','Show password').attr('title','Show password').html('<span class="cwp-eye-icon" aria-hidden="true">&#128065;</span>');
        if (copyButton) jQuery(copyButton).prop('disabled', false);
    }
    function togglePassword(input, button) {
        var el = jQuery(input);
        if (!el.length) return;
        var visible = el.attr('type') === 'text';
        el.attr('type', visible ? 'password' : 'text');
        var b = jQuery(button);
        b.attr('aria-pressed', visible ? 'false' : 'true');
        b.attr('aria-label', visible ? 'Show password' : 'Hide password');
        b.attr('title', visible ? 'Show password' : 'Hide password');
        b.html('<span class="cwp-eye-icon" aria-hidden="true">&#128065;</span>');
    }
    function copyPassword(input, button) {
        var value = jQuery(input).val() || '';
        if (!value) return;
        var done = function(){ var b=jQuery(button), old=b.text(); b.text('Copied'); setTimeout(function(){b.text(old);},1200); };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(value).then(done).catch(function(){ jQuery(input).focus().select(); });
        } else {
            jQuery(input).focus().select();
            try { document.execCommand('copy'); done(); } catch (e) {}
        }
    }
    function stat(row) {
        var track = row.percent !== null ? '<div class="cwp-track"><div class="cwp-fill' + (row.over ? ' cwp-over' : '') + '" style="width:' + row.percent + '%"></div></div>' : '';
        return '<div class="cwp-stat" title="' + esc(row.text) + '"><div class="cwp-stat-label">' + esc(row.label) + '</div><div class="cwp-stat-value">' + esc(row.usedText) + ' <span class="cwp-stat-limit">of ' + esc(row.limitText) + '</span></div>' + track + '</div>';
    }
    function tabs() {
        return '<div class="cwp-tabs" role="tablist">'
            + '<button type="button" class="cwp-tab active" data-tab="overview">Overview</button>'
            + '<button type="button" class="cwp-tab" data-tab="websites">Websites</button>'
            + '<button type="button" class="cwp-tab" data-tab="email">Email</button>'
            + '<button type="button" class="cwp-tab" data-tab="databases">Databases</button>'
            + '<button type="button" class="cwp-tab" data-tab="ftp">FTP</button>'
            + '<button type="button" class="cwp-tab" data-tab="dns">DNS</button>'
            + '<button type="button" class="cwp-tab" data-tab="backups">Backups</button>'
            + '</div>';
    }
    function pane(id, html, active) { return '<section class="cwp-pane' + (active ? ' active' : '') + '" id="cwp-pane-' + id + '">' + html + '</section>'; }
    function table(title, columns, rows, keys) {
        if (!rows.length) return '<div class="cwp-card"><h4>' + esc(title) + '</h4><div class="cwp-muted">Nothing found.</div></div>';
        var body = rows.slice(0, PANEL_ROWS).map(function(r){ return '<tr>' + keys.map(function(k){ return '<td>' + esc(r[k]) + '</td>'; }).join('') + '</tr>'; }).join('');
        var more = rows.length > PANEL_ROWS ? '<div class="cwp-muted" style="margin-top:8px">Showing first ' + PANEL_ROWS + ' of ' + rows.length + '. Detailed paging will be expanded with the dedicated management API.</div>' : '';
        return '<div class="cwp-card"><h4>' + esc(title) + '</h4><div class="cwp-scroll"><table class="table table-condensed"><thead><tr>' + columns.map(function(c){return '<th>'+esc(c)+'</th>';}).join('') + '</tr></thead><tbody>' + body + '</tbody></table></div>' + more + '</div>';
    }
    function dnsPanel(data) {
        var rows = data.domains || [];
        if (!rows.length) {
            return '<div class="cwp-card"><h4>DNS Management</h4><div class="cwp-muted">No domains were reported by this CWP account.</div></div>';
        }
        var options = rows.map(function(r){ return '<option value="' + esc(r.domain || '') + '">' + esc(r.domain || '') + '</option>'; }).join('');
        return '<div class="cwp-card"><h4>DNS Management</h4>'
            + '<p class="cwp-muted">We first verify that this domain is delegated to the nameservers configured for the CWP server assigned to this hosting service. CWP DNS records are not shown until that check passes.</p>'
            + '<div class="cwp-dns-controls"><div><label style="display:block;font-size:11px;margin-bottom:4px;opacity:.72">Domain</label><select id="cwp-dns-domain" class="form-control input-sm">' + options + '</select></div><button type="button" class="btn btn-default" id="cwp-dns-check">Check DNS Delegation</button></div>'
            + '<div id="cwp-dns-status"><div class="cwp-loading">Checking DNS delegation&hellip;</div></div>'
            + '</div>'
            + '<div class="cwp-feature-note" style="margin-top:12px"><strong>DNS record management remains gated by two checks.</strong><br>First the domain must be delegated to this hosting server. After delegation is verified, the module will use only a verified CWP zone-record interface; it will not guess an undocumented DNS API or modify zone files directly.</div>';
    }

    function dnsStatus(reply) {
        var status = String(reply.status || 'unknown');
        var good = !!reply.ready;
        var label = good ? '<span class="label label-success">Delegation verified</span>' : '<span class="label label-default">' + esc(status.replace(/_/g,' ')) + '</span>';
        var current = (reply.current_nameservers || []).length ? reply.current_nameservers.join(', ') : 'None returned';
        var expected = (reply.expected_nameservers || []).length ? reply.expected_nameservers.join(', ') : 'Not configured';
        var ips = (reply.resolved_nameserver_ips || []).length ? reply.resolved_nameserver_ips.join(', ') : 'Not resolved';
        var html = '<div class="cwp-dns-status"><h4>' + label + '</h4><dl>'
            + '<dt>Domain</dt><dd>' + esc(reply.domain || '-') + '</dd>'
            + '<dt>Expected nameservers</dt><dd>' + esc(expected) + '</dd>'
            + '<dt>Current nameservers</dt><dd>' + esc(current) + '</dd>'
            + '<dt>Resolved NS addresses</dt><dd>' + esc(ips) + '</dd>'
            + '<dt>Result</dt><dd>' + esc(reply.message || '-') + '</dd>'
            + '</dl>';
        if (good) {
            html += '<div class="cwp-feature-note" style="margin-top:12px"><strong>Domain delegation verified.</strong><br>Published DNS records can be inspected. DNS changes are available only when the CWP Zone Editor transport is configured and this service allows DNS management.</div>';
            html += '<div id="cwp-dns-records" class="cwp-dns-records"><div class="cwp-loading">Loading published DNS records&hellip;</div></div>';
        } else if (status === 'not_pointed') {
            html += '<div class="cwp-feature-note" style="margin-top:12px"><strong>Do not edit CWP DNS yet.</strong><br>Changes in the CWP zone will not be authoritative for this domain until its nameservers are fully delegated to this hosting server.</div>';
        }
        return html + '</div>';
    }

    function loadDns() {
        var host = document.getElementById('cwp-dns-status');
        var select = document.getElementById('cwp-dns-domain');
        var button = document.getElementById('cwp-dns-check');
        if (!host || !select) return;
        var domain = select.value || '';
        host.innerHTML = '<div class="cwp-loading">Checking DNS delegation&hellip;</div>';
        if (button) button.disabled = true;
        jQuery.post(dataUrl, {cwpajax:1, cwpop:'dns.list', domain:domain})
            .done(function(reply){
                if (!reply || !reply.ok || !reply.data) {
                    host.innerHTML = '<div class="cwp-msg cwp-msg-bad">' + esc((reply && reply.error) || 'DNS delegation could not be checked right now.') + '</div>';
                    return;
                }
                host.innerHTML = dnsStatus(reply.data);
                if (reply.data.ready) loadDnsRecords(domain);
            })
            .fail(function(xhr){
                var msg = 'DNS delegation could not be checked right now.';
                if (xhr && xhr.status === 403) msg = 'Your session has expired. Please reload the page and try again.';
                host.innerHTML = '<div class="cwp-msg cwp-msg-bad">' + esc(msg) + '</div>';
            })
            .always(function(){ if (button) button.disabled = false; });
    }

    function renderDnsRecords(data) {
        var host = document.getElementById('cwp-dns-records');
        if (!host) return;
        var rows = data.records || [];
        var manageable = !!data.management_enabled && !!data.zone_editor_configured;
        var body = rows.map(function(r){
            return '<tr><td>' + esc(r.name || '@') + '</td><td>' + esc(r.type || '') + '</td><td>' + esc(r.ttl || '') + '</td><td>' + esc(r.priority || 0) + '</td><td style="word-break:break-word">' + esc(r.value || '') + '</td></tr>';
        }).join('');
        var html = '<div class="cwp-card"><div class="cwp-section-head"><h4>Published DNS Records</h4><span class="cwp-muted">' + rows.length + ' record' + (rows.length === 1 ? '' : 's') + '</span></div>';
        if (manageable) {
            html += '<div class="cwp-dns-manage"><div><strong>Add TXT record</strong><div class="cwp-muted">This first CRUD release uses the live CWP Zone Editor contract captured from this server.</div></div><div class="cwp-dns-add-grid"><div><label>Name</label><input id="cwp-dns-add-name" class="form-control input-sm" value="@" placeholder="@ or host"></div><div><label>TTL</label><input id="cwp-dns-add-ttl" class="form-control input-sm" value="300" inputmode="numeric"></div><div><label>Value</label><input id="cwp-dns-add-value" class="form-control input-sm" placeholder="TXT value"></div><div class="cwp-form-actions"><button type="button" id="cwp-dns-add" class="btn btn-primary btn-sm">Add TXT</button></div></div><div id="cwp-dns-msg"></div></div>';
        } else if (data.management_enabled && !data.zone_editor_configured) {
            html += '<div class="cwp-feature-note"><strong>DNS management is enabled but the CWP Zone Editor session could not be established.</strong><br>The module derives the CWP server from the WHMCS-assigned server and creates a short-lived panel session. Check the server hostname, credentials, HTTPS/2087 access, and CWP login response.</div>';
        }
        if (!rows.length) {
            html += '<div class="cwp-muted">No published records were returned for the domain and CWP-known hostnames.</div>';
        } else {
            html += '<div class="cwp-scroll"><table class="table table-condensed"><thead><tr><th>Name</th><th>Type</th><th>Observed TTL</th><th>Priority</th><th>Value</th></tr></thead><tbody>' + body + '</tbody></table></div>';
        }
        var sourceText = data.source === 'cwp_zone_editor' ? 'Source: CWP Zone Editor User Defined Records from the authenticated server-side Zone Editor session. This is the configured zone inventory; read-only display. Record mutations use the same dynamically discovered CWP Zone Editor endpoint.' : 'Source: authoritative/public DNS lookup after successful delegation verification. Duplicate resolver observations are collapsed by name/type/priority/value; TTL is the highest observed resolver TTL. Read-only fallback inventory.';
        html += '<div class="cwp-dns-source">' + sourceText + '</div></div>';
        host.innerHTML = html;
    }

    function loadDnsRecords(domain) {
        var host = document.getElementById('cwp-dns-records');
        if (!host) return;
        host.innerHTML = '<div class="cwp-loading">Loading published DNS records&hellip;</div>';
        jQuery.post(dataUrl, {cwpajax:1, cwpop:'dns.records', domain:domain})
            .done(function(reply){
                if (!reply || !reply.ok || !reply.data) {
                    host.innerHTML = '<div class="cwp-msg cwp-msg-bad">Published DNS records could not be loaded right now.</div>';
                    return;
                }
                renderDnsRecords(reply.data);
            })
            .fail(function(xhr){
                var msg = 'Published DNS records could not be loaded right now.';
                if (xhr && xhr.status === 403) msg = 'Your session has expired. Please reload the page and try again.';
                host.innerHTML = '<div class="cwp-msg cwp-msg-bad">' + esc(msg) + '</div>';
            });
    }

    function renderBase(data) {
        dashboard = data;
        domains = (data.domains || []).map(function(d){return d.domain;});
        root.innerHTML = tabs()
            + pane('overview', '<div class="cwp-grid">' + (data.meters || []).concat(data.allowances || []).map(stat).join('') + '</div>'
                + '<div class="cwp-summary">'
                + '<div class="cwp-card"><h4>Account</h4><dl><dt>Package</dt><dd>' + esc(data.package || '-') + '</dd><dt>Status</dt><dd>' + esc(data.state || '-') + '</dd><dt>Home</dt><dd>' + esc(data.directory || '-') + '</dd></dl></div>'
                + '<div class="cwp-card"><h4>Quick Actions</h4><p style="margin:0 0 7px"><a class="btn btn-primary btn-sm" href="' + esc('{/literal}{$ssoUrl|escape:'html'}{literal}') + '">Log in to Control Panel</a></p><p class="cwp-muted" style="margin:0">Use the tabs below to inspect the account without leaving WHMCS.</p></div>'
                + '</div>', true)
            + pane('websites', '<div class="cwp-panels">' + table('Domains', ['Domain','Document Root'], data.domains || [], ['domain','path']) + table('Subdomains', ['Subdomain','Document Root'], data.subdomains || [], ['name','path']) + '</div>')
            + pane('databases', '<div id="cwp-database-content"><div class="cwp-loading">Loading databases&hellip;</div></div>')
            + pane('email', '<div id="cwp-email-content"><div class="cwp-loading">Loading email accounts&hellip;</div></div>')
            + pane('ftp', '<div id="cwp-ftp-content"><div class="cwp-loading">Loading FTP accounts&hellip;</div></div>')
            + pane('dns', dnsPanel(data))
            + pane('backups', '<div class="cwp-feature-note"><strong>Backups</strong><br>This section will show CWP backup status and restore points after the CWP backup API contract is verified.</div>');
        loadEmail();
        loadFtp();
        loadDatabases();
        loadDns();
    }
    function matchingMailboxes(){
        var q = mailboxView.filter.toLowerCase();
        return !q ? mailboxView.rows : mailboxView.rows.filter(function(m){return String(m.address).toLowerCase().indexOf(q) !== -1;});
    }
    function mailboxList(){
        var rows=matchingMailboxes(), total=rows.length, pages=Math.max(1,Math.ceil(total/MAILBOXES_PER_PAGE));
        mailboxView.page=Math.min(Math.max(mailboxView.page,0),pages-1);
        var from=mailboxView.page*MAILBOXES_PER_PAGE, page=rows.slice(from,from+MAILBOXES_PER_PAGE);
        if(!mailboxView.rows.length) return '<div class="cwp-muted">No email accounts yet.</div>';
        if(!total) return '<div class="cwp-muted">No address matches that.</div>';
        var html='<div class="cwp-scroll"><table class="table table-condensed"><thead><tr><th>Address</th><th>Used</th><th>Quota</th>'+(mailboxView.manageable?'<th></th>':'')+'</tr></thead><tbody>';
        html+=page.map(function(m,i){var a=esc(m.address); return '<tr><td>'+a+'</td><td>'+esc(m.used===null?'':m.used+' MB')+'</td><td>'+esc(m.quota===null?'unlimited':m.quota+' MB')+'</td>'+(mailboxView.manageable?'<td class="cwp-row-acts"><button class="btn btn-default btn-xs cwp-edit-open" data-row="'+i+'">Edit</button><button class="btn btn-danger btn-xs cwp-del" data-address="'+a+'">Delete</button></td>':'')+'</tr>'+(mailboxView.manageable?'<tr id="cwp-edit-'+i+'" style="display:none"><td colspan="4" class="cwp-edit"><div class="cwp-edit-grid"><div><label>New password</label><div class="cwp-password-wrap"><input class="form-control input-sm cwp-edit-pw" type="password" autocomplete="new-password"><button type="button" class="cwp-password-eye" data-input=".cwp-edit-pw" aria-pressed="false" aria-label="Show password" title="Show password"><span class="cwp-eye-icon" aria-hidden="true">&#128065;</span></button></div><div class="cwp-password-actions"><button type="button" class="btn btn-default btn-sm cwp-generate-password" data-input=".cwp-edit-pw">Generate</button><button type="button" class="btn btn-default btn-sm cwp-copy-password" data-input=".cwp-edit-pw">Copy</button></div></div><div><label>Size (MB)</label><input class="form-control input-sm cwp-edit-quota" type="text" placeholder="'+esc(m.quota===null?'unlimited':m.quota)+'"></div><div><button class="btn btn-primary cwp-edit-save" data-address="'+a+'" data-row="'+i+'">Save</button></div></div></td></tr>':'');}).join('');
        html+='</tbody></table></div>';
        if(total>MAILBOXES_PER_PAGE) html+='<div class="cwp-pager"><button class="btn btn-default btn-xs cwp-page" data-step="-1"'+(mailboxView.page===0?' disabled':'')+'>Previous</button><span class="cwp-pager-at">'+(from+1)+'–'+(from+page.length)+' of '+total+'</span><button class="btn btn-default btn-xs cwp-page" data-step="1"'+(mailboxView.page>=pages-1?' disabled':'')+'>Next</button></div>';
        return html;
    }
    function loadEmail(){
        var host=document.getElementById('cwp-email-content'); if(!host) return;
        jQuery.post(dataUrl,{cwpajax:1,cwpop:'mailbox.list'}).done(function(reply){
            if(!reply||!reply.ok){host.innerHTML='<div class="cwp-msg cwp-msg-bad">'+esc((reply&&reply.error)||'Email information is not available right now.')+'</div>';return;}
            mailboxView.rows=reply.data.mailboxes||[]; mailboxView.manageable=!!reply.data.manageable; mailboxView.page=0;
            var form='';
            if(mailboxView.manageable){ form='<div class="cwp-mailbox-form"><div><label>Mailbox</label><input id="cwp-mailbox" class="form-control input-sm" type="text"></div><div><label>Domain</label><select id="cwp-domain" class="form-control input-sm">'+domains.map(function(d){return '<option value="'+esc(d)+'">'+esc(d)+'</option>';}).join('')+'</select></div><div class="cwp-password-field"><label>Password</label><div class="cwp-password-wrap"><input id="cwp-password" class="form-control input-sm" type="password" autocomplete="new-password"><button type="button" class="cwp-password-eye" data-input="#cwp-password" aria-pressed="false" aria-label="Show password" title="Show password"><span class="cwp-eye-icon" aria-hidden="true">&#128065;</span></button></div><div class="cwp-password-actions"><button type="button" class="btn btn-default btn-sm cwp-generate-password" data-input="#cwp-password">Generate</button><button type="button" class="btn btn-default btn-sm cwp-copy-password" data-input="#cwp-password">Copy</button></div></div><div class="cwp-form-actions"><button id="cwp-create" class="btn btn-primary">Create Email</button></div></div>'; }
            var totalUsed=0,totalQuota=0,quotaKnown=false; mailboxView.rows.forEach(function(m){ if(m.used!==null) totalUsed+=Number(m.used)||0; if(m.quota!==null){totalQuota+=Number(m.quota)||0;quotaKnown=true;} });
            var pct=quotaKnown&&totalQuota>0?Math.min(100,Math.round(totalUsed/totalQuota*100)):null;
            var summary='<div class="cwp-email-summary"><div><span>MAILBOXES</span><strong>'+mailboxView.rows.length+'</strong></div><div><span>TOTAL USED</span><strong>'+totalUsed.toFixed(1)+' MB</strong></div><div><span>KNOWN QUOTA</span><strong>'+(quotaKnown?totalQuota.toFixed(1)+' MB':'Unlimited / mixed')+'</strong></div>'+(pct!==null?'<div><span>USAGE</span><strong>'+pct+'%</strong><div class="cwp-track"><div class="cwp-fill'+(pct>=90?' cwp-over':'')+'" style="width:'+pct+'%"></div></div></div>':'')+'</div>';
            if(mailboxView.rows.length){ form+='<div style="margin:-6px 0 12px"><a class="btn btn-default btn-sm" href="'+esc('{/literal}{$webmailUrl|escape:'html'}{literal}')+'" target="_blank" rel="noopener noreferrer">Open Webmail</a></div>'; }
            host.innerHTML=summary+'<div class="cwp-section-head"><h3>Email Accounts</h3><input id="cwp-filter" class="form-control input-sm cwp-mailbox-filter" type="search" placeholder="Search email addresses"></div>'+form+'<div id="cwp-mailbox-msg"></div><div id="cwp-mailbox-list"></div>';
            if(mailboxView.manageable){ fillPassword('#cwp-password'); }
            drawMailboxList();
        }).fail(function(){host.innerHTML='<div class="cwp-msg cwp-msg-bad">Email information is not available right now.</div>';});
    }
    function drawMailboxList(){var h=document.getElementById('cwp-mailbox-list');if(h)h.innerHTML=mailboxList();}
    function say(target,text,good){var id=target==='ftp'?'cwp-ftp-msg':(target==='database'?'cwp-database-msg':(target==='dns'?'cwp-dns-msg':'cwp-mailbox-msg'));var b=document.getElementById(id);if(b)b.innerHTML='<div class="cwp-msg '+(good?'cwp-msg-ok':'cwp-msg-bad')+'>'+esc(text)+'</div>';}
    function send(op,fields,done,target,always){
        target=target||'email';
        fields.cwpajax=1;
        fields.cwpop=op;
        fields.token=csrfToken;
        jQuery.ajax({url:dataUrl,type:'POST',data:fields,dataType:'json',timeout:45000}).done(function(r){
            if(r&&r.ok){
                done(r.data||{});
            }else{
                say(target,(r&&r.error)||'That did not work.',false);
            }
        }).fail(function(x,textStatus){
            var message=(x.responseJSON&&x.responseJSON.error)||((textStatus==='timeout')?(target==='ftp'?'The hosting server did not finish the FTP request within 45 seconds. Check the WHMCS Module Log for the CWP API response.':'The request did not finish within 45 seconds. Check the WHMCS Module Log for the CWP API response.'):'The request could not be completed. HTTP '+(x.status||'error')+'.');
            say(target,message,false);
        }).always(function(){
            if(typeof always==='function') always();
        });
    }

    jQuery(document).on('click','.cwp-generate-password',function(e){
        e.preventDefault();
        var selector=jQuery(this).data('input');
        var input=jQuery(this).closest('.cwp-password-wrap').find('input').first();
        if(!input.length && selector) input=jQuery(selector).first();
        fillPassword(input);
    });
    jQuery(document).on('click','.cwp-password-eye',function(e){
        e.preventDefault();
        var input=jQuery(this).closest('.cwp-password-wrap').find('input').first();
        if(!input.length) input=jQuery(jQuery(this).data('input')).first();
        togglePassword(input,this);
    });
    jQuery(document).on('click','.cwp-copy-password',function(e){
        e.preventDefault();
        var input=jQuery(this).closest('.cwp-password-wrap').find('input').first();
        if(!input.length) input=jQuery(jQuery(this).data('input')).first();
        copyPassword(input,this);
    });
    jQuery(document).on('click','.cwp-tab',function(){var id=jQuery(this).data('tab');jQuery('.cwp-tab').removeClass('active');jQuery(this).addClass('active');jQuery('.cwp-pane').removeClass('active');jQuery('#cwp-pane-'+id).addClass('active');if(id==='email' && !mailboxView.rows.length) loadEmail();if(id==='databases') loadDatabases();});
    jQuery(document).on('input','#cwp-filter',function(){mailboxView.filter=jQuery(this).val()||'';mailboxView.page=0;drawMailboxList();});
    jQuery(document).on('click','.cwp-page',function(){mailboxView.page+=parseInt(jQuery(this).data('step'),10);drawMailboxList();});
    jQuery(document).on('click','#cwp-create',function(){send('mailbox.create',{mailbox:jQuery('#cwp-mailbox').val(),domain:jQuery('#cwp-domain').val(),password:jQuery('#cwp-password').val()},function(d){loadEmail();say('email',d.address+' created.',true);});});
    jQuery(document).on('click','.cwp-edit-open',function(){jQuery('#cwp-edit-'+jQuery(this).data('row')).toggle();});
    jQuery(document).on('click','.cwp-edit-save',function(){var b=jQuery(this),row=jQuery('#cwp-edit-'+b.data('row')),a=b.data('address');send('mailbox.update',{address:a,password:row.find('.cwp-edit-pw').val(),quota:row.find('.cwp-edit-quota').val()},function(){loadEmail();say('email',a+' updated.',true);});});
    jQuery(document).on('click','.cwp-del',function(){var a=jQuery(this).data('address');if(!window.confirm('Delete '+a+'? This cannot be undone.'))return;send('mailbox.delete',{address:a},function(){loadEmail();say('email',a+' deleted.',true);});});

    function databaseSummary(){
        return '<div class="cwp-db-summary"><div><span>DATABASES</span><strong>'+databaseView.databases.length+'</strong></div></div>';
    }
    function databaseForms(){ return ''; }
    function databaseTables(){
        var html='<div class="cwp-panels">';
        if(databaseView.databases.length){
            html+='<div class="cwp-card"><h4>Databases</h4><div class="cwp-scroll"><table class="table table-condensed"><thead><tr><th>Database</th></tr></thead><tbody>';
            html+=databaseView.databases.map(function(d){return '<tr><td>'+esc(d.database)+'</td></tr>';}).join('');
            html+='</tbody></table></div></div>';
        } else { html+='<div class="cwp-card"><h4>Databases</h4><div class="cwp-muted">No databases found for this hosting account.</div></div>'; }
        return html+'</div>';
    }
    function loadDatabases(){
        var host=document.getElementById('cwp-database-content'); if(!host) return;
        jQuery.post(dataUrl,{cwpajax:1,cwpop:'database.list'}).done(function(reply){
            if(!reply||!reply.ok){host.innerHTML='<div class="cwp-msg cwp-msg-bad">'+esc((reply&&reply.error)||'Database information is not available right now.')+'</div>';return;}
            databaseView.databases=reply.data.databases||[]; databaseView.users=[]; databaseView.manageable=false;
            host.innerHTML=databaseSummary()+databaseTables();
        }).fail(function(){host.innerHTML='<div class="cwp-msg cwp-msg-bad">Database information is not available right now.</div>';});
    }
    function databaseSay(text,good){var b=document.getElementById('cwp-database-msg');if(b)b.innerHTML='<div class="cwp-msg '+(good?'cwp-msg-ok':'cwp-msg-bad')+'">'+esc(text)+'</div>';}

    function drawFtp(){
        var host=document.getElementById('cwp-ftp-list'); if(!host) return;
        var rows=ftpView.rows;
        if(!rows.length){host.innerHTML='<div class="cwp-muted">No FTP accounts yet.</div>';return;}
        var html='<div class="cwp-scroll"><table class="table table-condensed"><thead><tr><th>Username</th><th>Path</th>'+(ftpView.manageable?'<th></th>':'')+'</tr></thead><tbody>';
        html+=rows.map(function(m,i){var u=esc(m.username);return '<tr><td>'+u+'</td><td>'+esc(m.path||'/')+'</td>'+(ftpView.manageable?'<td class="cwp-row-acts"><button class="btn btn-default btn-xs cwp-ftp-edit-open" data-row="'+i+'">Edit</button><button class="btn btn-danger btn-xs cwp-ftp-del" data-username="'+u+'">Delete</button></td>':'')+'</tr>'+(ftpView.manageable?'<tr id="cwp-ftp-edit-'+i+'" style="display:none"><td colspan="3" class="cwp-edit"><div class="cwp-edit-grid"><div><label>New password</label><div class="cwp-password-wrap"><input class="form-control input-sm cwp-ftp-pw" type="password" autocomplete="new-password"><button type="button" class="cwp-password-eye" data-input=".cwp-ftp-pw" aria-pressed="false" aria-label="Show password" title="Show password"><span class="cwp-eye-icon" aria-hidden="true">&#128065;</span></button></div><div class="cwp-password-actions"><button type="button" class="btn btn-default btn-sm cwp-generate-password" data-input=".cwp-ftp-pw">Generate</button><button type="button" class="btn btn-default btn-sm cwp-copy-password" data-input=".cwp-ftp-pw">Copy</button></div></div><div><label>Path</label><input class="form-control input-sm cwp-ftp-path" type="text" value="'+esc(m.path||'/public_html')+'"></div><div><button class="btn btn-primary cwp-ftp-save" data-username="'+u+'" data-row="'+i+'">Save</button></div></div></td></tr>':'');}).join('');
        html+='</tbody></table></div>'; host.innerHTML=html;
    }
    function loadFtp(){
        var host=document.getElementById('cwp-ftp-content'); if(!host) return;
        jQuery.post(dataUrl,{cwpajax:1,cwpop:'ftp.list'}).done(function(reply){
            if(!reply||!reply.ok){host.innerHTML='<div class="cwp-msg cwp-msg-bad">'+esc((reply&&reply.error)||'FTP information is not available right now.')+'</div>';return;}
            ftpView.rows=reply.data.accounts||[]; ftpView.manageable=!!reply.data.manageable;
            var form='';
            if(ftpView.manageable){form='<div class="cwp-mailbox-form"><div><label>Username</label><input id="cwp-ftp-user" class="form-control input-sm" type="text"></div><div><label>Domain</label><select id="cwp-ftp-domain" class="form-control input-sm">'+domains.map(function(d){return '<option value="'+esc(d)+'">'+esc(d)+'</option>';}).join('')+'</select></div><div class="cwp-password-field"><label>Password</label><div class="cwp-password-wrap"><input id="cwp-ftp-password" class="form-control input-sm" type="password" autocomplete="new-password"><button type="button" class="cwp-password-eye" data-input="#cwp-ftp-password" aria-pressed="false" aria-label="Show password" title="Show password"><span class="cwp-eye-icon" aria-hidden="true">&#128065;</span></button></div><div class="cwp-password-actions"><button type="button" class="btn btn-default btn-sm cwp-generate-password" data-input="#cwp-ftp-password">Generate</button><button type="button" class="btn btn-default btn-sm cwp-copy-password" data-input="#cwp-ftp-password">Copy</button></div></div><div><label>Path</label><input id="cwp-ftp-path" class="form-control input-sm" type="text" value="/public_html"></div><div class="cwp-form-actions"><button id="cwp-ftp-create" class="btn btn-primary">Create FTP</button></div></div>'; }
            host.innerHTML=form+'<div id="cwp-ftp-msg"></div><div id="cwp-ftp-list"></div>'; drawFtp();
            if(ftpView.manageable){ fillPassword('#cwp-ftp-password'); }
            if(ftpView.manageable){
                var createBtn=jQuery('#cwp-ftp-create');
                createBtn.off('click.cwpFtpCreate').on('click.cwpFtpCreate',function(e){
                    e.preventDefault();
                    var b=jQuery(this);
                    var username=jQuery('#cwp-ftp-user').val();
                    var domain=jQuery('#cwp-ftp-domain').val();
                    var password=jQuery('#cwp-ftp-password').val();
                    var path=jQuery('#cwp-ftp-path').val();
                    if(!username || !domain || !password || !path){
                        say('ftp','Please enter FTP username, domain, password and path.',false);
                        return;
                    }
                    b.prop('disabled',true).text('Creating FTP...');
                    say('ftp','Sending request to CWP and verifying the new account...',true);
                    send('ftp.create',{username:username,domain:domain,password:password,path:path},function(d){
                        loadFtp();
                        say('ftp',(d&&d.username?d.username:'FTP account')+' created.',true);
                    },'ftp',function(){
                        b.prop('disabled',false).text('Create FTP');
                    });
                });
            }
        }).fail(function(){host.innerHTML='<div class="cwp-msg cwp-msg-bad">FTP information is not available right now.</div>';});
    }
    jQuery(document).on('click','#cwp-db-create',function(e){
        e.preventDefault(); var b=jQuery(this), name=jQuery('#cwp-db-name').val();
        if(!name){databaseSay('Enter a database name.',false);return;}
        b.prop('disabled',true).text('Creating...');
        send('database.create',{database:name},function(d){databaseSay((d&&d.database?d.database:'Database')+' created.',true);loadDatabases();},'database',function(){b.prop('disabled',false).text('Create Database');});
    });
    jQuery(document).on('click','#cwp-db-user-create',function(e){
        e.preventDefault(); var b=jQuery(this), username=jQuery('#cwp-db-user').val(), password=jQuery('#cwp-db-password').val(), db=jQuery('#cwp-db-user-db').val(), host=jQuery('#cwp-db-user-host').val();
        if(!username||!password||!db||!host){databaseSay('Enter database username, password, database and host.',false);return;}
        b.prop('disabled',true).text('Creating...');
        send('database.user.create',{username:username,password:password,database:db,host:host},function(d){databaseSay((d&&d.username?d.username:'Database user')+' created.',true);loadDatabases();},'database',function(){b.prop('disabled',false).text('Create Database User');});
    });
    jQuery(document).on('click','.cwp-db-delete',function(e){e.preventDefault();var name=jQuery(this).data('database');if(!window.confirm('Delete '+name+'? This cannot be undone.'))return;send('database.delete',{database:name},function(){databaseSay(name+' deleted.',true);loadDatabases();},'database');});
    jQuery(document).on('click','.cwp-db-user-delete',function(e){e.preventDefault();var name=jQuery(this).data('username'),host=jQuery(this).data('host')||'localhost';if(!window.confirm('Delete database user '+name+'? This cannot be undone.'))return;send('database.user.delete',{username:name,host:host},function(){databaseSay(name+' deleted.',true);loadDatabases();},'database');});
    jQuery(document).on('click','.cwp-ftp-edit-open',function(e){e.preventDefault();jQuery('#cwp-ftp-edit-'+jQuery(this).data('row')).toggle();});
    jQuery(document).on('click','.cwp-ftp-save',function(){var b=jQuery(this),r=jQuery('#cwp-ftp-edit-'+b.data('row'));send('ftp.update',{username:b.data('username'),password:r.find('.cwp-ftp-pw').val(),path:r.find('.cwp-ftp-path').val()},function(){loadFtp();say('ftp',b.data('username')+' updated.',true);},'ftp');});
    jQuery(document).on('click','.cwp-ftp-del',function(){var u=jQuery(this).data('username');if(!window.confirm('Delete '+u+'? This cannot be undone.'))return;send('ftp.delete',{username:u},function(){loadFtp();say('ftp',u+' deleted.',true);},'ftp');});
    jQuery(document).on('click','#cwp-dns-add',function(e){
        e.preventDefault();
        var btn=this, name=document.getElementById('cwp-dns-add-name'), ttl=document.getElementById('cwp-dns-add-ttl'), value=document.getElementById('cwp-dns-add-value'), msg=document.getElementById('cwp-dns-msg'), domain=document.getElementById('cwp-dns-domain');
        if(!name||!ttl||!value||!domain) return;
        msg.innerHTML='<div class="cwp-loading">Saving TXT record&hellip;</div>'; btn.disabled=true;
        send('dns.add',{domain:domain.value,type:'TXT',name:name.value,ttl:ttl.value,value:value.value},function(){
            msg.innerHTML='<div class="cwp-msg cwp-msg-ok">TXT record added successfully. Published DNS may take time to reflect the change.</div>';
            loadDnsRecords(domain.value);
            value.value='';
        },'dns',function(){btn.disabled=false;});
    });
    jQuery(document).on('change','#cwp-dns-domain',function(){loadDns();});
    jQuery(document).on('click','#cwp-dns-check',function(e){e.preventDefault();loadDns();});
    jQuery.ajax({url:dataUrl,type:'POST',data:{cwpajax:1,cwpop:'dashboard.list',token:csrfToken},dataType:'json',timeout:45000}).done(function(reply){if(reply&&reply.ok&&reply.data){renderBase(reply.data);}else{root.innerHTML='<div class="cwp-msg cwp-msg-bad">'+esc((reply&&reply.error)||'Account information is not available right now.')+'</div>';}}).fail(function(xhr,status){var msg='Account information is not available right now.';if(status==='timeout'){msg='The CWP request timed out. Please reload the page and try again.';}else if(xhr&&xhr.status===403){msg='Your session has expired. Please reload the page and try again.';}else if(xhr&&xhr.status>=500){msg='The hosting portal returned an unexpected server response. Check the WHMCS Module Log.';}root.innerHTML='<div class="cwp-msg cwp-msg-bad">'+esc(msg)+'</div>';});
}

if (window.jQuery) {
    cwp7InitPortal();
} else {
    (function () {
        var script = document.createElement('script');
        script.src = 'modules/servers/cwp7/assets/js/jquery-3.6.1.min.js';
        script.onload = cwp7InitPortal;
        script.onerror = function () {
            var root = document.getElementById('cwp-dashboard');
            if (root) root.innerHTML = '<div class="cwp-msg cwp-msg-bad">The hosting portal JavaScript library could not be loaded. Please contact support.</div>';
        };
        document.head.appendChild(script);
    }());
}
</script>
{/literal}
