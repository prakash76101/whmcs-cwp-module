<?php
/**
 * CWP WHMCS Module — read-only API capability detection.
 *
 * This class deliberately probes only endpoints already used by the module. It never
 * sends add/update/delete/suspend requests. A capability is marked supported when the
 * endpoint answers successfully, unavailable when CWP returns a non-transport refusal,
 * and unknown when the request could not reach the API.
 *
 * @package cwp7
 * @version 3.0.23
 */
namespace Cwp7\Diagnostics;

use Cwp7\CwpClient;
use Cwp7\CwpException;

final class Capabilities
{
    /** Only read operations that the current module already relies upon. */
    const PROBES = [
        'core.account_list' => ['function' => 'account', 'action' => 'list'],
        'core.account_detail' => ['function' => 'accountdetail', 'action' => 'list'],
        'core.packages' => ['function' => 'packages', 'action' => 'list'],
        'ftp.list' => ['function' => 'ftp', 'action' => 'list'],
        'database.list' => ['function' => 'databasemysql', 'action' => 'list'],
    ];

    /**
     * Probe every known capability.
     *
     * @return array<string,array<string,mixed>>
     */
    public static function probe(CwpClient $client) {
        $results = [];

        foreach (self::PROBES as $name => $probe) {
            try {
                $client->call($probe['function'], $probe['action']);
                $results[$name] = [
                    'status' => 'supported',
                    'function' => $probe['function'],
                    'action' => $probe['action'],
                    'message' => 'Read request succeeded.',
                ];
            } catch (CwpException $e) {
                $kind = $e->getKind();
                $results[$name] = [
                    'status' => $kind === CwpException::KIND_TRANSPORT ? 'unknown' : 'unavailable',
                    'function' => $probe['function'],
                    'action' => $probe['action'],
                    'message' => self::safeMessage($e),
                ];
            } catch (\Exception $e) {
                $results[$name] = [
                    'status' => 'unknown',
                    'function' => $probe['function'],
                    'action' => $probe['action'],
                    'message' => 'Unexpected diagnostic failure.',
                ];
            }
        }

        return $results;
    }

    /** @param array<string,array<string,mixed>> $results */
    public static function summary($results) {
        $summary = ['supported' => 0, 'unavailable' => 0, 'unknown' => 0, 'total' => count($results)];

        foreach ($results as $result) {
            $status = isset($result['status']) ? (string) $result['status'] : 'unknown';
            if (!isset($summary[$status])) {
                $status = 'unknown';
            }
            $summary[$status]++;
        }

        return $summary;
    }

    /** @param array<string,array<string,mixed>> $results */
    public static function report($results) {
        $lines = [];

        foreach ($results as $name => $result) {
            $status = strtoupper((string) $result['status']);
            $lines[] = $name . ': ' . $status;
        }

        return implode("\n", $lines);
    }

    public static function testConnectionDescription($summary) {
        return sprintf(
            'CWP API reachable. Read capabilities: %d/%d supported, %d unavailable, %d unknown.',
            $summary['supported'],
            $summary['total'],
            $summary['unavailable'],
            $summary['unknown']
        );
    }

    private static function safeMessage(CwpException $e) {
        $message = trim($e->getMessage());
        if ($message === '') {
            return 'CWP returned no diagnostic message.';
        }

        return mb_substr($message, 0, 300);
    }
}
