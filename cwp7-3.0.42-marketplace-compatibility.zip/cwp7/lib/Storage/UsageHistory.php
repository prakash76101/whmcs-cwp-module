<?php
/**
 * CWP Hosting Module for WHMCS — usage history persistence.
 *
 * Stores periodic snapshots separately from tblhosting so WHMCS's current usage
 * columns remain the authoritative live values while the module can build history.
 * The table is created lazily by UsageUpdate, avoiding a dependency on a module
 * activation hook that WHMCS server modules do not consistently expose.
 *
 * @package cwp7
 * @version 2.9.0
 */
namespace Cwp7\Storage;

final class UsageHistory
{
    const TABLE = 'mod_cwp7_usage_history';

    /** Ensure the history table exists. Safe to call on every usage run. */
    public static function ensureTable() {
        if (!class_exists('\WHMCS\Database\Capsule')) {
            return;
        }

        $schema = \WHMCS\Database\Capsule::schema();
        if ($schema->hasTable(self::TABLE)) {
            return;
        }

        $schema->create(self::TABLE, function ($table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('service_id');
            $table->unsignedBigInteger('server_id');
            $table->string('username', 64)->nullable();
            $table->string('domain', 255)->nullable();
            $table->decimal('disk_used', 18, 3)->default(0);
            $table->decimal('disk_limit', 18, 3)->default(0);
            $table->decimal('bandwidth_used', 18, 3)->default(0);
            $table->decimal('bandwidth_limit', 18, 3)->default(0);
            $table->dateTime('recorded_at');
            $table->index(['service_id', 'recorded_at']);
            $table->index(['server_id', 'recorded_at']);
        });
    }

    /**
     * Store one snapshot. Persistence failure must never fail the usage import.
     *
     * @param array<string,mixed> $row
     */
    public static function record($row) {
        if (!class_exists('\WHMCS\Database\Capsule')) {
            return false;
        }

        try {
            self::ensureTable();
            \WHMCS\Database\Capsule::table(self::TABLE)->insert([
                'service_id' => (int) $row['service_id'],
                'server_id' => (int) $row['server_id'],
                'username' => isset($row['username']) ? (string) $row['username'] : null,
                'domain' => isset($row['domain']) ? (string) $row['domain'] : null,
                'disk_used' => (float) $row['disk_used'],
                'disk_limit' => (float) $row['disk_limit'],
                'bandwidth_used' => (float) $row['bandwidth_used'],
                'bandwidth_limit' => (float) $row['bandwidth_limit'],
                'recorded_at' => date('Y-m-d H:i:s'),
            ]);
            return true;
        } catch (\Exception $e) {
            if (function_exists('logModuleCall')) {
                logModuleCall('cwp7', 'UsageHistory', [], $e->getMessage());
            }
            return false;
        }
    }
}
