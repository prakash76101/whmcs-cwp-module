<?php
/**
 * CWP WHMCS Module — DNS delegation verification.
 *
 * This class deliberately does not edit a CWP zone. Before the module exposes any CWP
 * DNS records, it verifies that the domain is delegated to the nameservers configured
 * for the WHMCS CWP server. This keeps the CWP hosting module from presenting or changing
 * a zone that is not authoritative for the domain.
 *
 * @package cwp7
 * @version 3.0.29
 */
namespace Cwp7\Actions;

use Cwp7\CwpClient;
use WHMCS\Database\Capsule;

final class Dns
{
    /**
     * Verify delegation using the resolver available to the WHMCS PHP process.
     *
     * @param array<int,string> $expectedNameservers
     * @param array<int,string> $expectedIps
     *
     * @return array<string,mixed>
     */
    public static function delegation(
        $domain,
        $expectedNameservers,
        $expectedIps = [],
        $requireIpMatch = false
    ) {
        $domain = self::normaliseName($domain);
        $expectedNameservers = self::normaliseNames($expectedNameservers);
        $expectedIps = self::normaliseIps($expectedIps);

        if ($domain === '') {
            return self::result('invalid', $domain, $expectedNameservers, $expectedIps, [], [], false, false,
                'A valid domain is required.');
        }

        if ($expectedNameservers === []) {
            return self::result('configuration_required', $domain, $expectedNameservers, $expectedIps, [], [], false, false,
                'The CWP server does not have its authoritative nameservers configured in the module.');
        }

        if (!function_exists('dns_get_record')) {
            return self::result('lookup_unavailable', $domain, $expectedNameservers, $expectedIps, [], [], false, false,
                'DNS lookup is not available in the PHP environment running WHMCS.');
        }

        $records = @dns_get_record($domain, DNS_NS);
        if ($records === false) {
            return self::result('lookup_failed', $domain, $expectedNameservers, $expectedIps, [], [], false, false,
                'The WHMCS server could not obtain the domain nameserver records.');
        }

        $currentNameservers = [];
        foreach ($records as $record) {
            if (!is_array($record) || !isset($record['target'])) {
                continue;
            }
            $name = self::normaliseName((string) $record['target']);
            if ($name !== '') {
                $currentNameservers[] = $name;
            }
        }
        $currentNameservers = self::normaliseNames($currentNameservers);

        if ($currentNameservers === []) {
            return self::result('lookup_failed', $domain, $expectedNameservers, $expectedIps, [], [], false, false,
                'No authoritative nameservers were returned for this domain.');
        }

        $nameserversMatch = self::sameSet($currentNameservers, $expectedNameservers);
        $resolvedIps = [];
        foreach ($currentNameservers as $nameserver) {
            $resolvedIps[$nameserver] = self::addresses($nameserver);
        }

        $flatIps = [];
        foreach ($resolvedIps as $addresses) {
            foreach ($addresses as $ip) {
                $flatIps[] = $ip;
            }
        }
        $flatIps = self::normaliseIps($flatIps);

        $ipMatch = true;
        if ($requireIpMatch) {
            $ipMatch = self::everyNameserverMatches($resolvedIps, $expectedIps);
        }

        if (!$nameserversMatch) {
            return self::result(
                'not_pointed',
                $domain,
                $expectedNameservers,
                $expectedIps,
                $currentNameservers,
                $flatIps,
                false,
                $ipMatch,
                'The domain is not using the nameservers configured for this CWP hosting server.'
            );
        }

        if ($requireIpMatch && !$ipMatch) {
            return self::result(
                'not_pointed',
                $domain,
                $expectedNameservers,
                $expectedIps,
                $currentNameservers,
                $flatIps,
                false,
                false,
                'The domain uses the expected nameserver names, but their resolved addresses do not match the configured CWP DNS server addresses.'
            );
        }

        return self::result(
            'verified',
            $domain,
            $expectedNameservers,
            $expectedIps,
            $currentNameservers,
            $flatIps,
            true,
            $ipMatch,
            $requireIpMatch
                ? 'Domain delegation and nameserver address checks passed.'
                : 'Domain delegation matches the nameservers configured for this CWP hosting server.'
        );
    }

    /**
     * Server-scoped configuration helper. Nameservers are intentionally server-specific:
     * the same product can land on different CWP servers with different NS pairs.
     *
     * @return array{nameservers:array<int,string>,ips:array<int,string>,require_ip_match:bool}
     */
    public static function serverSettings(CwpClient $client, $params = []) {
        // Explicit cwp7 config.php values remain authoritative. If they are empty,
        // inherit the nameservers and nameserver IPs already configured on the WHMCS
        // server record assigned to this hosting service. WHMCS stores these as
        // nameserver1..5 and nameserver1ip..5ip in tblservers. This is important for
        // multi-CWP installations: each hosting service automatically uses the NS pair
        // belonging to its assigned WHMCS server instead of requiring a duplicate copy
        // in config.php.
        $nameservers = $client->getOption('dns_nameservers', []);
        $ips = $client->getOption('dns_nameserver_ips', []);
        $requireIp = (bool) $client->getOption('dns_require_nameserver_ip_match', false);

        $nameservers = is_array($nameservers) ? self::normaliseNames($nameservers) : [];
        $ips = is_array($ips) ? self::normaliseIps($ips) : [];

        if ($nameservers === [] && isset($params['serverid']) && (int) $params['serverid'] > 0) {
            try {
                $row = Capsule::table('tblservers')
                    ->where('id', '=', (int) $params['serverid'])
                    ->first([
                        'nameserver1', 'nameserver2', 'nameserver3', 'nameserver4', 'nameserver5',
                        'nameserver1ip', 'nameserver2ip', 'nameserver3ip', 'nameserver4ip', 'nameserver5ip',
                    ]);

                if ($row) {
                    $serverNames = [];
                    $serverIps = [];
                    for ($i = 1; $i <= 5; $i++) {
                        $nameKey = 'nameserver' . $i;
                        $ipKey = 'nameserver' . $i . 'ip';
                        if (isset($row->{$nameKey}) && trim((string) $row->{$nameKey}) !== '') {
                            $serverNames[] = (string) $row->{$nameKey};
                        }
                        if (isset($row->{$ipKey}) && trim((string) $row->{$ipKey}) !== '') {
                            $serverIps[] = (string) $row->{$ipKey};
                        }
                    }
                    $nameservers = self::normaliseNames($serverNames);
                    if ($ips === []) {
                        $ips = self::normaliseIps($serverIps);
                    }
                }
            } catch (\Exception $e) {
                // A missing/unavailable WHMCS database row should not turn a client
                // page into a fatal error. The result will correctly remain
                // configuration_required and the administrator can inspect the logs.
            }
        }

        return [
            'nameservers' => $nameservers,
            'ips' => $ips,
            'require_ip_match' => $requireIp,
        ];
    }

    /**
     * Read the publicly published DNS records for an already verified domain.
     *
     * This is deliberately read-only and uses the DNS protocol rather than an
     * undocumented CWP zone-editor endpoint. It is therefore safe to expose as the
     * first record-listing stage after delegation has been verified. The result is
     * labelled as authoritative/public DNS data; it is not treated as a substitute
     * for the CWP zone editor for mutations.
     *
     * @param array<int,string> $names Additional owned FQDNs to inspect, such as
     *                                CWP-reported subdomains.
     * @return array<string,mixed>
     */
    public static function publishedRecords($domain, $names = []) {
        $domain = self::normaliseName($domain);
        if ($domain === '') {
            return ['domain' => '', 'records' => [], 'queried_names' => [], 'source' => 'authoritative_dns'];
        }

        $targets = [$domain];
        foreach ($names as $name) {
            if (!is_scalar($name)) {
                continue;
            }
            $name = self::normaliseName((string) $name);
            if ($name === '' || $name === $domain || !self::belongsToDomain($name, $domain)) {
                continue;
            }
            $targets[] = $name;
        }

        // These are the standard CWP service names visible in many CWP zones. They
        // are only queried when they belong to the verified domain; absent records
        // simply do not appear in the result.
        foreach (['www', 'mail', 'smtp', 'pop', 'pop3', 'imap', 'webmail', 'ftp', 'cpanel', 'cwp'] as $label) {
            $targets[] = $label . '.' . $domain;
        }
        $targets = array_values(array_unique($targets));

        $types = [
            'A' => defined('DNS_A') ? DNS_A : 1,
            'AAAA' => defined('DNS_AAAA') ? DNS_AAAA : 134217728,
            'CNAME' => defined('DNS_CNAME') ? DNS_CNAME : 16,
            'MX' => defined('DNS_MX') ? DNS_MX : 16384,
            'TXT' => defined('DNS_TXT') ? DNS_TXT : 32768,
            'SRV' => defined('DNS_SRV') ? DNS_SRV : 33554432,
            'CAA' => defined('DNS_CAA') ? DNS_CAA : 8192,
            'NS' => defined('DNS_NS') ? DNS_NS : 2,
        ];

        $records = [];
        foreach ($targets as $target) {
            foreach ($types as $type => $flag) {
                $rows = @dns_get_record($target, $flag);
                if (!is_array($rows)) {
                    continue;
                }
                foreach ($rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $normalised = self::normaliseDnsRecord($row, $type, $domain);
                    if ($normalised === null) {
                        continue;
                    }
                    $key = implode('|', [
                        $normalised['name'],
                        $normalised['type'],
                        (string) $normalised['ttl'],
                        (string) $normalised['priority'],
                        $normalised['value'],
                    ]);
                    $records[$key] = $normalised;
                }
            }
        }

        // A recursive resolver can return the same RR more than once (for example
        // when responses are assembled from multiple authoritative nameservers).
        // The TTL is an observed/remaining resolver TTL, not part of the DNS RR
        // identity, so it must never be used as the de-duplication key.
        $records = self::deduplicatePublishedRecords(array_values($records));
        usort($records, static function ($a, $b) {
            return [$a['name'], $a['type'], $a['priority'], $a['value']]
                <=> [$b['name'], $b['type'], $b['priority'], $b['value']];
        });

        return [
            'domain' => $domain,
            'records' => $records,
            'queried_names' => $targets,
            'source' => 'authoritative_dns',
            'read_only' => true,
            'cwp_zone_editor_verified' => false,
        ];
    }

    /**
     * Collapse duplicate public DNS observations without treating resolver TTL
     * differences as distinct records. The DNS record identity is name + type +
     * priority + value. When the same RR is observed with different remaining TTLs,
     * retain the highest observed TTL because it is the least likely to be a partially
     * expired resolver copy.
     *
     * @param array<int,array<string,mixed>> $records
     * @return array<int,array<string,mixed>>
     */
    public static function deduplicatePublishedRecords($records) {
        $unique = [];
        foreach ($records as $record) {
            if (!is_array($record)) {
                continue;
            }
            $key = implode('|', [
                strtolower(trim((string) (isset($record['name']) ? $record['name'] : ''))),
                strtoupper(trim((string) (isset($record['type']) ? $record['type'] : ''))),
                (string) ((int) (isset($record['priority']) ? $record['priority'] : 0)),
                trim((string) (isset($record['value']) ? $record['value'] : '')),
            ]);
            if ($key === '|||') {
                continue;
            }
            if (!isset($unique[$key])) {
                $unique[$key] = $record;
                continue;
            }
            $existingTtl = isset($unique[$key]['ttl']) && is_numeric($unique[$key]['ttl'])
                ? (int) $unique[$key]['ttl'] : 0;
            $candidateTtl = isset($record['ttl']) && is_numeric($record['ttl'])
                ? (int) $record['ttl'] : 0;
            if ($candidateTtl > $existingTtl) {
                $unique[$key]['ttl'] = $candidateTtl;
            }
        }
        return array_values($unique);
    }

    /**
     * De-duplicate records returned directly by CWP's Zone Editor. Unlike public
     * resolver observations, these rows represent configured zone records, so the
     * configured TTL is part of the displayed data but not the record identity.
     *
     * @param array<int,array<string,mixed>> $records
     * @return array<int,array<string,mixed>>
     */
    public static function deduplicateZoneEditorRecords($records) {
        $unique = [];
        foreach ($records as $record) {
            if (!is_array($record)) {
                continue;
            }
            $name = trim((string) (isset($record['name']) ? $record['name'] : ''));
            $type = strtoupper(trim((string) (isset($record['type']) ? $record['type'] : '')));
            $priority = (int) (isset($record['priority']) ? $record['priority'] : 0);
            $value = trim((string) (isset($record['value']) ? $record['value'] : ''));
            if ($name === '' || $type === '' || $value === '') {
                continue;
            }
            $key = strtolower($name) . '|' . $type . '|' . $priority . '|' . $value;
            if (!isset($unique[$key])) {
                $unique[$key] = $record;
            }
        }

        return array_values($unique);
    }

    private static function belongsToDomain($name, $domain) {
        return $name === $domain || substr($name, -strlen('.' . $domain)) === '.' . $domain;
    }

    /** @return array<string,mixed>|null */
    private static function normaliseDnsRecord($row, $type, $domain) {
        $name = self::normaliseName((string) (isset($row['host']) ? $row['host'] : $domain));
        if ($name === '' || !self::belongsToDomain($name, $domain)) {
            return null;
        }

        $ttl = isset($row['ttl']) && is_numeric($row['ttl']) ? (int) $row['ttl'] : 0;
        $priority = isset($row['pri']) && is_numeric($row['pri']) ? (int) $row['pri'] : 0;
        $value = '';

        if ($type === 'A' && isset($row['ip'])) {
            $value = trim((string) $row['ip']);
        } elseif ($type === 'AAAA' && isset($row['ipv6'])) {
            $value = trim((string) $row['ipv6']);
        } elseif ($type === 'CNAME' && isset($row['target'])) {
            $value = self::normaliseName((string) $row['target']);
        } elseif ($type === 'NS' && isset($row['target'])) {
            $value = self::normaliseName((string) $row['target']);
        } elseif ($type === 'MX' && isset($row['target'])) {
            $value = self::normaliseName((string) $row['target']);
        } elseif ($type === 'TXT' && isset($row['txt'])) {
            $value = trim((string) $row['txt']);
        } elseif ($type === 'SRV' && isset($row['target'])) {
            $weight = isset($row['weight']) ? (int) $row['weight'] : 0;
            $port = isset($row['port']) ? (int) $row['port'] : 0;
            $value = $weight . ' ' . $port . ' ' . self::normaliseName((string) $row['target']);
        } elseif ($type === 'CAA' && isset($row['value'])) {
            $flags = isset($row['flags']) ? (int) $row['flags'] : 0;
            $tag = isset($row['tag']) ? trim((string) $row['tag']) : '';
            $value = $flags . ' ' . $tag . ' "' . trim((string) $row['value']) . '"';
        }

        if ($value === '') {
            return null;
        }

        return [
            'name' => $name === $domain ? '@' : substr($name, 0, -(strlen($domain) + 1)),
            'fqdn' => $name,
            'type' => $type,
            'ttl' => $ttl,
            'priority' => $priority,
            'value' => $value,
        ];
    }

    /**
     * Pure comparison helper used by tests and diagnostics.
     *
     * @param array<int,string> $current
     * @param array<int,string> $expected
     */
    public static function nameserversMatch($current, $expected) {
        return self::sameSet(self::normaliseNames($current), self::normaliseNames($expected));
    }

    /**
     * Pure IP matching helper: every nameserver must resolve to at least one address
     * contained in the configured expected address list.
     *
     * @param array<string,array<int,string>> $resolved
     * @param array<int,string> $expectedIps
     */
    public static function nameserverIpsMatch($resolved, $expectedIps) {
        return self::everyNameserverMatches($resolved, self::normaliseIps($expectedIps));
    }

    private static function result(
        $status,
        $domain,
        $expectedNameservers,
        $expectedIps,
        $currentNameservers,
        $resolvedIps,
        $nameserversMatch,
        $ipMatch,
        $message
    ) {
        return [
            'status' => $status,
            'domain' => $domain,
            'expected_nameservers' => $expectedNameservers,
            'current_nameservers' => $currentNameservers,
            'expected_ips' => $expectedIps,
            'resolved_nameserver_ips' => $resolvedIps,
            'nameservers_match' => $nameserversMatch,
            'ip_match' => $ipMatch,
            'ready' => $status === 'verified',
            'message' => $message,
            'checked_at' => gmdate('c'),
        ];
    }

    /** @return array<int,string> */
    private static function addresses($name) {
        $out = [];
        $records = @dns_get_record($name, DNS_A | DNS_AAAA);
        if ($records === false) {
            return [];
        }

        foreach ($records as $record) {
            if (!is_array($record) || !isset($record['ip'])) {
                continue;
            }
            $ip = trim((string) $record['ip']);
            if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                $out[] = $ip;
            }
        }

        return self::normaliseIps($out);
    }

    /** @param array<string,array<int,string>> $resolved */
    private static function everyNameserverMatches($resolved, $expectedIps) {
        if ($expectedIps === [] || $resolved === []) {
            return false;
        }

        $expected = array_flip(self::normaliseIps($expectedIps));
        foreach ($resolved as $addresses) {
            $matched = false;
            foreach (self::normaliseIps(is_array($addresses) ? $addresses : []) as $ip) {
                if (isset($expected[$ip])) {
                    $matched = true;
                    break;
                }
            }
            if (!$matched) {
                return false;
            }
        }

        return true;
    }

    /** @param array<int,string> $values */
    private static function normaliseNames($values) {
        $out = [];
        foreach ($values as $value) {
            if (!is_scalar($value)) {
                continue;
            }
            $value = self::normaliseName((string) $value);
            if ($value !== '') {
                $out[$value] = $value;
            }
        }
        $out = array_values($out);
        sort($out, SORT_STRING);
        return $out;
    }

    /** @param array<int,string> $values */
    private static function normaliseIps($values) {
        $out = [];
        foreach ($values as $value) {
            if (!is_scalar($value)) {
                continue;
            }
            $value = trim((string) $value);
            if ($value !== '' && filter_var($value, FILTER_VALIDATE_IP) !== false) {
                $out[$value] = $value;
            }
        }
        $out = array_values($out);
        sort($out, SORT_STRING);
        return $out;
    }

    private static function normaliseName($value) {
        $value = strtolower(trim($value));
        return rtrim($value, '.');
    }

    /** @param array<int,string> $left @param array<int,string> $right */
    private static function sameSet($left, $right) {
        sort($left, SORT_STRING);
        sort($right, SORT_STRING);
        return $left === $right;
    }
}
