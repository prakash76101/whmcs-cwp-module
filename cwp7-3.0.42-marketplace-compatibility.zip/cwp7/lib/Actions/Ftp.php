<?php
/**
 * CWP WHMCS Module — FTP account management.
 *
 * CWP exposes FTP Manager as the `ftp` API function with list/add/upd/del actions.
 * The module keeps the hosting account fixed from WHMCS and validates every requested
 * FTP identity against the account's current list before an update/delete.
 *
 * @package cwp7
 * @version 3.0.12
 */
namespace Cwp7\Actions;

use Cwp7\CwpClient;
use Cwp7\CwpException;
use Cwp7\Validate;

final class Ftp
{
    const FUNCTION = 'ftp';
    const ACCOUNT = 'user';

    /**
     * CWP FTP Manager fields. The account UI supplies domain, login, password and path.
     * The API key and action are added by CwpClient.
     */
    const ADD = [
        'username' => 'userftp',
        'password' => 'passftp',
        'domain' => 'domainftp',
        'path' => 'pathftp',
    ];

    const MODIFY = [
        'username' => 'userftp',
        'password' => 'passftp',
        'path' => 'pathftp',
    ];

    /** @var CwpClient */
    private $client;
    /** @var string */
    private $account;

    public function __construct(CwpClient $client, $account)
    {
        $this->client = $client;
        $this->account = $account;
    }

    /** @return array<int,array<string,mixed>> */
    public function all() {
        return self::rows(CwpClient::rows($this->client->call(self::FUNCTION, 'list', [
            self::ACCOUNT => $this->account,
        ])));
    }

    /** @param array<int,mixed> $rows */
    public static function rows($rows) {
        $out = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $username = Usage::pick($row, ['ftpuser', 'username', 'user', 'login', 'ftp_account']);
            if ($username === null || trim((string) $username) === '') {
                continue;
            }
            $domain = Usage::pick($row, ['domain', 'domain_name']);
            $path = Usage::pick($row, ['path', 'ftp_path', 'directory', 'dir']);
            $full = trim((string) $username);
            if ($domain !== null && strpos($full, '@') === false && trim((string) $domain) !== '') {
                $full .= '@' . trim((string) $domain);
            }
            $out[] = [
                'username' => strtolower($full),
                'domain' => $domain === null ? '' : strtolower(trim((string) $domain)),
                'path' => $path === null ? '' : trim((string) $path),
            ];
        }
        usort($out, function ($a, $b) { return strcmp($a['username'], $b['username']); });
        return $out;
    }

    /** @throws CwpException */
    public function create($detail, $username, $domain, $password, $path) {
        $username = Validate::accountName($username, 'FTP username');
        $domain = Validate::ownedDomain($detail, $domain);
        $fields = $this->createFields($username, $domain, $password, $path);

        // CWP's FTP Manager can take time to write the Pure-FTPd account. Do not
        // report success merely because the API returned HTTP/JSON success: verify
        // that the new identity is visible through ftp/list. This also gives us a
        // recovery path when the add request times out after CWP has actually created
        // the account.
        try {
            $this->client->call(
                self::FUNCTION,
                'add',
                $fields,
                max(5, (int) $this->client->getOption('ftp_create_timeout', 30))
            );
        } catch (CwpException $e) {
            if (!$this->verifyCreated($username, $domain)) {
                throw $e;
            }
        }

        $this->client->clearReadCache();
        if (!$this->verifyCreated($username, $domain)) {
            throw CwpException::api(
                'FTP add returned success, but the new account was not found by ftp/list.',
                ['function' => self::FUNCTION, 'action' => 'add']
            );
        }

        return $username . '@' . $domain;
    }

    /** @return array<string,string> */
    public function createFields($username, $domain, $password, $path) {
        $path = self::path($path);
        return [
            self::ACCOUNT => $this->account,
            self::ADD['username'] => Validate::accountName($username, 'FTP username'),
            self::ADD['domain'] => Validate::ownedDomain(['domains' => [['domain' => $domain]]], $domain),
            self::ADD['password'] => Validate::password($password),
            self::ADD['path'] => $path,
        ];
    }


    /**
     * Verify that an FTP account is visible after creation.
     *
     * @throws CwpException
     */
    private function verifyCreated($username, $domain) {
        // Keep verification short. A normal FTP list request must not inherit the
        // module's long provisioning timeout; otherwise one failed add can leave the
        // customer staring at “Creating FTP...” for several minutes with no message.
        $attempts = 2;
        $listTimeout = max(3, (int) $this->client->getOption('ftp_verify_timeout', 5));
        for ($attempt = 0; $attempt < $attempts; $attempt++) {
            $this->client->clearReadCache();
            try {
                $rows = CwpClient::rows($this->client->call(
                    self::FUNCTION,
                    'list',
                    [self::ACCOUNT => $this->account],
                    $listTimeout
                ));
            } catch (CwpException $e) {
                if ($attempt === $attempts - 1) {
                    // Preserve the original add error when this is only a verification
                    // failure. The full verification exception is already in the module
                    // log through CwpClient.
                    return false;
                }
                usleep(500000);
                continue;
            }

            foreach (self::rows($rows) as $row) {
                $identity = strtolower(trim((string) $row['username']));
                $wanted = strtolower($username . '@' . $domain);
                if ($identity === $wanted || $identity === strtolower($username)) {
                    return true;
                }
            }
            if ($attempt < $attempts - 1) {
                usleep(700000);
            }
        }

        return false;
    }

    /** @param array<int,array<string,mixed>> $existing @throws CwpException */
    public function update($existing, $username, $password, $path) {
        $identity = self::assertOwned($existing, $username);
        $fields = [self::ACCOUNT => $this->account, self::MODIFY['username'] => $identity];
        if (trim($password) !== '') {
            $fields[self::MODIFY['password']] = Validate::password($password);
        }
        if (trim($path) !== '') {
            $fields[self::MODIFY['path']] = self::path($path);
        }
        if (count($fields) === 2) {
            throw CwpException::input('Enter a new password or FTP path.');
        }
        $this->client->call(self::FUNCTION, 'upd', $fields);
    }

    /** @param array<int,array<string,mixed>> $existing @throws CwpException */
    public function delete($existing, $username) {
        $identity = self::assertOwned($existing, $username);
        $this->client->call(self::FUNCTION, 'del', [
            self::ACCOUNT => $this->account,
            self::MODIFY['username'] => $identity,
        ]);
    }

    public static function path($path) {
        $path = trim($path);
        if ($path === '') {
            throw CwpException::input('Enter an FTP path.');
        }
        if ($path[0] !== '/') {
            $path = '/' . $path;
        }
        if (strpos($path, "\0") !== false || strlen($path) > 255) {
            throw CwpException::input('That FTP path is invalid.');
        }
        return preg_replace('#/+#', '/', $path);
    }

    /** @param array<int,array<string,mixed>> $existing @throws CwpException */
    public static function assertOwned($existing, $username) {
        $username = strtolower(trim($username));
        if ($username === '') {
            throw CwpException::input('Choose an FTP account.');
        }
        foreach ($existing as $row) {
            if (isset($row['username']) && strtolower((string) $row['username']) === $username) {
                return $username;
            }
        }
        throw CwpException::input('That FTP account is not on this hosting account.');
    }
}
