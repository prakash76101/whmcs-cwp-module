<?php
/**
 * CWP web-panel Zone Editor transport.
 *
 * CWP's live DNS Zone Editor is an authenticated web-panel AJAX endpoint rather than
 * the documented 2304 API. This class keeps that boundary server-side: WHMCS uses the
 * CWP server credentials already stored in the server record to establish a short-lived
 * CWP panel session, then immediately uses that session for the zone-editor request.
 * No browser session cookie is exposed to the client and no cookie is persisted by the
 * module between requests.
 */
namespace Cwp7\Actions;

use Cwp7\CwpClient;
use Cwp7\CwpException;
use WHMCS\Database\Capsule;

final class ZoneEditor
{
    private $client;
    private $params;
    private $url;
    private $host;
    private $port;
    private $verifyTls;
    private $timeout;
    private $autoLogin;
    private $serverUsername;
    private $serverPassword;

    public function __construct(CwpClient $client, $params = [])
    {
        $this->client = $client;
        $this->params = $params;
        $this->url = '';
        $this->host = trim((string) (isset($params['serverhostname']) ? $params['serverhostname'] : ''));
        if ($this->host === '') {
            $this->host = trim((string) (isset($params['serverip']) ? $params['serverip'] : ''));
        }
        $this->port = 2087;
        $this->verifyTls = (bool) $client->getOption('dns_zone_editor_verify_tls', true);
        $this->timeout = max(3, (int) $client->getOption('dns_zone_editor_timeout', 20));
        $this->autoLogin = (bool) $client->getOption('dns_zone_editor_auto_login', true);
        $this->serverUsername = trim((string) (isset($params['serverusername']) ? $params['serverusername'] : ''));
        $this->serverPassword = (string) (isset($params['serverpassword']) ? $params['serverpassword'] : '');
    }

    public function configured() {
        if ($this->autoLogin) {
            $this->loadServerCredentials();
            return $this->host !== ''
                && $this->serverUsername !== ''
                && $this->serverPassword !== '';
        }

        // Explicit cookie fallback is intentionally no longer supported. A persistent
        // browser session is too fragile and unsafe for a production WHMCS integration.
        return false;
    }

    /** @return array<string,mixed> */
    public function parse($domain) {
        $file = $this->zoneFile($domain);
        $body = $this->request([
            'acc' => 'paserrecord',
            'domain' => $file,
        ]);

        return [
            'domain' => $domain,
            'file_path' => $file,
            'records' => $this->parseHtmlRecords($body),
            'raw_length' => strlen($body),
        ];
    }

    /** @return array<string,mixed> */
    public function addTxt($domain, $name, $ttl, $value) {
        $name = $this->recordName($name, $domain);
        if ($ttl < 0 || $ttl > 2147483647) {
            throw CwpException::input('Enter a valid DNS TTL.');
        }
        if ($value === '') {
            throw CwpException::input('Enter a TXT record value.');
        }

        $file = $this->zoneFile($domain);
        $body = $this->request([
            'reg' => 'TXT',
            'acc' => 'addregdns',
            'file_path' => $file,
            'txname' => $name === $domain ? '@' : $this->relativeName($name, $domain),
            'txcache' => (string) $ttl,
            'txvalue' => '"' . $this->escapeTxt($value) . '"',
        ]);

        return ['domain' => $domain, 'file_path' => $file, 'response' => $this->summariseResponse($body)];
    }

    /** @return array<string,mixed> */
    public function edit($domain, $lineNumber, $line) {
        if ($lineNumber < 1) {
            throw CwpException::input('A valid DNS zone line number is required.');
        }
        $body = $this->request([
            'acc' => 'editregzone',
            'line' => $this->encodeLine($line),
        ]);

        return ['domain' => $domain, 'line_number' => $lineNumber, 'response' => $this->summariseResponse($body)];
    }

    /** @return array<string,mixed> */
    public function delete($domain, $lineNumber, $line) {
        if ($lineNumber < 1) {
            throw CwpException::input('A valid DNS zone line number is required.');
        }
        $file = $this->zoneFile($domain);
        $body = $this->request([
            'acc' => 'deleteregzone',
            'file_path' => $file,
            'linedos' => (string) $lineNumber,
            'line' => $this->encodeLine($line),
        ]);

        return ['domain' => $domain, 'line_number' => $lineNumber, 'response' => $this->summariseResponse($body)];
    }

    private function request($fields) {
        if ($this->host === '') {
            throw CwpException::config('The assigned WHMCS CWP server has no hostname or IP address for the DNS Zone Editor.');
        }
        if (!$this->configured()) {
            throw CwpException::config(
                'CWP DNS Zone Editor requires the WHMCS server username/password so the module can create a short-lived CWP panel session. Do not configure a browser session cookie.'
            );
        }
        if (!function_exists('curl_init')) {
            throw CwpException::transport('PHP cURL is required for the CWP DNS Zone Editor transport.');
        }

        $session = $this->login();
        return $this->zoneRequest($fields, $session['cookie'], $session['zone_url']);
    }

    /**
     * Establish a short-lived CWP admin session using credentials already stored in WHMCS.
     * The cookie is returned only in memory and is never written to config or the module log.
     */
    /** @return array{cookie:string,zone_url:string} */
    private function login() {
        $this->loadServerCredentials();
        $username = $this->serverUsername;
        $password = $this->serverPassword;
        if ($username === '' || $password === '') {
            throw CwpException::config('CWP admin username/password are required for DNS Zone Editor login.');
        }

        $loginUrl = $this->loginUrl();
        $cookieFile = tempnam(sys_get_temp_dir(), 'cwp7_dns_');
        if ($cookieFile === false) {
            throw CwpException::transport('Unable to initialise the temporary CWP DNS session store.');
        }

        try {
            // CWP initializes the login session on the normal login page. Its
            // validation AJAX call expects the browser field contract:
            // username, password, sessioning and userlang.
            $loginPageUrl = $this->loginPageUrl();
            $loginPage = $this->simpleHttp($loginPageUrl, 'GET', [], '', $cookieFile, false);
            $loginFields = $this->loginFieldsFromPage($loginPage['body']);
            $loginFields['username'] = $username;
            // Older/current CWP login revisions have used both `user` and
            // `username` names in the login contract. Supplying the legacy alias
            // is harmless and makes the transport compatible with those panels.
            $loginFields['user'] = $username;
            $loginFields['password'] = $password;
            $loginFields['commit'] = 'login';
            $loginFields['userlang'] = isset($loginFields['userlang']) && $loginFields['userlang'] !== ''
                ? $loginFields['userlang']
                : 'en';

            // IMPORTANT: the validation request was accidentally omitted in the
            // previous release. The login page GET only initializes the browser
            // session; it does not authenticate the admin credentials. Actually
            // submit the CWP validation request while keeping the same temporary
            // cookie jar.
            $response = $this->simpleHttp($loginUrl, 'POST', $loginFields, '', $cookieFile, false);

            // CWP revisions differ in how the successful login is returned. Some
            // send a Location header to /cwp_<id>/admin/..., others return a small
            // HTML/JS/JSON payload containing only /cwp_<id>/, and some expose the
            // randomized prefix through the cookie path. Accept all of those forms.
            $combined = $response['effective_url'] . "\n" . $response['headers'] . "\n" . $response['body'];
            $cookie = $this->cookieHeaderFromFile($cookieFile);
            if ($cookie === '') {
                throw CwpException::api('CWP did not establish an authenticated admin-panel session for DNS Zone Editor.');
            }

            $combinedLower = strtolower($combined);
            if ((strpos($combinedLower, 'invalid') !== false || strpos($combinedLower, 'incorrect') !== false)
                && (strpos($combinedLower, 'password') !== false || strpos($combinedLower, 'login') !== false)) {
                throw CwpException::api('CWP rejected the configured admin username/password for DNS Zone Editor.');
            }

            $zoneUrl = $this->zoneEditorUrlFromEffectiveUrl(isset($response['effective_url']) ? $response['effective_url'] : '');
            if ($zoneUrl === '') {
                $zoneUrl = $this->zoneEditorUrlFromText($combined);
            }
            if ($zoneUrl === '') {
                $zoneUrl = $this->zoneEditorUrlFromCookieFile($cookieFile);
            }
            if ($zoneUrl === '') {
                throw CwpException::api('CWP login established cookies but did not expose the current randomized admin-panel session path.');
            }

            return ['cookie' => $cookie, 'zone_url' => $zoneUrl];
        } finally {
            @unlink($cookieFile);
        }
    }

    /**
     * WHMCS does not include serverusername/serverpassword in every custom client-area
     * invocation. The normal provisioning functions receive them, but the supported
     * ClientAreaAllowedFunctions transport can receive only the service/server context.
     * In that case retrieve the credentials from the assigned WHMCS server record.
     *
     * The password is decrypted only in memory for the immediate CWP login and is never
     * added back to $params, returned to the browser, or written to the module log.
     */
    private function loadServerCredentials() {
        if ($this->serverUsername !== '' && $this->serverPassword !== '') {
            return;
        }

        $serverId = isset($this->params['serverid']) ? (int) $this->params['serverid'] : 0;
        if ($serverId <= 0) {
            return;
        }
        if (!class_exists('\Illuminate\Database\Capsule\Manager')) {
            throw CwpException::config('WHMCS database access is unavailable; the DNS Zone Editor cannot retrieve the assigned CWP server credentials.');
        }

        try {
            $row = Capsule::table('tblservers')
                ->where('id', '=', $serverId)
                ->first(['username', 'password', 'hostname', 'ipaddress']);
        } catch (\Exception $e) {
            throw CwpException::config('Unable to read the assigned WHMCS CWP server credentials for DNS management.');
        }

        if (!$row) {
            throw CwpException::config('The assigned WHMCS CWP server could not be found.');
        }

        if ($this->host === '') {
            $this->host = trim((string) (isset($row->hostname) ? $row->hostname : ''));
            if ($this->host === '') {
                $this->host = trim((string) (isset($row->ipaddress) ? $row->ipaddress : ''));
            }
        }

        if ($this->serverUsername === '') {
            $this->serverUsername = trim((string) (isset($row->username) ? $row->username : ''));
        }

        if ($this->serverPassword === '') {
            $encrypted = (string) (isset($row->password) ? $row->password : '');
            if ($encrypted !== '' && function_exists('decrypt')) {
                try {
                    $this->serverPassword = (string) \decrypt($encrypted);
                } catch (\Exception $e) {
                    $this->serverPassword = '';
                }
            }
        }
    }

    private function loginPageUrl() {
        $host = $this->host;
        if ($host === '') {
            throw CwpException::config('The assigned WHMCS CWP server has no hostname or IP address.');
        }
        if (strpos($host, '/') !== false || strpos($host, '\\') !== false) {
            throw CwpException::config('The configured CWP server hostname/IP is invalid.');
        }
        $hostForUrl = $host;
        if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $hostForUrl = '[' . $host . ']';
        }
        return 'https://' . $hostForUrl . ':' . $this->port . '/login/index.php';
    }

    private function loginUrl() {
        return $this->loginPageUrl() . '?acc=validate';
    }

    /** @return array<string,string> */
    private function loginFieldsFromPage($html) {
        $fields = [];
        if ($html === '') {
            return $fields;
        }

        // Preserve hidden fields supplied by the current CWP login page.
        if (preg_match_all(
            '~<input[^>]+(?:name|id)=[\"\'](sessioning|intended|userlang)[\"\'][^>]*>~i',
            $html,
            $matches
        )) {
            foreach ($matches[0] as $input) {
                if (preg_match('~(?:name|id)=[\"\'](sessioning|intended|userlang)[\"\']~i', $input, $nameMatch)
                    && preg_match('~value=[\"\']([^\"\']*)[\"\']~i', $input, $valueMatch)) {
                    $fields[strtolower($nameMatch[1])] = html_entity_decode($valueMatch[1], ENT_QUOTES, 'UTF-8');
                }
            }
        }

        // Some CWP revisions create sessioning in JavaScript instead of an input.
        if (!isset($fields['sessioning'])
            && preg_match('~sessioning\s*[=:]\s*[\"\']([^\"\']+)[\"\']~i', $html, $match)) {
            $fields['sessioning'] = $match[1];
        }

        return $fields;
    }

    private function zoneEditorUrlFromText($text) {
        if ($text === '') {
            return '';
        }

        // The successful CWP login may expose the randomized prefix as a full
        // /cwp_<id>/admin/... URL, as a root-relative /cwp_<id>/ URL, or as a
        // JSON/JavaScript string containing only the prefix. Never persist it.
        if (preg_match('~/(cwp_[A-Za-z0-9]+)(?:/[^\s\"\'<>]*)?~i', $text, $m)) {
            return $this->adminZoneUrlFromPrefix('/' . $m[1]);
        }
        return '';
    }

    private function zoneEditorUrlFromCookieFile($file) {
        if (!is_readable($file)) {
            return '';
        }
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines)) {
            return '';
        }
        foreach ($lines as $line) {
            if (strpos($line, '#HttpOnly_') === 0) {
                $line = substr($line, strlen('#HttpOnly_'));
            }
            if ($line === '' || $line[0] === '#') {
                continue;
            }
            $parts = explode("\t", $line);
            if (count($parts) >= 7) {
                $path = trim($parts[2]);
                if (preg_match('~^/cwp_[A-Za-z0-9_-]+(?:/.*)?$~', $path)) {
                    $prefix = preg_replace('~/.*$~', '', substr($path, 1));
                    if (is_string($prefix) && strpos($prefix, 'cwp_') === 0) {
                        return $this->adminZoneUrlFromPrefix('/' . $prefix);
                    }
                }
            }
        }
        return '';
    }

    private function adminZoneUrlFromPrefix($prefix) {
        $hostForUrl = $this->host;
        if (filter_var($hostForUrl, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $hostForUrl = '[' . $hostForUrl . ']';
        }
        return 'https://' . $hostForUrl . ':' . $this->port . rtrim($prefix, '/') . '/admin/loader_ajax.php?ajax=zone_editor';
    }

    private function zoneEditorUrlFromEffectiveUrl($effectiveUrl) {
        if ($effectiveUrl === '') {
            return '';
        }
        $parts = parse_url($effectiveUrl);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return '';
        }
        if (strtolower((string) $parts['scheme']) !== 'https') {
            return '';
        }
        $path = (string) (isset($parts['path']) ? $parts['path'] : '');
        $adminPos = strpos($path, '/admin/');
        if ($adminPos === false) {
            return '';
        }
        $prefix = substr($path, 0, $adminPos);
        if ($prefix === '' || strpos($prefix, '/cwp_') === false) {
            return '';
        }
        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : ':' . $this->port;
        return $parts['scheme'] . '://' . $parts['host'] . $port . $prefix . '/admin/loader_ajax.php?ajax=zone_editor';
    }

    /** @return array{body:string,headers:string,http:int,effective_url:string} */
    private function simpleHttp(
        $url,
        $method,
        $fields,
        $cookie,
        $cookieFile,
        $follow
    ) {
        $ch = curl_init($url);
        if ($ch === false) {
            throw CwpException::transport('Unable to initialise the CWP DNS session connection.');
        }

        $headers = [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'User-Agent: WHMCS-CWP7-DNS/3.0.42',
        ];
        if ($cookie !== '') {
            $headers[] = 'Cookie: ' . $cookie;
        }

        $options = [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_FOLLOWLOCATION => $follow,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_COOKIEFILE => $cookieFile,
            CURLOPT_COOKIEJAR => $cookieFile,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_SSL_VERIFYPEER => $this->verifyTls,
            CURLOPT_SSL_VERIFYHOST => $this->verifyTls ? 2 : 0,
        ];
        if ($method === 'POST') {
            $options[CURLOPT_POSTFIELDS] = http_build_query($fields, '', '&');
            $options[CURLOPT_HTTPHEADER][] = 'Content-Type: application/x-www-form-urlencoded';
            if (strpos($url, '/login/index.php?acc=validate') !== false) {
                $options[CURLOPT_HTTPHEADER][] = 'X-Requested-With: XMLHttpRequest';
                $options[CURLOPT_HTTPHEADER][] = 'Referer: ' . $this->loginPageUrl();
            }
        }
        curl_setopt_array($ch, $options);

        $raw = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $effectiveUrl = (string) curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $headerSize = (int) curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);

        if ($raw === false || $errno !== 0) {
            throw CwpException::transport('CWP DNS Zone Editor login connection failed: ' . ($error !== '' ? $error : 'unknown cURL error'));
        }

        $headersText = substr((string) $raw, 0, $headerSize);
        $body = substr((string) $raw, $headerSize);
        if ($http < 200 || $http >= 400) {
            throw CwpException::api('CWP DNS Zone Editor login returned HTTP ' . $http . '.');
        }

        return ['body' => (string) $body, 'headers' => (string) $headersText, 'http' => $http, 'effective_url' => $effectiveUrl];
    }

    private function zoneRequest($fields, $cookie, $zoneUrl) {
        $ch = curl_init($zoneUrl);
        if ($ch === false) {
            throw CwpException::transport('Unable to initialise the DNS Zone Editor connection.');
        }
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($fields, '', '&'),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_HTTPHEADER => [
                'Accept: */*',
                'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With: XMLHttpRequest',
                'Cookie: ' . $cookie,
                'Referer: ' . $zoneUrl,
            ],
            CURLOPT_SSL_VERIFYPEER => $this->verifyTls,
            CURLOPT_SSL_VERIFYHOST => $this->verifyTls ? 2 : 0,
        ]);

        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $effectiveUrl = (string) curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);

        if ($body === false || $errno !== 0) {
            throw CwpException::transport('CWP DNS Zone Editor connection failed: ' . ($error !== '' ? $error : 'unknown cURL error'));
        }
        if ($http < 200 || $http >= 300) {
            throw CwpException::api('CWP DNS Zone Editor returned HTTP ' . $http . '.');
        }
        $text = strtolower((string) $body);
        if (strpos($text, 'login') !== false && strpos($text, 'password') !== false) {
            throw CwpException::api('CWP rejected the temporary DNS Zone Editor session. Check the WHMCS server credentials and CWP admin login requirements.');
        }

        return (string) $body;
    }

    private function cookieHeaderFromFile($file) {
        if (!is_readable($file)) {
            return '';
        }
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines)) {
            return '';
        }
        $cookies = [];
        foreach ($lines as $line) {
            if ($line === '') {
                continue;
            }
            // Netscape cookie jars prefix HttpOnly cookies with #HttpOnly_.
            // CWP commonly marks its authenticated panel cookie HttpOnly, so
            // those lines must be accepted rather than discarded.
            if (strpos($line, '#HttpOnly_') === 0) {
                $line = substr($line, strlen('#HttpOnly_'));
            } elseif ($line[0] === '#') {
                continue;
            }
            $parts = explode("\t", $line);
            if (count($parts) >= 7) {
                $name = trim($parts[5]);
                $value = trim($parts[6]);
                if ($name !== '') {
                    $cookies[$name] = $value;
                }
            }
        }
        $out = [];
        foreach ($cookies as $name => $value) {
            $out[] = $name . '=' . $value;
        }
        return implode('; ', $out);
    }

    private function zoneFile($domain) {
        $domain = strtolower(trim($domain));
        $domain = rtrim($domain, '.');
        if (preg_match('/^(?=.{1,253}$)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/', $domain) !== 1 || strpos($domain, '..') !== false) {
            throw CwpException::input('A valid DNS domain is required.');
        }
        return '/var/named/' . $domain . '.db';
    }

    private function recordName($name, $domain) {
        $name = strtolower(trim($name));
        $name = rtrim($name, '.');
        if ($name === '' || $name === '@') {
            return $domain;
        }
        if (substr($name, -strlen('.' . $domain)) === '.' . $domain) {
            return $name;
        }
        if (preg_match('/^[a-z0-9_*.@-]+$/', $name) !== 1) {
            throw CwpException::input('Enter a valid DNS record name.');
        }
        return $name . '.' . $domain;
    }

    private function relativeName($fqdn, $domain) {
        if ($fqdn === $domain) {
            return '@';
        }
        return substr($fqdn, 0, -(strlen($domain) + 1));
    }

    private function escapeTxt($value) {
        return str_replace(['\\', '"'], ['\\\\', '\\"'], $value);
    }

    private function encodeLine($line) {
        $line = trim($line);
        if ($line === '' || strlen($line) > 8192) {
            throw CwpException::input('A valid DNS record line is required.');
        }
        return base64_encode($line . "\n");
    }

    /** @return array<int,array<string,mixed>> */
    private function parseHtmlRecords($html) {
        if ($html === '') {
            return [];
        }

        $rows = [];
        if (class_exists('DOMDocument')) {
            $dom = new \DOMDocument();
            libxml_use_internal_errors(true);
            $dom->loadHTML('<meta http-equiv="Content-Type" content="text/html; charset=utf-8">' . $html);
            libxml_clear_errors();
            $xpath = new \DOMXPath($dom);
            foreach ($xpath->query('//tr') as $tr) {
                $cells = [];
                foreach ($xpath->query('./th|./td', $tr) as $cell) {
                    $cells[] = trim(html_entity_decode(preg_replace('/\s+/', ' ', (string) $cell->textContent), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
                }
                if ($cells !== []) {
                    $rows[] = [$cells, $tr->ownerDocument->saveHTML($tr)];
                }
            }
        } else {
            // The module must not require ext-dom. CWP returns ordinary HTML for
            // paserrecord, so a conservative row/cell parser is sufficient as a
            // fallback on WHMCS installations without the DOM extension.
            if (preg_match_all('/<tr\b[^>]*>(.*?)<\/tr>/is', $html, $rowMatches)) {
                foreach ($rowMatches[1] as $rowInner) {
                    $cells = [];
                    if (preg_match_all('/<(?:th|td)\b[^>]*>(.*?)<\/(?:th|td)>/is', $rowInner, $cellMatches)) {
                        foreach ($cellMatches[1] as $cellHtml) {
                            $text = html_entity_decode(strip_tags($cellHtml), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                            $cells[] = trim(preg_replace('/\s+/', ' ', $text));
                        }
                    }
                    if ($cells !== []) {
                        $rows[] = [$cells, '<tr>' . $rowInner . '</tr>'];
                    }
                }
            }
        }

        $records = [];
        $headerMap = null;
        foreach ($rows as [$cells, $rowHtml]) {
            $lower = array_map('strtolower', $cells);
            $nameIdx = array_search('name', $lower, true);
            $typeIdx = array_search('type', $lower, true);
            $ttlIdx = array_search('ttl', $lower, true);
            $valueIdx = array_search('value', $lower, true);
            if ($nameIdx !== false && $typeIdx !== false && $ttlIdx !== false && $valueIdx !== false) {
                $headerMap = [
                    'name' => (int) $nameIdx,
                    'type' => (int) $typeIdx,
                    'ttl' => (int) $ttlIdx,
                    'value' => (int) $valueIdx,
                ];
                continue;
            }

            if ($headerMap === null || count($cells) <= max($headerMap)) {
                continue;
            }

            $type = strtoupper(trim($cells[$headerMap['type']]));
            if (!in_array($type, ['A','AAAA','CNAME','MX','NS','TXT','SRV','CAA','PTR','DNAME','HINFO','AFSDB','RP','TLSA'], true)) {
                continue;
            }

            $name = trim($cells[$headerMap['name']]);
            $ttl = trim($cells[$headerMap['ttl']]);
            $value = trim($cells[$headerMap['value']]);
            if ($name === '' || $value === '') {
                continue;
            }

            $records[] = [
                'name' => $name,
                'type' => $type,
                'ttl' => is_numeric($ttl) ? (int) $ttl : $ttl,
                'priority' => 0,
                'value' => $value,
                'cells' => $cells,
                'line_number' => $this->findLineNumber($rowHtml),
                'line' => $this->findEncodedLine($rowHtml),
                'source' => 'cwp_zone_editor',
            ];
        }

        return $records;
    }

    private function findLineNumber($html) {
        if (preg_match('/(?:linedos|line[_-]?number|data-line(?:-number)?|data-linedos)\s*[=:]\s*["\']?(\d{1,6})/i', $html, $m)) {
            return (int) $m[1];
        }
        return 0;
    }

    private function findEncodedLine($html) {
        if (preg_match('/(?:line|editregzone|deleteregzone)[^\r\n]{0,600}?([A-Za-z0-9+\/=]{40,})/i', $html, $m)) {
            $decoded = base64_decode($m[1], true);
            return $decoded === false ? '' : $decoded;
        }
        return '';
    }

    /** @return array<string,mixed> */
    private function summariseResponse($body) {
        $text = trim(strip_tags($body));
        $text = preg_replace('/\s+/', ' ', $text);
        if (strlen($text) > 500) {
            $text = substr($text, 0, 500) . '...';
        }
        return [
            'ok' => true,
            'message' => $text !== '' ? $text : 'CWP accepted the DNS Zone Editor request.',
        ];
    }
}
