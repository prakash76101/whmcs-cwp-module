<?php
/**
 * CWP WHMCS Module — MySQL database and database-user management.
 *
 * CWP exposes MySQL databases through `databasemysql`. Database-user CRUD is
 * retained as deferred code, but the client portal does not call `usermysql/list`.
 *
 * @package cwp7
 * @version 3.0.16
 */
namespace Cwp7\Actions;

use Cwp7\CwpClient;
use Cwp7\CwpException;
use Cwp7\Validate;

final class Database
{
    const DATABASE_FUNCTION = 'databasemysql';
    const USER_FUNCTION = 'usermysql';
    const ACCOUNT = 'user';

    const DB_FIELD = 'database';
    const USER_FIELD = 'userdb';
    const PASSWORD_FIELD = 'pass';
    const HOST_FIELD = 'host';
    const USER_DB_FIELD = 'dbase';

    private $client;
    private $account;

    public function __construct(CwpClient $client, $account)
    {
        $this->client = $client;
        $this->account = $account;
    }

    /** @return array<int,array<string,mixed>> */
    public function databases() {
        return self::databaseRows(CwpClient::rows($this->client->call(
            self::DATABASE_FUNCTION,
            'list',
            [self::ACCOUNT => $this->account]
        )), $this->account);
    }

    /** @throws CwpException */
    public function createDatabase($database) {
        $database = self::databaseName($database);
        $this->client->call(self::DATABASE_FUNCTION, 'add', [
            self::ACCOUNT => $this->account,
            self::DB_FIELD => $database,
        ]);
        $this->client->clearReadCache();

        return $this->account . '_' . $database;
    }

    /** @throws CwpException */
    public function deleteDatabase($database) {
        $database = self::localDatabaseName($database, $this->account);
        $this->client->call(self::DATABASE_FUNCTION, 'del', [
            self::ACCOUNT => $this->account,
            self::DB_FIELD => $database,
        ]);
        $this->client->clearReadCache();
    }

    /** @throws CwpException */
    public function createUser($username, $password, $database, $host = 'localhost') {
        $username = Validate::accountName($username, 'database username');
        $password = Validate::password($password);
        $database = self::localDatabaseName($database, $this->account);
        $host = self::host($host);

        $this->client->call(self::USER_FUNCTION, 'add', [
            self::ACCOUNT => $this->account,
            self::USER_FIELD => $username,
            self::PASSWORD_FIELD => $password,
            self::USER_DB_FIELD => $database,
            self::HOST_FIELD => $host,
        ]);
        $this->client->clearReadCache();

        return $this->account . '_' . $username;
    }

    /** @throws CwpException */
    public function deleteUser($username, $host = 'localhost') {
        $username = self::localUserName($username, $this->account);
        $host = self::host($host);

        $this->client->call(self::USER_FUNCTION, 'del', [
            self::ACCOUNT => $this->account,
            self::USER_FIELD => $username,
            self::HOST_FIELD => $host,
        ]);
        $this->client->clearReadCache();
    }

    public static function databaseName($value) {
        $value = strtolower(trim($value));
        if ($value === '') {
            throw CwpException::input('Enter a database name.');
        }
        if (strlen($value) > 8) {
            throw CwpException::input('A database name may contain at most 8 characters in CWP.');
        }
        if (preg_match('/^[a-z][a-z0-9_]*$/', $value) !== 1) {
            throw CwpException::input('A database name may contain lowercase letters, numbers and underscores, and must begin with a letter.');
        }
        return $value;
    }

    public static function localDatabaseName($value, $account) {
        $value = strtolower(trim($value));
        $prefix = strtolower(trim($account)) . '_';
        if (strpos($value, $prefix) === 0) {
            $value = substr($value, strlen($prefix));
        }
        return self::databaseName($value);
    }

    public static function localUserName($value, $account) {
        $value = strtolower(trim($value));
        $prefix = strtolower(trim($account)) . '_';
        if (strpos($value, $prefix) === 0) {
            $value = substr($value, strlen($prefix));
        }
        return Validate::accountName($value, 'database username');
    }

    public static function host($value) {
        $value = strtolower(trim($value));
        if ($value === '') {
            return 'localhost';
        }
        if ($value === '%' || $value === 'localhost' || filter_var($value, FILTER_VALIDATE_IP) !== false) {
            return $value;
        }
        if (preg_match('/^(?:[a-z0-9-]+\.)*[a-z0-9-]+$/', $value) === 1) {
            return $value;
        }
        throw CwpException::input('Enter a valid database host, such as localhost or %.');
    }

    /** @param array<int,array<string,mixed>> $rows */
    public static function databaseRows($rows, $account) {
        $out = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $name = self::pick($row, ['database', 'dbname', 'db_name', 'name', 'db']);
            if ($name === null || trim((string) $name) === '') {
                continue;
            }
            $full = strtolower(trim((string) $name));
            $local = self::stripPrefix($full, $account);
            $out[] = [
                'database' => $full,
                'name' => $local,
                'size' => self::pick($row, ['size', 'dbsize', 'database_size']),
            ];
        }
        usort($out, function ($a, $b) { return strcmp($a['database'], $b['database']); });
        return $out;
    }

    /** @param array<int,array<string,mixed>> $rows */
    public static function userRows($rows, $account) {
        $out = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $name = self::pick($row, ['userdb', 'username', 'user', 'dbuser', 'name']);
            if ($name === null || trim((string) $name) === '') {
                continue;
            }
            $full = strtolower(trim((string) $name));
            $database = self::pick($row, ['dbase', 'database', 'dbname', 'db']);
            $out[] = [
                'username' => $full,
                'name' => self::stripPrefix($full, $account),
                'database' => $database === null ? '' : strtolower(trim((string) $database)),
                'host' => self::pick($row, ['host', 'hostname']) ?: 'localhost',
            ];
        }
        usort($out, function ($a, $b) { return strcmp($a['username'], $b['username']); });
        return $out;
    }

    private static function stripPrefix($value, $account) {
        $prefix = strtolower(trim($account)) . '_';
        return strpos($value, $prefix) === 0 ? substr($value, strlen($prefix)) : $value;
    }

    private static function pick($row, $keys)
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $row) && $row[$key] !== null && $row[$key] !== '') {
                return $row[$key];
            }
        }
        return null;
    }
}
