<?php
/**
 * CWP Hosting Module for WHMCS — CWP API transport.
 *
 * POST https://<host>:2304/v1/<function>, form-encoded, with `key` and `action`.
 * Responses are JSON: {"status":"OK", ...} or {"status":"Error","msg":"..."}.
 *
 * @package cwp7
 * @version 3.0.29
 * @author  Booysen Logistics <bradley@booysenlogistics.co.za>
 * @license MIT
 * @link    https://github.com/bradleygb/whmcs-cwp-module
 */
namespace Cwp7;

final class CwpClient
{
    /** Reachability probe used by TestConnection. */
    const PROBE_FUNCTION = 'typeserver';

    /** Secondary probe, so an unsupported PROBE_FUNCTION is not reported as a dead server. */
    const PROBE_FALLBACK = 'account';

    /**
     * libcurl codes for a failed certificate verification.
     *
     * Numeric literals, not CURLE_* constants: the constant set varies by build, and
     * CURLE_PEER_FAILED_VERIFICATION is undefined on PHP 8.3.
     */
    /**
     * Characters of a failed response carried into the error message. Long enough for
     * a framework error page to have got past its own boilerplate and said something.
     */
    const MAX_EXCERPT = 900;

    /** Longest raw response written to the module log, in bytes. */
    const MAX_LOG_BODY = 4000;

    /** Most payload rows written to the module log before they are summarised. */
    const MAX_LOG_ROWS = 20;

    const TLS_VERIFY_ERRORS = [51, 60, 77, 83];

    /**
     * Keys CWP has used to carry a response payload, in lookup order.
     *
     * Current builds return data under `result` and errors under `msg`. Older builds
     * used `msj` for both.
     */
    const MESSAGE_KEYS = ['result', 'msg', 'msj'];

    /** @var string */
    private $host;

    /** @var int */
    private $port;

    /** @var string */
    private $key;

    /** @var bool */
    private $verifyTls;

    /** @var string|null */
    private $caBundle;

    /** @var int */
    private $connectTimeout;

    /** @var int */
    private $timeout;

    /** @var int */
    private $provisionTimeout;

    /** @var bool */
    private $debug;

    /** @var int */
    private $panelPort;

    /** @var int */
    private $adminPort;

    /** @var int */
    private $webmailPort;

    /** @var array<string,mixed> */
    private $settings;

    /**
     * @param array<string,mixed> $settings
     *
     * @throws CwpException
     */
    public function __construct($settings)
    {
        $this->settings = $settings;

        $host = self::normaliseHost((string) (isset($settings['host']) ? $settings['host'] : ''));
        if ($host === null) {
            throw CwpException::config('server hostname/IP is missing or not a valid host');
        }

        $key = trim((string) (isset($settings['key']) ? $settings['key'] : ''));
        if ($key === '') {
            throw CwpException::config(
                'API key is empty — set it in the server entry\'s Access Hash field'
            );
        }

        $this->host = $host;
        $this->key = $key;
        $this->port = (int) (isset($settings['api_port']) ? $settings['api_port'] : 2304);
        $this->panelPort = (int) (isset($settings['panel_port']) ? $settings['panel_port'] : 2083);
        $this->adminPort = (int) (isset($settings['admin_port']) ? $settings['admin_port'] : 2031);
        $this->webmailPort = (int) (isset($settings['webmail_port']) ? $settings['webmail_port'] : 2096);
        $this->verifyTls = (bool) (isset($settings['verify_tls']) ? $settings['verify_tls'] : true);
        $this->connectTimeout = (int) (isset($settings['connect_timeout']) ? $settings['connect_timeout'] : 5);
        $this->timeout = (int) (isset($settings['timeout']) ? $settings['timeout'] : 20);
        $this->provisionTimeout = (int) (isset($settings['provision_timeout']) ? $settings['provision_timeout'] : 180);
        $this->debug = (bool) (isset($settings['debug']) ? $settings['debug'] : false);
        $this->readCacheEnabled = (bool) (isset($settings['read_cache_enabled']) ? $settings['read_cache_enabled'] : true);
        $this->readCacheTtl = max(0, (int) (isset($settings['read_cache_ttl']) ? $settings['read_cache_ttl'] : 15));

        $caBundle = isset($settings['ca_bundle']) ? $settings['ca_bundle'] : null;
        $this->caBundle = (is_string($caBundle) && $caBundle !== '') ? $caBundle : null;

        if ($this->port < 1 || $this->port > 65535) {
            throw CwpException::config('invalid API port: ' . $this->port);
        }
    }

    /**
     * Build a client from the parameters WHMCS passes every module function.
     *
     * @param array<string,mixed> $params
     *
     * @return self
     *
     * @throws CwpException
     */
    public static function fromParams($params)
    {
        $config = self::loadConfig();

        $host = (string) (isset($params['serverhostname']) ? $params['serverhostname'] : '');
        if (trim($host) === '') {
            $host = (string) (isset($params['serverip']) ? $params['serverip'] : '');
        }

        $settings = $config['defaults'];

        $hostKey = self::normaliseHost($host);
        if ($hostKey !== null && isset($config['servers'][$hostKey]) && is_array($config['servers'][$hostKey])) {
            $settings = array_merge($settings, $config['servers'][$hostKey]);
        }

        $settings['host'] = $host;
        $settings['key'] = (string) (isset($params['serveraccesshash']) ? $params['serveraccesshash'] : '');

        $serverPort = (int) (isset($params['serverport']) ? $params['serverport'] : 0);
        if ($serverPort > 0) {
            $settings['api_port'] = $serverPort;
        }

        return new self($settings);
    }

    /**
     * Issue one API call.
     *
     * @param $function CWP function, e.g. 'accountdetail'
     * @param $action   'list' | 'add' | 'udp' | 'del' | 'susp' | 'unsp'
     * @param array<string,scalar> $fields   Additional POST fields
     *
     * @return array<string,mixed> Decoded response, status verified as OK
     *
     * @throws CwpException
     */
    public function call($function, $action, $fields = [], $timeoutOverride = null) {
        // $function lands in the URL path.
        if (preg_match('/^[a-z0-9_]+$/', $function) !== 1) {
            throw CwpException::config('illegal CWP function name: ' . $function);
        }

        if (preg_match('/^[a-z_]+$/', $action) !== 1) {
            throw CwpException::config('illegal CWP action: ' . $action);
        }

        $url = sprintf('https://%s:%d/v1/%s', $this->host, $this->port, $function);

        // Only successful LIST calls are cached. Mutations are never cached, and the
        // cache is deliberately scoped to this CwpClient instance/request so stale data
        // cannot survive between unrelated WHMCS requests. This removes duplicate reads
        // during one render while keeping the correctness of the existing module.
        $cacheKey = $function . '/' . $action . '?' . http_build_query($fields);
        if ($this->readCacheEnabled && $this->readCacheTtl > 0 && $action === 'list') {
            if (isset($this->readCache[$cacheKey])) {
                $cached = $this->readCache[$cacheKey];
                if ((int) $cached['expires'] >= time()) {
                    return $cached['response'];
                }
                unset($this->readCache[$cacheKey]);
            }
        }

        $post = $fields;
        $post['key'] = $this->key;
        $post['action'] = $action;

        if ($this->debug) {
            $post['debug'] = '1';
        }

        $started = microtime(true);
        list($body, $httpCode, $curlErrno, $curlError, $primaryIp) = $this->execute(
            $url,
            $post,
            $timeoutOverride !== null ? max(1, $timeoutOverride) : $this->timeoutFor($action)
        );
        $elapsedMs = (int) round((microtime(true) - $started) * 1000);

        $context = [
            'function' => $function,
            'action' => $action,
            'http_code' => $httpCode,
            'elapsed_ms' => $elapsedMs,
            'curl_errno' => $curlErrno,
            'resolved_ip' => $primaryIp,
        ];

        try {
            $decoded = $this->interpret($body, $httpCode, $curlErrno, $curlError, $context);
        } catch (CwpException $e) {
            $this->log($function . '/' . $action, $url, $post, $body, $e->getMessage());
            throw $e;
        }

        $this->log($function . '/' . $action, $url, $post, $body, $decoded);

        if ($this->readCacheEnabled && $this->readCacheTtl > 0 && $action === 'list') {
            $this->readCache[$cacheKey] = [
                'expires' => time() + $this->readCacheTtl,
                'response' => $decoded,
            ];
        }

        return $decoded;
    }

    /**
     * Reachability check for TestConnection.
     *
     * @return array{ok:bool, endpoint:string, error:CwpException|null}
     */
    public function ping() {
        try {
            $this->call(self::PROBE_FUNCTION, 'list');

            return ['ok' => true, 'endpoint' => self::PROBE_FUNCTION, 'error' => null];
        } catch (CwpException $primary) {
            // Only an unrecognised endpoint or a permission refusal warrants the fallback.
            if ($primary->getKind() === CwpException::KIND_TRANSPORT
                || $primary->getKind() === CwpException::KIND_CONFIG
            ) {
                return ['ok' => false, 'endpoint' => self::PROBE_FUNCTION, 'error' => $primary];
            }

            try {
                $this->call(self::PROBE_FALLBACK, 'list');

                return ['ok' => true, 'endpoint' => self::PROBE_FALLBACK, 'error' => null];
            } catch (CwpException $fallback) {
                return ['ok' => false, 'endpoint' => self::PROBE_FALLBACK, 'error' => $fallback];
            }
        }
    }

    public function getHost() {
        return $this->host;
    }

    /** Base URL of the CWP end-user panel. */
    public function getPanelUrl() {
        return sprintf('https://%s:%d', $this->host, $this->panelPort);
    }

    /** Base URL of the CWP admin panel. */
    public function getAdminUrl() {
        return sprintf('https://%s:%d', $this->host, $this->adminPort);
    }

    /** Base URL of CWP Webmail. */
    public function getWebmailUrl() {
        return sprintf('https://%s:%d', $this->host, $this->webmailPort);
    }

    /**
     * A setting from config.php, after per-server overrides have been merged.
     *
     * @param mixed $default
     *
     * @return mixed
     */
    public function getOption($key, $default = null)
    {
        return array_key_exists($key, $this->settings) ? $this->settings[$key] : $default;
    }

    /** Clear successful read responses cached by this client instance. */
    public function clearReadCache() {
        $this->readCache = [];
    }

    /** Number of successful read responses currently retained by this instance. */
    public function readCacheCount() {
        return count($this->readCache);
    }

    /**
     * Ordinal of the JSON string-escape character.
     *
     * Numeric so this file carries no escape sequence of its own - one did not survive a
     * scripted edit while this was being written, and silently became a broken literal.
     */
    const JSON_ESCAPE = 92;

    /**
     * The first complete JSON object at the head of a reply, or null.
     *
     * For replies that are valid JSON followed by something else. Scans brace depth while
     * respecting quoted strings and escapes, so a brace inside a value cannot end the
     * object early - which is why this is not a search for the first "}<".
     *
     * @return array<string,mixed>|null
     */
    private static function leadingJsonObject($body)
    {
        $body = ltrim($body);

        if (strncmp($body, '{', 1) !== 0) {
            return null;
        }

        $depth = 0;
        $inString = false;
        $escaped = false;
        $length = strlen($body);

        for ($i = 0; $i < $length; $i++) {
            $char = $body[$i];

            if ($inString) {
                if ($escaped) {
                    $escaped = false;
                } elseif (ord($char) === self::JSON_ESCAPE) {
                    $escaped = true;
                } elseif ($char === '"') {
                    $inString = false;
                }

                continue;
            }

            if ($char === '"') {
                $inString = true;
                continue;
            }

            if ($char === '{') {
                $depth++;
                continue;
            }

            if ($char !== '}') {
                continue;
            }

            if (--$depth > 0) {
                continue;
            }

            $decoded = json_decode(substr($body, 0, $i + 1), true);

            return is_array($decoded) ? $decoded : null;
        }

        // Never balanced: the reply is truncated, not merely followed by something.
        return null;
    }

    /**
     * The message/payload a response carries, under either supported key.
     *
     * @param array<string,mixed> $decoded
     *
     * @return mixed Null when the response carries neither key.
     */
    public static function payload($decoded)
    {
        foreach (self::MESSAGE_KEYS as $key) {
            if (array_key_exists($key, $decoded)) {
                return $decoded[$key];
            }
        }

        return null;
    }

    /**
     * The payload as a list of rows, for endpoints returning a collection.
     *
     * @param array<string,mixed> $decoded
     *
     * @return array<int,array<string,mixed>>
     */
    public static function rows($decoded) {
        $payload = self::payload($decoded);

        if (!is_array($payload)) {
            return [];
        }

        // An associative array is a single row, not a list of rows.
        if ($payload !== [] && !array_key_exists(0, $payload)) {
            return [$payload];
        }

        $rows = [];
        foreach ($payload as $row) {
            if (is_array($row)) {
                $rows[] = $row;
            }
        }

        return $rows;
    }

    /** True for RFC1918, loopback, link-local and other non-routable addresses. */
    public static function isPrivateIp($ip) {
        if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
            return false;
        }

        return filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        ) === false;
    }

    /**
     * CWP returns its message as a string on some functions and an array on others.
     *
     * @param mixed $msg
     */
    public static function flattenMessage($msg) {
        if (is_string($msg)) {
            return $msg;
        }

        if (is_scalar($msg)) {
            return (string) $msg;
        }

        if (is_array($msg)) {
            $flat = json_encode($msg);

            return is_string($flat) ? $flat : 'unserialisable message';
        }

        return 'unknown error';
    }

    /**
     * How long a given action may run.
     *
     * Reads answer in milliseconds. Provisioning does not: creating an account builds a
     * user, home directory, vhost, DNS zone and mail configuration, and CWP keeps working
     * after a client gives up — so a short budget produces an account on the server and a
     * failed service in WHMCS.
     */
    public function timeoutFor($action) {
        return $action === 'list' ? $this->timeout : $this->provisionTimeout;
    }

    /**
     * @param array<string,scalar> $post
     *
     * @return array{0:string|null, 1:int, 2:int, 3:string, 4:string}
     *
     * @throws CwpException
     */
    private function execute($url, $post, $timeout) {
        $ch = curl_init();
        if ($ch === false) {
            throw CwpException::transport('could not initialise cURL');
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->connectTimeout);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

        // The API key is in the POST body; a redirect could replay it elsewhere.
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);

        if (defined('CURLOPT_PROTOCOLS_STR')) {
            curl_setopt($ch, CURLOPT_PROTOCOLS_STR, 'https');
        } elseif (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTPS')) {
            curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
        }

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $this->verifyTls);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $this->verifyTls ? 2 : 0);

        if ($this->verifyTls && $this->caBundle !== null) {
            curl_setopt($ch, CURLOPT_CAINFO, $this->caBundle);
        }

        $body = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $primaryIp = (string) curl_getinfo($ch, CURLINFO_PRIMARY_IP);

        curl_close($ch);

        return [is_string($body) ? $body : null, $httpCode, $errno, $error, $primaryIp];
    }

    /**
     * Turn a raw reply into a verified-OK response array, or throw.
     *
     * @param string|null         $body
     * @param array<string,mixed> $context
     *
     * @return array<string,mixed>
     *
     * @throws CwpException
     */
    private function interpret(
        $body,
        $httpCode,
        $curlErrno,
        $curlError,
        $context
    ) {
        if ($curlErrno !== 0) {
            if (in_array($curlErrno, self::TLS_VERIFY_ERRORS, true)) {
                throw CwpException::transport(
                    'TLS verification failed (' . $curlError . '). Check the certificate on '
                    . 'the API port: if it is self-signed, export it and set "ca_bundle" in '
                    . 'config.php; if it is from a real CA, this server\'s CA store is the '
                    . 'problem. Do not disable verification.',
                    $context
                );
            }

            $detail = $curlError . ' (errno ' . $curlErrno . ')';

            $ip = isset($context['resolved_ip']) ? (string) $context['resolved_ip'] : '';

            if ($ip !== '' && $ip !== $this->host) {
                $detail .= ' — ' . $this->host . ' resolved to ' . $ip;

                // Only where the connection itself failed. On a timeout the socket opened,
                // so where the name pointed is not the problem.
                $connectFailed = ($curlErrno === 6 || $curlErrno === 7);

                if ($connectFailed && self::isPrivateIp($ip)) {
                    $detail .= ', a private (RFC1918) address. That only works if WHMCS is on '
                        . 'the same network as CWP; otherwise this hostname resolves elsewhere '
                        . 'from the WHMCS server than it does from your workstation';
                }
            }

            throw CwpException::transport($detail, $context);
        }

        if ($body === null || $body === '') {
            throw CwpException::protocol('empty response body', $context);
        }

        if ($httpCode !== 200) {
            // Carry an excerpt of what came back. CWP answers some refusals with a PHP
            // error rather than a status, and discarding the body leaves nothing to work
            // from but the number - which is how an HTTP 500 on email/del cost a day.
            throw CwpException::protocol(
                'HTTP ' . $httpCode . ': ' . $this->excerpt($body),
                $context
            );
        }

        $decoded = json_decode($body, true);

        if (!is_array($decoded)) {
            // CWP appends its panel's HTML confirmation after the JSON on some actions.
            // account/del is confirmed - it answered `{"status":"OK"}<pre>User northwin
            // deleted from server...`, which json_decode rejects outright, so a
            // termination that had already happened was reported to WHMCS as a failure.
            //
            // Take the object off the front rather than special-casing that one action:
            // account/susp and account/unsp go through the same CWP controller and are
            // the obvious next candidates.
            //
            // Nothing is hidden by this. log() records the whole raw body, which is how
            // the trailing markup was found in the first place.
            $decoded = self::leadingJsonObject($body);
        }

        if (!is_array($decoded)) {
            if (strncmp(ltrim($body), '<', 1) === 0) {
                throw CwpException::config(
                    'CWP returned XML. Set this API key\'s response format to JSON in '
                    . 'CWP -> Settings -> API Manager.',
                    $context
                );
            }

            throw CwpException::protocol(
                'response was not JSON: ' . $this->redact(substr($body, 0, 200)),
                $context
            );
        }

        $status = (string) (isset($decoded['status']) ? $decoded['status'] : '');

        if (strcasecmp($status, 'OK') !== 0) {
            $message = self::payload($decoded);
            if ($message === null) {
                $message = ($status !== '') ? $status : 'no status field';
            }

            // CWP echoes the submitted key inside some errors, and this text reaches the
            // admin UI.
            $detail = $this->redact(self::flattenMessage($message));

            // The API Manager grid is per function and per action, so name both.
            if (isset($context['function'], $context['action'])) {
                $detail .= ' [' . $context['function'] . '/' . $context['action'] . ']';
            }

            throw CwpException::api($detail, $context);
        }

        return $decoded;
    }

    /** Remove the API key from text that originated at CWP. */
    private function redact($text) {
        if ($this->key !== '') {
            $text = str_replace($this->key, '[api key redacted]', $text);
        }

        return self::redactHashes($text);
    }

    /**
     * Does this field name hold something that must not be logged?
     *
     * A shape rather than a list, because the list has already been wrong once.
     */
    public static function isSecretField($field) {
        $field = strtolower($field);

        foreach (['pass', 'secret', 'token', 'key', 'hash'] as $marker) {
            if (strpos($field, $marker) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Strip stored password hashes out of anything on its way to the Module Log.
     *
     * email/list returns every mailbox's hash in full — `{SHA512-CRYPT}$6$…` — and CWP
     * offers no way to ask it not to. Logging the response verbatim puts the hash of
     * every customer mailbox password into a file any WHMCS admin can read, so they are
     * removed here rather than at each call site.
     *
     * Both shapes are covered: the scheme-prefixed form CWP sends, and a bare crypt hash.
     */
    public static function redactHashes($text) {
        $text = preg_replace('/\{[A-Z0-9-]{3,20}\}\$[^\s",}\]]+/', '[hash redacted]', $text);

        return (string) preg_replace('/\$[0-9a-z]{1,2}\$[^\s",}\]]{8,}/', '[hash redacted]', (string) $text);
    }

    /**
     * A short, safe piece of a response, for a message that has to explain itself.
     */
    private function excerpt($body) {
        // Drop stylesheets and scripts before the tags around them. CWP's API runs on
        // Slim, whose error page opens with an inline stylesheet long enough to fill the
        // whole budget and push the actual error past the end of it.
        $body = preg_replace('#<style[^>]*>.*?</style>#is', ' ', $body);
        $body = preg_replace('#<script[^>]*>.*?</script>#is', ' ', (string) $body);
        $body = trim(preg_replace('/\s+/', ' ', strip_tags((string) $body)));

        if ($body === '') {
            return '(empty body)';
        }

        return $this->redact(
            strlen($body) > self::MAX_EXCERPT ? substr($body, 0, self::MAX_EXCERPT) . '...' : $body
        );
    }

    /**
     * The same, applied through a decoded payload.
     *
     * WHMCS print_r's an array response into the log, so a hash nested in one would
     * otherwise never meet redact().
     *
     * @param mixed $value
     *
     * @return mixed
     */
    public static function redactPayload($value)
    {
        if (is_string($value)) {
            return self::redactHashes($value);
        }

        if (!is_array($value)) {
            return $value;
        }

        foreach ($value as $key => $item) {
            $value[$key] = self::redactPayload($item);
        }

        return $value;
    }

    /**
     * Write to the WHMCS Module Log with credentials masked.
     *
     * @param array<string,scalar> $post
     * @param string|null          $rawResponse
     * @param mixed                $processed
     */
    private function log($action, $url, $post, $rawResponse, $processed) {
        if (!function_exists('logModuleCall')) {
            return;
        }

        $safePost = $post;
        $safePost['key'] = '***';
        $replaceVars = [$this->key];

        // Every field whose name looks like a password, not a named list of them. CWP
        // calls the same thing `pass` on email/add and `password` on email/udp, and
        // masking only the first put a customer's mailbox password into the Module Log
        // in cleartext. The next endpoint will name it something else again.
        foreach ($post as $field => $value) {
            if (!self::isSecretField((string) $field) || !is_scalar($value) || $value === '') {
                continue;
            }

            $safePost[$field] = '***';
            $replaceVars[] = (string) $value;
        }

        logModuleCall(
            'cwp7',
            $action,
            $url . ' ' . http_build_query($safePost),
            $rawResponse === null ? '' : $this->redact(self::capBody($rawResponse)),
            is_string($processed) ? $this->redact($processed) : self::redactPayload(self::capRows($processed)),
            $replaceVars
        );
    }

    /**
     * Trim a response body to something a log row can hold.
     *
     * The head carries the status and enough rows to see the shape; the tail is the same
     * shape repeated. Says how much it dropped, so nobody reads a truncated body as a
     * short one.
     */
    private static function capBody($body) {
        $length = strlen($body);

        if ($length <= self::MAX_LOG_BODY) {
            return $body;
        }

        return substr($body, 0, self::MAX_LOG_BODY)
            . sprintf('... [%d of %d bytes logged]', self::MAX_LOG_BODY, $length);
    }

    /**
     * Summarise a long list response instead of logging every row.
     *
     * email/list returns every mailbox on the account and the client area fetches it on
     * every page view, so an account with hundreds of mailboxes wrote hundreds of rows
     * into tblmodulelog each time somebody opened their service page.
     *
     * Keeps the first few rows, because the shape is what anyone reading the log is
     * after, and states how many were dropped.
     *
     * @param mixed $processed
     *
     * @return mixed
     */
    private static function capRows($processed)
    {
        if (!is_array($processed)) {
            return $processed;
        }

        foreach (self::MESSAGE_KEYS as $key) {
            if (!isset($processed[$key]) || !is_array($processed[$key])) {
                continue;
            }

            $rows = $processed[$key];
            $count = count($rows);

            if ($count <= self::MAX_LOG_ROWS || !isset($rows[0])) {
                return $processed;
            }

            $processed[$key] = array_slice($rows, 0, self::MAX_LOG_ROWS);
            $processed[$key][] = sprintf(
                '... %d more rows, not logged (%d in total)',
                $count - self::MAX_LOG_ROWS,
                $count
            );

            return $processed;
        }

        return $processed;
    }

    /**
     * Reduce whatever is in the server entry to a bare host.
     *
     * Accepts a pasted URL. Returns null if nothing usable remains.
     *
     * @return string|null
     */
    private static function normaliseHost($raw)
    {
        $host = trim($raw);
        if ($host === '') {
            return null;
        }

        $host = preg_replace('#^[a-z][a-z0-9+.-]*://#i', '', $host);
        if ($host === null) {
            return null;
        }

        $parts = explode('/', $host, 2);
        $host = $parts[0];

        // Strip a trailing :port, but leave bare IPv6 alone.
        if (substr_count($host, ':') === 1) {
            $bits = explode(':', $host, 2);
            $host = $bits[0];
        }

        $host = trim($host);
        if ($host === '') {
            return null;
        }

        if (filter_var($host, FILTER_VALIDATE_IP) !== false) {
            return $host;
        }

        if (filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) !== false) {
            return $host;
        }

        return null;
    }

    /**
     * Optional. Every key has a default in the constructor, so an absent config.php
     * is a supported state.
     *
     * @return array{defaults:array<string,mixed>, servers:array<string,array<string,mixed>>}
     */
    private static function loadConfig() {
        static $config = null;

        if ($config === null) {
            $path = __DIR__ . '/../config.php';
            $loaded = is_readable($path) ? require $path : [];

            $config = [
                'defaults' => (is_array($loaded) && isset($loaded['defaults']) && is_array($loaded['defaults']))
                    ? $loaded['defaults'] : [],
                'servers' => (is_array($loaded) && isset($loaded['servers']) && is_array($loaded['servers']))
                    ? $loaded['servers'] : [],
            ];
        }

        return $config;
    }
}
